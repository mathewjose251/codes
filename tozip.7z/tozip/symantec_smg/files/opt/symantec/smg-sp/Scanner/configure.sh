#!/bin/sh
##################
### usage
###     ./configure.sh
################

# Are we upgrading from 10.X ?
# If so, we will skip portions of this configuration script

upgrade_10x=0
prev_version="unknown"
backup_dir=/opt/Symantec/smg_sp_10.6
test -f ${backup_dir}/bmiconfig.xml && upgrade_10x=1
test -f ${backup_dir}/prior_version && prev_version=`cat $backup_dir/prior_version`

echo ""
echo "This script will configure the \"Symantec Messaging Gateway for Service Providers\" 10.6 product"
echo "########  Checking for "root" privileges ..."
export user=$(whoami)
echo "########  "$user" user found."
if [ $user != "root" ]
then
echo "########  Configuration should be run through root only"
echo "########  Exiting...."
exit
fi

export ConfigureLog="/opt/symantec/smg-sp/Scanner"
touch $ConfigureLog/configure.log
echo "########  Configuration Log file :  [" `date` "]" > $ConfigureLog/configure.log
echo " "  >> $ConfigureLog/configure.log
echo "########  \"$user\" user found." >> $ConfigureLog/configure.log
upgrade=0
################ check Path ############################################
checkpath()
{
export chkpath="$1"
#export chkpath=`echo "$1" | sed 's/ //g'`
if [ -f "$chkpath" ]; then
echo "This is a file and not a directory"
return 0
else

if [ "$chkpath" = ""  >  /dev/null 2>&1 ]; then
echo "No input provided,  keeping the Default"
echo "########  No input provided,  keeping the Default" >> $ConfigureLog/configure.log
else
#Status=$(checkdirectory "$chkdir")
#echo $Status
#if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
#echo $Status
#else
if [ -d "$chkpath" ] ; then
echo $chkpath
else
echo "Not a valid Path"
echo "########  Not a valid Path" >> $ConfigureLog/configure.log
fi
fi
fi
}
#######################################################################
################# Start Check Directory function ########################

checkdirectory()
{
export dirc="$1"
#export dirc=`echo "$1" | sed 's/ //g'`
#if [ "$dirc" = ""  >  /dev/null 2>&1 ]; then
#echo "########  No input provided,  keeping the Default "
#echo "########  No input provided,  keeping the Default " >> $ConfigureLog/configure.log
#else

if [ -f "$dirc" ]; then
echo "########  This is a file and not a directory"
return 0
else
touch file.dirc1
touch file.dirc1.1
echo $dirc >  file.dirc1
d=0
while [ -n "$d" ]
do
sed -e 's/\/\//\//g' file.dirc1 > file.dirc1.1 && mv file.dirc1.1 file.dirc1
sed -e 's/\/\//\//g' file.dirc1 > file.dirc1.1
d=`diff file.dirc1 file.dirc1.1`
done
dirc="`cat file.dirc1`"

rm -rf file.dirc1 file.dirc1.1

if [ "$dirc" = "/tmp" ] || [ "$dirc" = "/tmp/" ] || [ "$dirc" = "/" ] || [ "$dirc" = "/opt/" ] || [ "$dirc" = "/opt" ] || [ "$dirc" = "/var/" ] ||[ "$dirc" = "/var" ] || [ "$dirc" = "/etc/" ] || [ "$dirc" = "/etc" ] || [ "$dirc" = "/var/" ] || [ "$dirc" = "/dev/" ] || [ "$dirc" = "/dev" ]|| [ "$dirc" = "/proc" ] || [ "$dirc" = "/proc/" ]|| [ "$dirc" = "/NULL/" ]||[ "$dirc" = "/NULL" ] || [ "$dirc" = "/home/" ] || [ "$dirc" = "/home" ]; then

#echo $dirc
echo "Permissions to this directory wont be changed to \"mailwall:bmi\""
echo "########  Permissions to this directory wont be changed to \"mailwall:bmi\"" >> $ConfigureLog/configure.log
else
echo $dirc
fi
fi
}

################# End Check Directory function ########################

#################Checking for earlier Installation################
echo ""
echo "######  Checking for Earlier installation ..."
echo "######  Checking for Earlier installation ..." >> $ConfigureLog/configure.log
if [ $upgrade_10x -eq 0 ] && [ -f /var/.com.zerog.registry.xml ]; then

    echo ""
    export products_found=`cat /var/.com.zerog.registry.xml | grep "<product name=" | wc -l `
    echo "######  Number of Products found : " $products_found
        echo "######  Number of Products found : " $products_found >> $ConfigureLog/configure.log
    cnt=0

    if [ "$products_found" -gt 0 ] ; then
    cat /var/.com.zerog.registry.xml | while read LINE
        do
           export pfound=`echo $LINE | grep "<product name="`
            if [ ! -z "$pfound" ]; then
            firstproduct[$cnt]=`echo $LINE | grep "<product name="| grep "<product name=" | cut -d "\"" -f2`
            echo ""
            echo "######  Product found : "  ${firstproduct[$cnt]}
                        echo "######  Product found : "  ${firstproduct[$cnt]} >> $ConfigureLog/configure.log

            if [ "${firstproduct[$cnt]}" = "Brightmail Control Center" ]; then
                bcc_location=`echo $LINE | awk '/location/ { print $10} ' | cut -d "\"" -f2`
                echo "######  \"${firstproduct[$cnt]}\" installation location : $bcc_location"
                                echo "######  \"${firstproduct[$cnt]}\" installation location : $bcc_location" >> $ConfigureLog/configure.log
                echo $bcc_location > /opt/symantec/smg-sp/Scanner/bcc_loc.txt
            fi

             if [ "${firstproduct[$cnt]}" = "Brightmail Scanner" ]; then
                location=`echo $LINE | awk '/location/ { print $9} '| cut -d "\"" -f2`
                echo "######  \"${firstproduct[$cnt]}\" installation location : $location"
                                echo "######  \"${firstproduct[$cnt]}\" installation location : $location" >> $ConfigureLog/configure.log
                echo $location > /opt/symantec/smg-sp/Scanner/loc.txt

                echo "######  Reading Version through bmiconfig.xml ###########"
                                echo "######  Reading Version through bmiconfig.xml ###########" >> $ConfigureLog/configure.log
               if [ -f $location/etc/bmiconfig.xml ]; then
                    smf_version=`cat $location/etc/bmiconfig.xml | awk '/productVersion/ { print $1}' | cut -d ">" -f2 | cut  -d "<" -f1`
                    echo "######  Scanner version =" $smf_version
                                        echo "######  Scanner version =" $smf_version >> $ConfigureLog/configure.log
                fi

                export version=`echo $smf_version | sed 's/^ *\(.*\) *$/\1/'`
                export smf_version=$version
                echo $version > /opt/symantec/smg-sp/Scanner/ver.txt
                 if [ "$version" !=  "6.3.0.0000" ] ; then
                    echo "######  Can not be upgraded from version \" $version\" "
                    echo "######  Upgrade is possible from SMF 6.3 only "
                    echo "######  Can not be upgraded from version \" $version\" " >> $ConfigureLog/configure.log
                    echo "######  Upgrade is possible from SMF 6.3 only " >> $ConfigureLog/configure.log
                    exit
                else
                                if [ -f $location/etc/bmiconfig.xml ]; then
                                        cp $location/etc/bmiconfig.xml /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml.6.3
                                        echo "$location/etc/bmiconfig.xml file Found" >> $ConfigureLog/configure.log
                                else
                                        echo "$location/etc/bmiconfig.xml file not Found" >> $ConfigureLog/configure.log
                                fi

                                if [ -f $location/etc/cert.pem ]; then
                                        cp $location/etc/cert.pem /opt/symantec/smg-sp/Scanner/etc
                                        echo "######  $location/etc/cert.pem file is copied to /opt/symantec/smg-sp/Scanner/etc" >> $ConfigureLog/configure.log
                                else
                                        echo "######  $location/etc/cert.pem file not Found" >> $ConfigureLog/configure.log
                                fi

                                if [ -f /etc/init.d/mailwall ]; then
                                        cp /etc/init.d/mailwall /etc/init.d/mailwall-10.6
                                else
                                        echo "######  /etc/init.d/mailwall File not found" >> $ConfigureLog/configure.log
                                fi

                                if [ -f /etc/init.d/mailwall-$version ]; then
                                        mv /etc/init.d/mailwall-$version /etc/init.d/mailwall
                                fi
                fi
            fi
        let cnt++
       fi
    done

        if [ -f /opt/symantec/smg-sp/Scanner/ver.txt ]; then
            version=`cat /opt/symantec/smg-sp/Scanner/ver.txt`
            rm -rf /opt/symantec/smg-sp/Scanner/ver.txt
        fi
        if [ -f /opt/symantec/smg-sp/Scanner/loc.txt ]; then
            location=`cat /opt/symantec/smg-sp/Scanner/loc.txt`
            rm -rf /opt/symantec/smg-sp/Scanner/loc.txt
        fi
         if [ -f /opt/symantec/smg-sp/Scanner/bcc_loc.txt ]; then
            bcc_location=`cat /opt/symantec/smg-sp/Scanner/bcc_loc.txt`
            rm -rf /opt/symantec/smg-sp/Scanner/bcc_loc.txt
        fi

  else
            echo "######  No earlier \"Brightmail\" installation found"  >> $ConfigureLog/configure.log
  fi
elif [ $upgrade_10x -eq 0 ]; then
        echo "######  No earlier \"Brightmail\" installation found"  >> $ConfigureLog/configure.log
fi

if [ $upgrade_10x -ne 0 ]; then
    echo "######  Previous $prev_version version of the \"Symantec Messaging Gateway for Service Providers\" was found."
    echo "######  Previous $prev_version version of the \"Symantec Messaging Gateway for Service Providers\" was found." >> $ConfigureLog/configure.log

fi

        if [  -f "$location/etc/allowedblockedlist.txt" ]; then
            cp "$location/etc/allowedblockedlist.txt" /opt/symantec/smg-sp/Scanner/etc
        fi

if [ $upgrade_10x -eq 0 ] && [ "$products_found" != "0" ] && [ -f /var/.com.zerog.registry.xml ] || [ -f $location/etc/bmiconfig.xml ] && [ ! -z $location ]; then
        if [ "$version" ==  "6.3.0.0000" ]; then
        upgrade=1
echo "######  Version 6.3.0.0000 found." >> $ConfigureLog/configure.log
echo "######  Version 6.3.0.0000 found."
echo ""


cd /opt/symantec/smg-sp/Scanner/bin/
if [ -f /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_linux.tar ];then
tar -xf CONFUP_106_x86_linux.tar >  /dev/null 2>&1
fi

if [ -f /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_64_linux.tar ];then
tar -xf CONFUP_106_x86_64_linux.tar >  /dev/null 2>&1
fi

cd xml_up

#'type' attribute addition is reuired only for v6.3 to v10.5 upgrade. From v10.5 upgrades this attribute additon must be removed.
###     Removing for 10.6
# installtype=`file /opt/symantec/smg-sp/Scanner/bin/bmserver |  awk  '{ print $3 }'`
# test -f $location/etc/bmiconfig.xml && sed -i -e "s/arch=/type=\"${installtype}\" arch=/i" $location/etc/bmiconfig.xml

export LD_LIBRARY_PATH=/opt/symantec/smg-sp/Scanner/lib
./configupgrade -i $location/etc/bmiconfig.xml -r /opt/symantec/smg-sp/Scanner/bin/xml_up/ -o /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml

if [ -f /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml ]; then
earlier_location=`cat /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml | awk '/loadpoint/ { print $1}' | cut -d ">" -f2 | cut  -d "<" -f1`
touch /opt/symantec/smg-sp/Scanner/file.LocDir1
echo $earlier_location >  /opt/symantec/smg-sp/Scanner/file.LocDir1
sed -e 's/\//\\\//g' /opt/symantec/smg-sp/Scanner/file.LocDir1 >> /opt/symantec/smg-sp/Scanner/file.LocDir1.1 && mv /opt/symantec/smg-sp/Scanner/file.LocDir1.1 /opt/symantec/smg-sp/Scanner/file.LocDir1
LocDir1="`cat /opt/symantec/smg-sp/Scanner/file.LocDir1`"
test -f /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml && sed -i -e  "s#${LocDir1}#/opt/symantec/smg-sp/Scanner#g" /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml
rm -rf /opt/symantec/smg-sp/Scanner/file.LocDir1
fi

cd - >  /dev/null 2>&1

if [ -d /opt/symantec/smg-sp/Scanner/bin/xml_up ];then
rm -rf /opt/symantec/smg-sp/Scanner/bin/xml_up >  /dev/null 2>&1
fi
else
echo "Exiting..."
echo "Exiting..."  >> $ConfigureLog/configure.log
exit
fi
    echo "########  Uninstalling earlier brightmail installation."
    echo "########  Uninstalling earlier brightmail installation." >> $ConfigureLog/configure.log
    $location/UninstallerData/Uninstall | tee $ConfigureLog/scanner_uninstallation.log
    echo "########  Scanner uninstallation is successful"
    echo "########  Scanner uninstallation is successful" >> $ConfigureLog/configure.log
    if [ -f /etc/init.d/mailwall-10.6 ]; then
        mv /etc/init.d/mailwall-10.6 /etc/init.d/mailwall
        fi
fi

if [ $upgrade_10x -ne 0 ]; then
    # run config-upgrade for 10.X upgrade scenario

    cd /opt/symantec/smg-sp/Scanner/bin/
    if [ -f /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_linux.tar ];then
        tar -xf CONFUP_106_x86_linux.tar >  /dev/null 2>&1
    fi

    if [ -f /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_64_linux.tar ];then
        tar -xf CONFUP_106_x86_64_linux.tar >  /dev/null 2>&1
    fi

    if [ -d xml_up ]; then
        cd xml_up

        export LD_LIBRARY_PATH=/opt/symantec/smg-sp/Scanner/lib
        ./configupgrade -i $backup_dir/bmiconfig.xml -r /opt/symantec/smg-sp/Scanner/bin/xml_up/ -o /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml

        cd - >  /dev/null 2>&1

        if [ -d /opt/symantec/smg-sp/Scanner/bin/xml_up ];then
            rm -rf /opt/symantec/smg-sp/Scanner/bin/xml_up  >  /dev/null 2>&1
        fi
    fi
fi

###  No longer relevant for 10.6 install
#if [ "$products_found" != "0" ] && [ -f /var/.com.zerog.registry.xml ] || [ -f $location/etc/bmiconfig.xml ] && [ ! -z $bcc_location ]; then
#                echo "BCC Installation Detected, SMG-SP 10.5 does not require BCC"
#               echo "BCC Installation Detected, SMG-SP 10.5 does not require BCC" >> $ConfigureLog/configure.log
#                read -p "########  Do you want to uninstall BCC? [y/n] :" bcc_ans
#
#                echo "########  User input for BCC uninstallation: " $bcc_ans >> $ConfigureLog/configure.log
#                export ans="yes"
#                export bcc_ans=`echo $bcc_ans | grep -i "^${ans}$" ||  echo $bcc_ans | grep -i "Y"`
#
#            if [ "$bcc_ans" = "" ]; then
#                        echo "########  User do not want BCC to be uninstalled."
#                        echo "########  User do not want BCC to be uninstalled." >> $ConfigureLog/configure.log
#            else
#                    if [ -f $bcc_location/uninstall.sh ]; then
#                        echo "########  Uninstalling the BCC now ..."
#                        echo "########  Uninstalling the BCC now ..." >> $ConfigureLog/configure.log
#                        $bcc_location/uninstall.sh | tee $ConfigureLog/bcc_uninstallation.log
#                    else
#                        echo "BCC uninstall.sh not found [ $bcc_location/uninstall.sh ]"
#                        echo "BCC uninstall.sh not found [ $bcc_location/uninstall.sh ]" >> $ConfigureLog/configure.log
#                    fi
#            fi
#fi

chown mailwall:bmi -R /opt/symantec/smg-sp/Scanner >/dev/null 2>&1
 echo ""
################check ends here##################################

## Etrack 3751034
## I don't know why this was put in, but I'm taking it out.
##   --   aborders
# chmod 777 /opt

#Ankur Nema: Bypassing Read
#read -p "########  Do you accept the End User License Agreement (Location: /opt/symantec/smg-sp/Scanner/EULA)(Default: n) [y/n] :" eula
echo "########  Do you accept the End User License Agreement (Location: /opt/symantec/smg-sp/Scanner/EULA)(Default: n) [y/n] : y"
eula="y"
echo "########  Do you accept the End User License Agreement (Location: /opt/symantec/smg-sp/Scanner/EULA)(Default: n) [y/n] : " >> $ConfigureLog/configure.log
echo "########  User input for EULA: " $eula >> $ConfigureLog/configure.log
export ans="yes"
export eula=`echo $eula | grep -i "^${ans}$" ||  echo $eula | grep -i "Y"`
if [ "$eula" = "" ]; then
echo "########  End User License Agreement (EULA) is not accepted."
echo "########  End User License Agreement (EULA) is not accepted." >> $ConfigureLog/configure.log
echo "########  Aborting the configuration."
echo "########  Aborting the configuration." >> $ConfigureLog/configure.log
exit
else
echo "########  End User License Agreement (EULA) is accepted."
echo "########  End User License Agreement (EULA) is accepted." >> $ConfigureLog/configure.log
echo "########  Configuration starts ..."
echo "########  Configuration starts ..." >> $ConfigureLog/configure.log
fi

export serverInstallation=`rpm -qa | grep  "SYMCmg-sp-server"`
export installed=`rpm -qa | grep "SYMCmg-sp-client"`

# if we're doing a 10.X upgrade, set av_scan based on the runner
if [ $upgrade_10x -ne 0 ]; then
    if grep '^Jjlu-controller' $backup_dir/runner.cfg > /dev/null 2>&1
    then
       av_scan="y"
    fi
fi

if [ -d /opt/symantec/smg-sp/Scanner/bm_ruleset.2.avsym.1 ]; then
    cp -R /opt/symantec/smg-sp/Scanner/bm_ruleset.2.avsym.1 /opt/symantec/smg-sp/Scanner/etc >> $ConfigureLog/configure.log
    chown -R mailwall:bmi  /opt/symantec/smg-sp/Scanner/etc/bm_ruleset.2.avsym.1
fi

if [ $upgrade_10x -eq 0 ]; then
# only do this if we are not upgrading from 10.X

mkdir -p /var/log/brightmail
LogDir=/var/log/brightmail
mkdir -p /var/spool/brightmail
SpoolDir=/var/spool/brightmail
TempDir=/tmp

if test  $upgrade -eq "0" ; then
# Ankur Nema. Bypassing temp directory and making it default.
#read -p  "########  Choose a \"temp\" working directory for LiveUpdate [ Default:  /tmp ]  : " TempDir
echo ########  Choose a \"temp\" working directory for LiveUpdate [ Default:  /tmp ]  : /tmp"

echo "########  Choose a \"temp\" working directory for LiveUpdate [ Default:  /tmp ]  :" >> $ConfigureLog/configure.log
#export TempDir=`echo "$TempDir" | sed 's/ //g'`
export TempDir=`echo "$TempDir" | sed 's/\/\//\//g'`
Status=$(checkpath "$TempDir")

if [ "$Status" != "Not a valid Path" ]  && [ "$Status" != "No input provided,  keeping the Default" ]; then
TempDir=$Status
Status=$(checkdirectory "$Status")

if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
        TempDir=$TempDir
else
        Status=$(checkpath "$Status")

        if [ "$Status" = "Not a valid Path" ]; then
                echo "######## " $Status
                TempDir=/tmp

                read -p  "########  Re-enter \"Temp\" Directory Path [ Default:  /tmp ]  " TempDir
                echo "########  Re-enter \"TempDir\" Directory Path [ Default  /tmp ]" >> $ConfigureLog/configure.log

                Status=$(checkdirectory "$TempDir")

                if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
                        TempDir=$TempDir
                else
                        Status=$(checkpath "$Status")
                                if [ "$Status" = "Not a valid Path" ]; then
                                        echo "########  Still not a valid Path, keeping the Default [ Default  /tmp ]"
                                        TempDir=/tmp
                                fi

                if [ "$Status" = "No input provided,  keeping the Default" ]; then
                echo "######## " $Status
                    TempDir=/tmp
                fi
            fi
        else
        if [ "$Status" = "No input provided,  keeping the Default" ]; then
           echo "######## " $Status
                TempDir=/tmp
           else
                        TempDir=$Status
           fi
fi
fi
else
        if [ "$Status" = "No input provided,  keeping the Default" ]; then
                echo "######## " $Status
                    TempDir=/tmp
        else
###########Recheck####################
                if [ "$Status" = "Not a valid Path" ]; then
                echo "######## " $Status

                read -p  "########  Re-enter \"Temp\" Directory Path [ Default:  /tmp ]  " TempDir
                echo "########  Re-enter \"TempDir\" Directory Path [ Default  /tmp ]" >> $ConfigureLog/configure.log

                Status=$(checkdirectory "$TempDir")

                if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
                        TempDir=$TempDir
                else
                        Status=$(checkpath "$Status")
                                if [ "$Status" = "Not a valid Path" ]; then
                                        echo "########  Still not a valid Path, keeping the Default [ Default  /tmp ]"
                                        TempDir=/tmp
                                fi

                if [ "$Status" = "No input provided,  keeping the Default" ]; then
                echo "######## " $Status
                    TempDir=/tmp
                fi
    fi
fi
#############Recheck done ############
fi
fi
######################### End Temp Directory check ###############################

##Ankur: Bypassing log directory input and keeping it default.
echo  "########  Enter \"Log\" Directory Path [ Default:  /var/log/brightmail ]  : /var/log/brightmail"
#read -p  "########  Enter \"Log\" Directory Path [ Default:  /var/log/brightmail ]  " LogDir
echo "########  Enter "Log" Directory Path [ Default  /var/log/brightmail ]" >> $ConfigureLog/configure.log

#export LogDir=`echo "$LogDir" | sed 's/ //g'`
#export LogDir=`echo "$LogDir" | sed 's/\\\//g'`

Status=$(checkdirectory "$LogDir")

if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
        echo "######## " $Status
        echo "########  Keeping the default : \"/var/log/brightmail\" ]"
        LogDir=/var/log/brightmail
else
        Status=$(checkpath "$Status")

        if [ "$Status" = "Not a valid Path" ]; then
                echo "######## " $Status
                LogDir=/var/log/brightmail

                read -p  "########  Re-enter \"Log\" Directory Path [ Default:  /var/log/brightmail ]  " LogDir
                echo "########  Re-enter "Log" Directory Path [ Default  /var/log/brightmail ]" >> $ConfigureLog/configure.log

                #export LogDir=`echo "$LogDir" | sed 's/ //g'`
                #export LogDir=`echo "$LogDir" | sed 's/\\\//g'`

                Status=$(checkdirectory "$LogDir")

                if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
                        echo "######## " $Status
                        echo "########  Keeping the default : \"/var/log/brightmail\" ]"
                        LogDir=/var/log/brightmail
                else
                        Status=$(checkpath "$Status")
                                if [ "$Status" = "Not a valid Path" ]; then
                                        echo "########  Still not a valid Path, keeping the Default [ Default  /var/log/brightmail ]"
                                        LogDir=/var/log/brightmail
                                fi

                if [ "$Status" = "No input provided,  keeping the Default" ]; then
                echo "######## " $Status
                LogDir=/var/log/brightmail
                fi
        fi
        else
           if [ "$Status" = "No input provided,  keeping the Default" ]; then
           echo "######## " $Status
           LogDir=/var/log/brightmail
           else
                        LogDir=$Status
           fi
fi
fi

###############################Code To Check spool Directory ################################

## Ankur: Bypassing spool directory check and keeping it to default
#read -p  "########  Enter \"Spool\" Directory Path [ Default:  /var/spool/brightmail ]  " SpoolDir

echo "########  Enter \"Spool\" Directory Path [ Default:  /var/spool/brightmail ]  : /var/spool/brightmail"
echo "########  Enter "Spool" Directory Path [ Default  /var/spool/brightmail ]" >> $ConfigureLog/configure.log

#export SpoolDir=`echo "$SpoolDir" | sed 's/ //g'`
#export SpoolDir=`echo "$SpoolDir" | sed 's/\\\//g'`

Status=$(checkdirectory "$SpoolDir")

if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
        echo "######## " $Status
        echo "########  Keeping the default : \"/var/spool/brightmail\" ]"
        SpoolDir=/var/spool/brightmail

else
        Status=$(checkpath "$Status")

        if [ "$Status" = "Not a valid Path" ]; then
                echo "######## " $Status
                SpoolDir=/var/spool/brightmail

                read -p  "########  Re-enter \"Spool\" Directory Path [ Default:  /var/spool/brightmail ]  " SpoolDir
                echo "########  Re-enter \"Spool\" Directory Path [ Default  /var/spool/brightmail ]" >> $ConfigureLog/configure.log

                #export SpoolDir=`echo "$SpoolDir" | sed 's/ //g'`
                #export SpoolDir=`echo "$SpoolDir" | sed 's/\\\//g'`

                Status=$(checkdirectory "$SpoolDir")

                if [ "$Status" = "Permissions to this directory wont be changed to \"mailwall:bmi\"" ]; then
                        echo "######## " $Status
                        echo "########  Keeping the default : \"/var/spool/brightmail\" ]"
                        SpoolDir=/var/spool/brightmail
                else
                        Status=$(checkpath "$Status")
                                if [ "$Status" = "Not a valid Path" ]; then
                                        echo "########  Still not a valid Path, keeping the Default [ Default  /var/spool/brightmail ]"
                                        SpoolDir=/var/spool/brightmail
                                fi

                if [ "$Status" = "No input provided,  keeping the Default" ]; then
                echo "######## " $Status
                SpoolDir=/var/spool/brightmail
                fi

                fi
        else
           if [ "$Status" = "No input provided,  keeping the Default" ]; then
           echo "######## " $Status
           SpoolDir=/var/spool/brightmail
           else
                        SpoolDir=$Status
           fi

fi
fi
fi
############################### Code ends for spool Directory ###############################

if [ "$installed" = "">  /dev/null 2>&1 ]; then
## Ankur: Defaulting AV Scanning installation to N.
#read -p "########  Do you want AV Scanning [ Default: n ] [y/n] :  " av_scan
echo "########  Do you want AV Scanning [ Default: n ] [y/n] :  n"
av_scan=""
echo "########  Do you want AV Scanning [ Default: n ] [y/n] :" >> $ConfigureLog/configure.log
echo "########  User Entered [ $av_scan ]" >> $ConfigureLog/configure.log
fi

export ans="yes"
export av_scan=`echo $av_scan | grep -i "^${ans}$" ||  echo $av_scan | grep -i "Y"`
if [ "$av_scan" = "" ]; then
echo "########  AV Scanning support not needed."
echo "########  AV Scanning support not needed." >> $ConfigureLog/configure.log
else
echo "########  AV Scanning support required."
echo "########  AV Scanning support required." >> $ConfigureLog/configure.log
fi

if [ "$installed" = "">  /dev/null 2>&1 ]; then
## Defaulting to N
#read -p "########  Will you use an HTTPS proxy? (Default: n) [y/n]" proxy
echo "########  Will you use an HTTPS proxy? (Default: n) [y/n] : n"
proxy=""
echo "########  Will you use an HTTPS proxy (Default: n) [y/n] : " >> $ConfigureLog/configure.log
echo "########  User Entered [ $proxy ]" >> $ConfigureLog/configure.log
export ans="yes"
export proxy=`echo $proxy | grep -i "^${ans}$" ||  echo $proxy | grep -i "Y"`
if [ "$proxy" = "" ]; then
echo "########  HTTPS proxy will not be used."
echo "########  HTTPS proxy will not be used." >> $ConfigureLog/configure.log
else
echo "########  The host and port should be given in the form \"host:port\"."
echo "########  If you need to specify a user name and password, you may give it in the form \"user:password\"."
echo "########  If a username and password are not required, leave it with the default value \"none:none\"."
echo "########  User will use HTTPS proxy." >> $ConfigureLog/configure.log
read -p  "########  Host:Port (DEFAULT: localhost:80) : " hostport
echo "########  Host:Port (DEFAULT: localhost:80) : $hostport" >> $ConfigureLog/configure.log
read -p "########  Username:Password (DEFAULT: none:none): " username_passwd
echo "########  Username:Password (DEFAULT: none:none): $username_passwd" >> $ConfigureLog/configure.log

if [ "$hostport" = "" > /dev/null 2>&1 ]; then
echo "########  No host:port is provided"
echo "########  No host:port is provided" >> $ConfigureLog/configure.log
echo "########  Keeping the default (DEFAULT: localhost:80)"
echo "########  Keeping the default (DEFAULT: localhost:80)" >> $ConfigureLog/configure.log
export host=localhost
export port=80
else
echo "########  host:port entered :   $hostport " >> $ConfigureLog/configure.log

######## host/ip and port validation starts here

export cnt=`grep -o ":" <<< "$hostport" | wc -l`
#echo cnt=$cnt
if [ $cnt -eq 1 ]; then
export host=`echo $hostport | cut -d ":" -f1`
#echo host=$host
port=`echo $hostport | cut -d ":" -f2`
export port1=$port
#echo port1=$port1
portt=`echo $port1 | sed 's/[[:digit:]]//g'`
if [ ! -z $portt ] ; then
  echo "########  Invalid PORT! Only digits, no commas, spaces, etc." >&2
  echo "########  Invalid PORT! Only digits, no commas, spaces, etc." >&2 >> $ConfigureLog/configure.log
  echo "########  keeping the default [Default: 80]"
  echo "########  keeping the default [Default: 80]" >> $ConfigureLog/configure.log
  port=80
else
export length=`echo $port1 | wc -c`
#echo $length
if [ $length -gt 6 ]; then
echo "########  Port greater than 5 digits, invalid port number, keeping the default"
echo "########  Port greater than 5 digits, invalid port number, keeping the default" >> $ConfigureLog/configure.log
echo "########  keeping the default [Default: 80]"
echo "########  keeping the default [Default: 80]" >> $ConfigureLog/configure.log
export port=80
else
port=$port1
fi
fi

if [  -z $port ] ; then
echo "########  PORT : NULL string"
echo "########  PORT : NULL string" >> $ConfigureLog/configure.log
echo "########  keeping the default [Default: 80]"
echo "########  keeping the default [Default: 80]" >> $ConfigureLog/configure.log
export port=80
fi

export ipaddr=$host

regex="\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b"

CHECK=$(echo $ipaddr | egrep $regex)
if [[ "$?" -eq 0 ]]
then
echo "########  IP address looks good"
echo "########  IP address looks good" >> $ConfigureLog/configure.log
else
echo -n "########  Incorrect IP address, "
echo -n "########  Incorrect IP address, " >> $ConfigureLog/configure.log
echo " Treating this as a hostname"
echo " Treating this as a hostname" >> $ConfigureLog/configure.log
#host=localhost
fi

if [  -z $ipaddr ] ; then
echo "########  HOST : NULL string, keeping the default"
echo "########  HOST : NULL string, keeping the default" >> $ConfigureLog/configure.log
export host=localhost
fi

else
echo "########  Not a valid host:port"
echo "########  Not a valid host:port" >> $ConfigureLog/configure.log
echo "########  Keeping the default [Default localhost:80]"
echo "########  Keeping the default [Default localhost:80]" >> $ConfigureLog/configure.log
export host=localhost
export port=80
fi
fi

###### host/ip and port ends here
if [ "$username_passwd" = "" > /dev/null 2>&1 ]; then
echo "########  No username and password is provided"
echo "########  No username and password is provided" >> $ConfigureLog/configure.log
echo "########  Keeping the default (none:none)"
echo "########  Keeping the default (none:none)" >> $ConfigureLog/configure.log
else
echo "########  username and password entered :   $username_passwd " >> $ConfigureLog/configure.log
fi

##### username and password validation

export cnt=`grep -o ":" <<< "$username_passwd" | wc -l`
#echo cnt=$cnt
if [ $cnt -eq 1 ]; then
export user=`echo $username_passwd | cut -d ":" -f1`
export passwd=`echo $username_passwd | cut -d ":" -f2`
#echo "Username = " $user
#echo "Password = " $passwd

if echo "$user" | egrep -q "[[:space:]]" ; then
echo "########  Username contains space"
echo "########  Username contains space" >> $ConfigureLog/configure.log
echo "########  Keeping the default"
echo "########  Keeping the default" >> $ConfigureLog/configure.log
export username=none
else
username=$user
fi

if [  -z $username ] ; then
echo "########  Username : a NULL string"
echo "########  Username : a NULL string" >> $ConfigureLog/configure.log
echo "########  Keeping the default"
echo "########  Keeping the default" >> $ConfigureLog/configure.log
export username=none
fi

if echo "$passwd" | egrep -q "[[:space:]]" ; then
echo "########  Password contains space"
echo "########  Password contains space" >> $ConfigureLog/configure.log
echo "########  Keeping the default"
echo "########  Keeping the default" >> $ConfigureLog/configure.log
export passwd=none
else
passwd=$passwd
fi

if [  -z $passwd ] ; then
echo "########  Passwd: a NULL string"
echo "########  Passwd: a NULL string" >> $ConfigureLog/configure.log
echo "########  Keeping the default"
echo "########  Keeping the default" >> $ConfigureLog/configure.log
export passwd=none
fi

else
#echo "########  Not valid inputs"
#echo "########  Not valid inputs" >> $ConfigureLog/configure.log
export username=none
export passwd=none
fi

##### username and password validation ends here

fi
fi

export TempDir=$TempDir
export LogDir=$LogDir
export SpoolDir=$SpoolDir

export TempDir1=$TempDir
export LogDir1=$LogDir
export SpoolDir1=$SpoolDir

touch file.TempDir1
touch file.LogDir1
touch file.SpoolDir1
echo $TempDir1 >  file.TempDir1
echo $LogDir1 > file.LogDir1
echo $SpoolDir1 > file.SpoolDir1

#find file.TempDir1 | xargs sed -i -e 's/\//\\\//g'
#find file.LogDir1 | xargs sed -i -e 's/\//\\\//g'
#find file.SpoolDir1 | xargs sed -i -e 's/\//\\\//g'

sed -e 's/\//\\\//g' file.TempDir1 >> file.TempDir1.1 && mv file.TempDir1.1 file.TempDir1
sed -e 's/\//\\\//g' file.LogDir1 >> file.LogDir1.1 && mv file.LogDir1.1 file.LogDir1
sed -e 's/\//\\\//g' file.SpoolDir1 >> file.SpoolDir1.1 && mv file.SpoolDir1.1 file.SpoolDir1

TempDir1="`cat file.TempDir1`"
LogDir1="`cat file.LogDir1`"
SpoolDir1="`cat file.SpoolDir1`"

#echo "LogDir1=" $LogDir1
#echo "SpoolDir1=" $SpoolDir1
if test  $upgrade -eq "0" ; then
echo ""
echo ""
echo "########  User specified paths: "
echo "########  User specified paths: "  >> $ConfigureLog/configure.log
echo "########  "temp"  :  $TempDir "
echo "########  "temp"  :  $TempDir " >> $ConfigureLog/configure.log
echo "########  "Log"   :  $LogDir "
echo "########  "Log"   :  $LogDir " >> $ConfigureLog/configure.log
echo "########  "Spool" :  $SpoolDir "
echo "########  "Spool" :  $SpoolDir " >> $ConfigureLog/configure.log
fi
if [ "$proxy" != "" ]; then
echo ""

echo ""
echo "########  hostname and port considered : "
echo "########  hostname and port considered : " >> $ConfigureLog/configure.log
echo "########  hostname :  $host"
echo "########  hostname :  $host" >> $ConfigureLog/configure.log
echo "########  port :  $port"
echo "########  port :  $port" >> $ConfigureLog/configure.log
echo ""
echo "########  Username and Password considered: "
echo "########  USername :  $username"
echo "########  Password :  $passwd"
echo "########  Username and Password considered: " >> $ConfigureLog/configure.log
echo "########  USername :  $username" >> $ConfigureLog/configure.log
echo "########  Password :  $passwd" >> $ConfigureLog/configure.log

echo ""

fi

echo ""
## Ankur: Bypassing this and continuing...
#read -p "#########  Press <ENTER> to continue: " entr
echo ""

chown -R  mailwall:bmi $LogDir $SpoolDir
chmod 776 $LogDir $SpoolDir

chown -R mailwall:bmi  /opt/symantec/smg-sp/Scanner/

osname=`uname`
arch=`uname -m`
installtype=`file /opt/symantec/smg-sp/Scanner/bin/bmserver |  awk  '{ print $3 }'`
###################################################################################################
cp /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml.bck
cp /opt/symantec/smg-sp/Scanner/etc/runner.cfg /opt/symantec/smg-sp/Scanner/etc/runner.cfg.bck
cp /opt/symantec/smg-sp/Scanner/etc/brightmail-env /opt/symantec/smg-sp/Scanner/etc/brightmail-env.bck

loadpoint="/opt/symantec/smg-sp/Scanner"
configloc="$loadpoint/etc/bmiconfig.xml"

if [ -f $configloc ]
then
    # Simple substitutions

    sed -i -e "s/\$INSTALLOS\\$/${osname}/g" $configloc
    sed -i -e "s/\$INSTALLARCH\\$/${arch}/g" $configloc
    sed -i -e "s/\$INSTALLTYPE\\$/${installtype}/g" $configloc
    sed -i -e 's/\$PRODUCTNAME\\$/SMG-SP/g' $configloc
    sed -i -e 's/\$LOGEXT\$//g' $configloc

    # Replaces '$/$' with '/' - I know - very ugly.  But necessary.

    sed -i -e 's#\$/\$#/#g' $configloc

    # There's '$' in the match pattern, '/' in the replacement string,
    #   and the replacement string contains a variable.  Ugly.  So we:
    # 1. use '#' as the sed 's' delimiter
    # 2. single quote the match pattern
    # 3. double quote the replacement string
    # This escapes everything properly.

    sed -i -e 's#\$LOADPOINT\$'"#${loadpoint}#g" $configloc
    sed -i -e 's#\$RULEDIR\$'"#${loadpoint}#g" $configloc
    sed -i -e 's#\$JAVAHOME\$'"#${loadpoint}/jre#g" $configloc
    sed -i -e 's#\$CONFIGDIR\$'"#${loadpoint}/etc#g" $configloc
    sed -i -e 's#\$STATSDIR\$'"#${loadpoint}/stats#g" $configloc
    sed -i -e "s/\$JLUTEMPDIR\\$/${TempDir1}/g" $configloc

    # These are cases where the script has already escaped the
    # path directory, so we stick with the quoting, escaping, and
    # default sed delimiter, rather than go back and change the stuff
    # that already works

    sed -i -e "s/\$SCANNER_LOGDIR\\$/${LogDir1}/g" $configloc
    sed -i -e "s/\$LOGDIR\\$/${LogDir1}/g" $configloc
    sed -i -e "s/\$SPOOLDIR\\$/${SpoolDir1}/g" $configloc

    # Now we start dealing with the special case substitutions, where
    # the replacement string depends on local conditions

    export arch=`uname -m`
    arch64=`file ${loadpoint}/bin/kicker | grep 64`

    # for the various 'KICKCOMMAND' variables:
    # There's '$' in the match pattern, '/' in the replacement string,
    #   and the replacement string contains a variable.  Ugly.  So we:
    # 1. use '#' as the sed 's' delimiter
    # 2. single quote the match pattern
    # 3. double quote the replacement string
    # This escapes everything properly.

    if [ "$arch64" != "" ]; then
        sed -i -e  's#\$JLU_KICKCOMMAND\$'"#${loadpoint}/bin/kicker ${loadpoint}/etc/bmiconfig.xml ${loadpoint}/jobs/bmserver/bmserver.pid#g" $configloc
    else
        sed -i -e  's#\$JLU_KICKCOMMAND\$'"#${loadpoint}/bin/kicker -s cleaner ${loadpoint}/etc/bmiconfig.xml ${loadpoint}/jobs/bmcleaner/bmcleaner.pid#g" $configloc
    fi

    sed -i -e  's#\$CONDUIT_KICKCOMMAND\$'"#${loadpoint}/bin/kicker ${loadpoint}/etc/bmiconfig.xml ${loadpoint}/jobs/bmserver/bmserver.pid#g" $configloc
    sed -i -e  's#\$KICKCOMMAND\$'"#${loadpoint}/bin/kicker ${loadpoint}/etc/bmiconfig.xml ${loadpoint}/jobs/bmserver/bmserver.pid#g" $configloc
    sed -i -e  's#\$SUBM_CONDUIT_KICKCOMMAND\$'"#${loadpoint}/bin/kicker -s conduit ${loadpoint}/etc/bmiconfig.xml ${loadpoint}/jobs/conduit/conduit.pid#g" $configloc

    sed -i -e 's/$SUBMITTEREMAIL\$//g' $configloc

    if [ "$installed" != "">  /dev/null 2>&1 ]; then
        sed -i -e 's/$CLIENT_PACKAGE_INSTALLED\$/true/g' $configloc
        sed -i -e 's/$SERVER_PACKAGE_INSTALLED\$/false/g' $configloc
    fi

    if [ "$serverInstallation" != "">  /dev/null 2>&1 ]; then
        sed -i -e 's/$CLIENT_PACKAGE_INSTALLED\$/false/g' $configloc
        sed -i -e 's/$SERVER_PACKAGE_INSTALLED\$/true/g' $configloc
    fi

    sed -i -e 's/$CLIENT_PACKAGE_INSTALLED\$/true/g' $configloc
    sed -i -e 's/$SERVER_PACKAGE_INSTALLED\$/true/g' $configloc

fi

if [ "$installed" != "">  /dev/null 2>&1 ]; then
if test  $upgrade -eq "0" ; then
## Ankur: Bypassing this read and getting FQDN
#read -p "########   Enter IP Address or Hostname of the server : " ServerIP
serverIP=`hostname --long`
echo "########   Enter IP address or Hostname of the server : " >> $ConfigureLog/configure.log
echo "########   Server IP adress or Hostname Entered is : [ $ServerIP ]" >> $ConfigureLog/configure.log

find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e  "s/\$SERVER\\$/${ServerIP}/g"
echo "########  Server IP or Hostname entered in bmiconfig.xml : [ $ServerIP ] " >> $ConfigureLog/configure.log
fi

else
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e  's/$SERVER\$/localhost/g'
echo "########  Server IP or Hostname entered in bmiconfig.xml : [ localhost ] " >> $ConfigureLog/configure.log
fi

if [ "`echo $proxy | grep -i "^y"`" != "" ]; then

find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e 's/proxy enabled=\"false\"/proxy enabled=\"true\"/g'
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e "s/server host=\"none\"/server host=\"${host}\"/g"
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e "s/port=\"false\"/port=\"${port}\"/g"

##### code for adding usernam and passwd in bmiconfig.xml ####
######## first clean them up because they might have been added by previous run
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e '/<username/d' -e '/<password/d'

line_no="`grep -n '</proxy>$' /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml | cut -f1 -d: | tail -n 1`" ; echo "$line_no" > /dev/null 2>&1
export line1=`expr $line_no - 1`

[[ -n "$line1" ]] && sed -i "$line1"'s#$#\n            <username>'"${username}"'</username>\n                <password plain="true">'"${passwd}"'</password>#' /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml

##### End code for username and passwd
else
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e 's/proxy enabled="[^"]*"/proxy enabled="false"/g'
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e '/proxy enabled/s/server host="[^"]*"/server host=\"none\"/g'
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e '/proxy enabled/s/port="[^"]*"/port=\"false\"/g'

find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e '/<username/d' -e '/<password/d'
fi

echo "########  \"bmiconfig.xml\" configured successfully  [Location: /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml ] "
echo "########  \"bmiconfig.xml\" configured successfully  [Location: /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml ] " >> $ConfigureLog/configure.log

# end of 'if upgrade_10x == 0' block
fi

if [ "$installed" = "">  /dev/null 2>&1 ]; then

find /opt/symantec/smg-sp/Scanner/sbin/register.sh  -type f -print0 | xargs -0 -n 1 sed -i -e 's#\$USER_INSTALL_DIR\$#/opt/symantec/smg-sp/Scanner#g'
find /opt/symantec/smg-sp/Scanner/sbin/register.sh  -type f -print0 | xargs -0 -n 1 sed -i -e 's/\$DOLLAR\$/$/g'
echo "########  \"register.sh\" configured successfully [Location: /opt/symantec/smg-sp/Scanner/sbin/register.sh ]"
echo "########  \"register.sh\" configured successfully [Location: /opt/symantec/smg-sp/Scanner/sbin/register.sh ]" >>  $ConfigureLog/configure.log

fi

find /opt/symantec/smg-sp/Scanner/etc/brightmail-env  -type f -print0 | xargs -0 -n 1 sed -i -e 's/$LOADPOINT\$/\/opt\/symantec\/smg-sp\/Scanner/g'
echo "########  \"brightmail-env\" configured successfully [Location: /opt/symantec/smg-sp/Scanner/etc/brightmail-env ]"
echo "########  \"brightmail-env\" configured successfully [Location: /opt/symantec/smg-sp/Scanner/etc/brightmail-env ]" >>  $ConfigureLog/configure.log

if [ $upgrade_10x -eq 0 ]; then
# only do this if we are not upgrading from 10.X

find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/$LOADPOINT\$/\/opt\/symantec\/smg-sp\/Scanner/g'

if [ -f /opt/symantec/smg-sp/Scanner/etc/runner-client.cfg ]; then
find /opt/symantec/smg-sp/Scanner/etc/runner-client.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/$LOADPOINT\$/\/opt\/symantec\/smg-sp\/Scanner/g'
fi

if [ "$installed" != "">  /dev/null 2>&1 ]; then
find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Jbmserver/#Jbmserver/g'
find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Jconduit/#Jconduit/g'
find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Jjlu-controller/#Jjlu-controller/g'
fi

 if [ "$av_scan" = "" ]; then
 find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Jbmcleaner/#Jbmcleaner/g'
 find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Javoop/#Javoop/g'
 find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Jjlu-controller/#Jjlu-controller/g'
 else
 find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/#Jbmcleaner/Jbmcleaner/g'
 find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/#Javoop/Javoop/g'
 find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/#Jjlu-controller/Jjlu-controller/g'
 fi

if [ "$serverInstallation" != "">  /dev/null 2>&1 ]; then
find /opt/symantec/smg-sp/Scanner/etc/runner.cfg -type f -print0 | xargs -0 -n 1 sed -i -e 's/Jbmifilter/#Jbmifilter/g'
fi

# end of 'if upgrade_10x == 0' block
fi

find /opt/symantec/smg-sp/Scanner/sbin/controller.sh -type f -print0 | xargs -0 -n 1 sed -i -e 's#$LOADPOINT\$#/opt/symantec/smg-sp/Scanner#g'
find /opt/symantec/smg-sp/Scanner/sbin/controller.sh -type f -print0 | xargs -0 -n 1 sed -i -e 's/$USER/mailwall/g'

echo "########  \"controller.sh\" configured successfully [Location: /opt/symantec/smg-sp/Scanner/sbin/controller.sh ]"
echo "########  \"controller.sh\" configured successfully [Location: /opt/symantec/smg-sp/Scanner/sbin/controller.sh ]" >>  $ConfigureLog/configure.log

if [ $upgrade_10x -eq 0 ]; then
# only do this if we are not upgrading from 10.X

########## code to modify /etc/init.d/mailwall script
if [ -f /etc/init.d/mailwall ]
then
    sed -i -e 's#$USER_INSTALL_DIR\$#/opt/symantec/smg-sp/Scanner#g' /etc/init.d/mailwall
    sed -i -e 's/$DOLLAR\$/$/g' /etc/init.d/mailwall
    sed -i -e 's#$BIN\$#/bin#g' /etc/init.d/mailwall
    sed -i -e 's/$PSCMD\$/cmd/g' /etc/init.d/mailwall
    sed -i -e 's#$/\$#/#g' /etc/init.d/mailwall
fi


if [ "$serverInstallation" != "">  /dev/null 2>&1 ]; then
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$SERVERONLY\$//g'
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$CLIENTONLY\$/#/g'
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$COMPLETEONLY\$/#/g'
fi

if [ "$installed" != "">  /dev/null 2>&1 ]; then
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$CLIENTONLY\$//g'
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$SERVERONLY\$/#/g'
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$COMPLETEONLY\$/#/g'
fi

if [ "$installed" = "" ] && [ "$serverInstallation" = "" ]; then
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$SERVERONLY\$//g'
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$CLIENTONLY\$//g'
find  /etc/init.d/mailwall -type f -print0 | xargs -0 -n 1 sed -i -e 's/$COMPLETEONLY\$//g'
fi

echo "########  \"mailwall\" configured successfully [Location: /etc/init.d/mailwall ]"
echo "########  \"mailwall\" configured successfully [Location: /etc/init.d/mailwall ]" >>  $ConfigureLog/configure.log
echo ""

# end of 'if upgrade_10x == 0' block
fi

echo "########   Create Link :" >>  $ConfigureLog/configure.log
if [ ! -f /etc/rc0.d/K99mailwall ] ; then
ln -s /etc/init.d/mailwall /etc/rc0.d/K99mailwall >>  $ConfigureLog/configure.log
if [ $? = 0 ];then
echo "########  Softlink \"/etc/rc0.d/K99mailwall\" created successfully" >>  $ConfigureLog/configure.log
fi
else
echo "########   Softlink \"/etc/rc0.d/K99mailwall\" exists" >>  $ConfigureLog/configure.log
fi

if [ ! -f /etc/rc3.d/S99mailwall ] ; then
ln -s /etc/init.d/mailwall /etc/rc3.d/S99mailwall >>  $ConfigureLog/configure.log
if [ $? = 0 ];then
echo "########  Softlink \"/etc/rc3.d/S99mailwall\" created successfully" >>  $ConfigureLog/configure.log
fi
else
echo "########   Softlink \"/etc/rc3.d/S99mailwall\" exists" >>  $ConfigureLog/configure.log
fi

if [ -d /etc/rc5.d ]; then
if [ ! -f /etc/rc5.d/S99mailwall ] ; then
ln -s /etc/init.d/mailwall /etc/rc5.d/S99mailwall >>  $ConfigureLog/configure.log
if [ $? = 0 ];then
echo "########  Softlink \"/etc/rc5.d/S99mailwall\" created successfully" >>  $ConfigureLog/configure.log
fi
else
echo "########   Softlink \"/etc/rc5.d/S99mailwall\" exists" >>  $ConfigureLog/configure.log
fi
fi

if [ $upgrade_10x -eq 0 ]; then
# only do this if we are not upgrading from 10.X

export av_scan=`echo $av_scan | grep -i "^${ans}$" ||  echo $av_scan | grep -i "Y"`
if [ "$av_scan" != "" ]; then

find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e 's/service name=\"virus\" enabled=\"false\"/service name=\"virus\" enabled=\"true\"/g'

find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e 's/\"libantivirus\" enabled=\"false\"/\"libantivirus\" enabled=\"true\"/g'

find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e '/default-virus-policy/s/enabled=\"false\"/enabled=\"true\"/g'

else
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e 's/service name=\"virus\" enabled=\"true\"/service name=\"virus\" enabled=\"false\"/g'
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e 's/\"libantivirus\" enabled=\"true\"/\"libantivirus\" enabled=\"false\"/g'
find /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -type f -print0 | xargs -0 -n 1 sed -i -e '/default-virus-policy/s/enabled=\"true\"/enabled=\"false\"/g'
fi

# end of 'if upgrade_10x == 0' block
fi

export av_scan=`echo $av_scan | grep -i "^${ans}$" ||  echo $av_scan | grep -i "Y"`
if [ "$av_scan" != "" ]; then

    echo "########   Installing JLU ..."
    cd /opt/symantec/smg-sp/Scanner/jre
    /opt/symantec/smg-sp/Scanner/jre/bin/java -classpath /opt/symantec/smg-sp/Scanner/jre/bin/jlu.jar com.symantec.liveupdate.Installer >  /dev/null 2>&1
    echo "########   JLU installation over !!!"
    cd - >  /dev/null 2>&1
fi

echo ""
echo "" >> $ConfigureLog/configure.log
echo "########   SYMCmg-sp : Configuration is completed  successfully"
echo "########   SYMCmg-sp : Configuration is completed  successfully" >> $ConfigureLog/configure.log
echo ""
echo "" >> $ConfigureLog/configure.log

####################################################################################################

if [ "$installed" = "">  /dev/null 2>&1 ]; then

if [ -f /opt/symantec/smg-sp/Scanner/etc/cert.pem ]; then

echo "########   /opt/symantec/smg-sp/Scanner/etc/cert.pem file is present so no need to re-register the product" >>  $ConfigureLog/configure.log
else

##Ankur: Bypassing manual entry of licence file location. Using location: /opt/symantec/smg-sp/Scanner/appliance-3-28-2022.slf
#read -p  "########   Enter Symantec license file path to register the product  :  " license_file_loc
echo "Bypassing SMG-SP registration from configure.sh. Will do after replacing bmiconfig.xml with mailwall specific config file."
license_file_loc=""
echo "########   Enter Symantec license file path to register the product  :  " >>  $ConfigureLog/configure.log
echo "########   User input for License file path : [ $license_file_loc ]" >>  $ConfigureLog/configure.log


if [ "$license_file_loc" = ""  >  /dev/null 2>&1 ]; then
echo "########   No path is provided."
echo "########   No path is provided." >>  $ConfigureLog/configure.log
else
if [ -f $license_file_loc ]; then
echo "########   License file found at : $license_file_loc"
echo "########   License file found at : $license_file_loc" >>  $ConfigureLog/configure.log
else
echo "########   License file [NOT] found at : $license_file_loc"
echo "########   License file [NOT] found at : $license_file_loc" >>  $ConfigureLog/configure.log
echo "########   Now try registration Manually [/opt/symantec/smg-sp/Scanner/sbin/register.sh -c config_file -l license_file]"
echo "########   Now try registration Manually [/opt/symantec/smg-sp/Scanner/sbin/register.sh -c config_file -l license_file]" >>  $ConfigureLog/configure.log
echo "########   Configuration log file located at : $ConfigureLog/configure.log "
exit
fi
fi

/usr/sbin/setenforce 0 >/dev/null 2>&1

#echo "########   Command is : [ /opt/symantec/smg-sp/Scanner/sbin/register -c /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -l $license_file_loc] "
export LD_LIBRARY_PATH=/opt/symantec/smg-sp/Scanner/lib:$LD_LIBRARY_PATH
/opt/symantec/smg-sp/Scanner/sbin/register -c /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml -l $license_file_loc
out=$?
if [ $out = "0" ];then
echo "########   Registration successful." >>  $ConfigureLog/configure.log
else
echo "########   Registration failed." >> $ConfigureLog/configure.log
echo "########   Operating system error code : $out " >>  $ConfigureLog/configure.log
echo "########   Now try registration Manually [/opt/symantec/smg-sp/Scanner/sbin/register.sh -c config_file -l license_file]"
echo "########   Now try registration Manually [/opt/symantec/smg-sp/Scanner/sbin/register.sh -c config_file -l license_file]" >>  $ConfigureLog/configure.log
fi
fi
fi
echo "########   Configuration log file located at : $ConfigureLog/configure.log "


        if [ -f /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_linux.tar ];then
        rm -rf /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_linux.tar >  /dev/null 2>&1
        fi

        if [ -f /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_64_linux.tar ];then
        rm -rf /opt/symantec/smg-sp/Scanner/bin/CONFUP_106_x86_64_linux.tar >  /dev/null 2>&1
        fi

if [ -f /etc/jlumachine.id ]; then
chmod 664  /etc/jlumachine.id >  /dev/null 2>&1
fi
if [ -f /etc/liveupdate.conf ]; then
chmod 664  /etc/liveupdate.conf  >  /dev/null 2>&1
fi
if [ -f /etc/Product.Catalog.JavaLiveUpdate ]; then
chmod 664 /etc/Product.Catalog.JavaLiveUpdate  >  /dev/null 2>&1
fi


rm -rf file.TempDir1 file.LogDir1 file.SpoolDir.1 file.SpoolDir1 >  /dev/null 2>&1
