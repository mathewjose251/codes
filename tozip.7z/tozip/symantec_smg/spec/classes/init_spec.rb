require 'spec_helper'
describe 'spamlab_mailwall' do
  context 'with default values for all parameters' do
    it { should contain_class('spamlab_mailwall') }
  end
end
