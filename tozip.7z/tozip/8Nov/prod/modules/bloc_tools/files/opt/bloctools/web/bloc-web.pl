# Configuration file for bloc-web.  This file can contain arbitrary perl, as
# long as it returns a hashref at the end.

my $home = app->home->to_string;


{
    # Web server definition when running hypnotoad (morbo ignores this)
    hypnotoad => {

        # See Mojo::Server::Daemon for examples of listen's syntax
        listen => [ 'http://*:8080', 'https://*:8443' ],

        # Hardwired in a couple different places, so don't change it
        pid_file => "$home/run/bloc-web-httpd.pid",

        clients => 1,    # Fork per-request.  This cannot be raised.
        workers => 4,    # 2 workers per CPU is typical
        spare   => 2,
	inactivity_timeout => 60, # seconds until inactive connections closed

        # Values here are defaults

        #accepts => 10_000,  # restart at random interval between 5K-10K requests
        #backlog => 128,     # can't exceed SOMAXCONN, usually 128
        #clients => 1000,    # max concurrent clients
        #graceful_timeout => 120,  # time in seconds stopping workers have to stop
        #heartbeat_interval => 5,  # interval in seconds to ping workers
        #heartbeat_timeout => 30,  # seconds before killing nonresponsive workers
        #inactivity_timeout => 15, # seconds until inactive connections closed
        #pid_file => "$home/app/hypnotoad.pid" # filename to place pid file
        #proxy => 1,                # activate reverse proxy support
        #requests => 100,           # max keep-alive requests per connection
        #spare => 2,                # pre-fork this many idle instances
        #upgrade_timeout => 180,    # timeout for hot redeployment
        #workers => 4,              # spawn up to this many workers
    },

}
