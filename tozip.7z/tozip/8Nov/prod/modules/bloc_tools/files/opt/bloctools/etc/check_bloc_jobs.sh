#!/bin/bash

#This  script will check Only when the new bloc instance is created 
#and there is no Jobs added to bloc-db for that   host

varJobchk=$(/opt/bloctools/bin/bloc_control --host=`hostname` status)
varGetHost=$(grep bmi_approle /etc/facter/facts.d/brightmail.txt|cut -f2 -d '=')


if [ "$varJobchk" = "No jobs found!" ]
then
## check  text file where  the jobs list is  stored  and start  jobs'

varJobListFile='/opt/bloctools/etc/bloc_jobs_list'

#extract the jobs from list
varJobsToAdd=$(/bin/sed -n "s/.*$varGetHost//p"  $varJobListFile)
  for jobname  in $varJobsToAdd
  do
  /opt/bloctools/bin/bloc_control --job=$jobname --host=`hostname` add
  /opt/bloctools/bin/bloc_control --job=$jobname --host=`hostname` start --wait

  done
fi
 touch /opt/bloctools/etc/Puppet_bloc_job_done

