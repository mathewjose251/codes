BLOC Module readme

Creating the BLOC Puppet recipe

What  to  achieve  ::
 we need to define the final state of the system in easy to use language in the puppet  manifest
  that later can be tested and executed to achieve desired level of consistency.

So the desired level of consistency  depends on our needs  is described as below in terms of puppet.

−  BLOC user and group to be present in the system.
−  BLOC production YUM repository  to present in the system.

−  the hostname to be set on the log configs
−  to run nagios monitoring plugins in the system
−  relevant sshd configurations copied to the system.

−  to have sudoers files pulled to the system.

-   to have the  relevant NFS mount  points available in the system

−  BLOC dependency  rpms to be installed on our machines
−  BLOC rpms to be installed on our machines
−  to set custom BLOC configurations with relevant bloc-config
−  to set custom BLOC email set up with relevant blocrpms
−  BLOC  tools to be constantly running
−  BLOC status service to be constantly running
-  whenever a new host is created via autoscaling  it should run the bloc_control command to add
   its own jobs to the jobs table in bloc db and start the jobs in a streamlined fashion



-   all out logs are available at log server.
-   the crontabs and logroataion is working as expected  .

Luckily we do not have to write everything from scratch, the code  from staging is  reusable with Hiera data lookup .

We use the definitive language that puppet provides  (DSL) along with the classes and functions which we created .



While puppet agent runs on   bt servers

We use run  stages  via a base module along with and role and profiles via Hiera.

stages
----
Stage[one] :Base Module

             :: users,::Ec2configs
             YUM  Module

Stage[two] :Puppet module

Stage[three]:sudoers module

            :nagios install module

Stage[Main] :nrpe module
            :system module (wip)
            nfs module
            bloc_tools module
            bt_mail module
Stage[six] :crontab module

----
Dependency path along modules

Stage[three]/before: subscribes to Stage[four]
Stage[two]/before: subscribes to Stage[three]
Stage[one]/before: subscribes to Stage[two]
Stage[six]/require: subscribes to Stage[main]


role and profiles via Hiera.

The systems role is decided by the hiera class lookup which is defined as below.

hierarchy:
- name: "node based data(yaml version)"
  path: "hostname/%{facts.hostname}"
- name: "App_role based data(yaml version)"
  path: "bmi_approle/%{::bmi_approle}.yaml"
- name: "Per-node data (yaml version)"
  path: "bmi_classes/%{::bmi_classes}.yaml"
- name: "common  data(yaml version)"
  path: "common.yaml"

  in bloc systems we use only "bmi_classes" for data lookups.So Our  data  file is located

  in data/bmil_classes folder.

  The rest of the  details  ( as they have sensitive data ) will be included in the detailed readme and how to files in the repo.

