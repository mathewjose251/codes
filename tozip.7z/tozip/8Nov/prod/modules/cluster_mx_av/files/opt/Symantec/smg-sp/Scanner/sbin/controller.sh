#!/bin/sh
#
#   Copyright 2004 Symantec Corporation.  All Rights Reserved.
#
#   This product is protected by U.S. and International Copyright and
#   distributed under license restricting copying and distributing.
#
#   ALL SOFTWARE, SERVICES, AND DOCUMENTATION PRODUCED FROM THIS CODE
#   ARE BEING PROVIDED "AS IS". SYMANTEC CORPORATION (SYMANTEC) MAKES NO
#   REPRESENTATION OR WARRANTY OF ANY KIND WHETHER EXPRESS OR IMPLIED
#   (EITHER IN FACT OR BY OPERATION OF LAW) WITH RESPECT TO THE SOFTWARE
#   GENERATED FROM THIS CODE.  SYMANTEC EXPRESSLY DISCLAIMS ALL IMPLIED
#   WARRANTIES, INCLUDING WITHOUT LIMITATION, THOSE OF NONINFRINGEMENT,
#   MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. SYMANTEC DOES NOT
#   WARRANT THAT THIS CODE WILL BE ERROR-FREE, SECURE, OR UNINTERRUPTED.
#
#   File Name       :   controller.sh
#   Description     :   controls components in a mailwall
#   Original Author :   Mark Lim
#   Current Owner   :   Shari Brooks
#   RCSID           :   $Id: controller.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
#
# *** This is the reference file.  The real file picked up by the
# *** installer is controller.sh.zerog
# *** Any modifications to this file will not show up in the product!

#return values:
OK=0
UNKNOWN_COMMAND=11
UNKNOWN_COMPONENT=12
KICK_FAILED=13
UNKNOWN_OS=14
RUNNING=0
NOT_RUNNING=1
ENABLED=0
NOT_ENABLED=1

#constants
LOADPOINT=/opt/symantec/smg-sp/Scanner
USER=mailwall
#rm temp1
PID=0 #global variable for the pid of a process we looked for.
if [ "$2" = "bmifilter" ]; then
RUNNER_CFG=${LOADPOINT}/etc/runner-client.cfg
else
RUNNER_CFG=${LOADPOINT}/etc/runner.cfg
fi

# 'enable' or 'disable' 'start' 'stop' 'kick' 'isenabled' 'isactive'
command=$1

#component 'conduit' 'bmserver' 'bmifilter' 'bmcleaner' 'jlu-controller'
component=$2

#detect OS and set OS specific differences.

OSYS=`uname -s`

if [ "${OSYS}" = "Linux" ]; then
    PSFU="ps -wwfu"
elif [ "${OSYS}" = "SunOS" ]; then
    PSFU="ps -fu"
else
    echo "Unknown operating system: "$OSYS
    exit $UNKNOWN_OS
fi

BMCLEANER_ARCH=64
file ${LOADPOINT}/bin/bmcleaner|grep '32-bit' 1> /dev/null
rv=$?
if [ $rv -eq 0 ]; then BMCLEANER_ARCH=32; else BMCLEANER_ARCH=64; fi

##
#
# usage()
#
# prints the usage to stdout
#
usage() {
    echo "Usage: $0 command component"
    echo "command is one of 'enable', 'disable', 'start', 'stop', 'kick', 'isenabled', 'isactive'"
    echo "component is one of 'bmserver', 'conduit', 'bmifilter', 'bmcleaner' 'jlu-controller'"
}

##
# getPID()
#
# retrieves the PID of a process running out of the loadpoint
#
# scribbles the PID into $PID
#
# $1 MUST be the program name
#

getPID() {
    process=$1    
    
    case $process in
        conduit|bmserver|bmifilter|bmcleaner|jlu-controller) 
#            $PSFU mailwall | grep ${LOADPOINT}/bin/$process |grep -v grep > temp2
            PID=`$PSFU mailwall |grep ${LOADPOINT}/bin/$process |grep -v grep | sed -e 's/ [ ]*/ /g' -e 's/^ [ ]*//' | cut -d" " -f2 | sort -r -n | head -1`
           PID=${PID:=0}
;;

        runner) 
#    rm temp3
#            $PSFU mailwall | grep ${LOADPOINT}/sbin/$process |grep -v grep > temp3
#            if [ ! -s temp3 ]; then rm temp3; PID=0; return 0; fi
                    #turn all multiple whitespace blocks into one space
            PID=`$PSFU mailwall |grep ${LOADPOINT}/sbin/$process |grep -v grep | sed -e 's/ [ ]*/ /g' -e 's/^ [ ]*//' | cut -d" " -f2 | sort -r -n | head -1`
#            rm temp3
	PID=${PID:=0}
            ;;

        *) 
            echo "getPID: Unknown process"
            ;;

    esac
}


##
# kick()
#
# sends a "reload" message to a runner controlled process
# This is used to reconfigure processes
#
# returns $OK on success
#         $KICK_FAILED on failure

kick() {
    . ${LOADPOINT}/etc/brightmail-env
    mycomponent=$1

    case $mycomponent in

        conduit|bmserver) 
            ${LOADPOINT}/bin/kicker -m reload -s $1 ${LOADPOINT}/jobs/$mycomponent/$mycomponent.pid
            ;;

        bmifilter)  
            getPID bmifilter
            if [ $PID -gt 0 ]; then kill -HUP $PID; else exit $OK; fi
            ;;
        bmcleaner)
            if [ $BMCLEANER_ARCH -eq 32 ]; then
                ${LOADPOINT}/bin/kicker -m reload -s cleaner ${LOADPOINT}/jobs/$mycomponent/$mycomponent.pid
            else
                echo "kick is not supported for $mycomponent"	
            fi
            return $OK
            ;; #do nothing as this is a short-lived process.
        jlu-controller)
            echo "kick is not supported for $mycomponent"
            return $OK
            ;; #do nothing as this is a short-lived process.

        *) 
            echo "kick: Unknown process"
            return $KICK_FAILED
            ;;
    esac
}

##
#  main()
#

if [ $# -lt 2 ]; then usage; exit $OK; fi


if [ \( $component = "bmserver" \)  -o \( $component = "conduit" \) -o \( $component = "bmifilter" \) -o \( $component = "bmcleaner" \) -o \( $component = "jlu-controller" \) ]; then

    case $command in

        enable)  
            cp $RUNNER_CFG $RUNNER_CFG.bak
            sed -e "/J$component/s/#//g" $RUNNER_CFG.bak > $RUNNER_CFG
            ;;

        disable) 
            cp $RUNNER_CFG $RUNNER_CFG.bak
            sed -e "/J$component/s/^/#/"  $RUNNER_CFG.bak > $RUNNER_CFG
            ;;

        start)  
            grep ${LOADPOINT}/bin/$component $RUNNER_CFG |grep "^#" 1> /dev/null
            rv=$?
            if [ $rv -eq 0 ]; then exit $OK; else rm ${LOADPOINT}/jobs/$component/$component.stop 2> /dev/null; fi
            CNTR=1
            while [ $CNTR -lt 64  ]; do
                getPID $component
                if [ $PID -ne 0 ]; then
                    break
                fi
                sleep 1
                CNTR=`expr $CNTR + 1`
            done
            if [ $CNTR -ge 64 ]; then
                exit $NOT_OK
            fi
            exit $OK
            ;;

        stop)   
            touch ${LOADPOINT}/jobs/$component/$component.stop
            CNTR=1
            while [ $CNTR -lt 64  ]; do
                getPID $component
                if [ $PID -eq 0 ]; then
                    break
                fi
                sleep 1
                CNTR=`expr $CNTR + 1`
            done
            if [ $CNTR -ge 64 ]; then
                exit $NOT_OK
            fi
            ;;

        kick)  
            kick $component
            ;;

        isactive) 
            getPID $component
            if [ $PID -eq 0 ]; then exit $NOT_RUNNING; else exit $RUNNING; fi
            ;;
        isenabled) 
            grep J$component $RUNNER_CFG |grep "^#" 1> /dev/null
            rv=$?
            if [ $rv -eq 0 ]; then exit $NOT_ENABLED; else exit $ENABLED; fi
            ;;

        *) 
            echo "Unknown command" 
            exit $UNKNOWN_COMMAND;;
    esac
else
    echo "Unknown component"
    exit $UNKNOWN_COMPONENT;
fi
