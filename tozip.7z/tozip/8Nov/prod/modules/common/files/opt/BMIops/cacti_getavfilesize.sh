#!/bin/bash
# cacti_getavfilesize.sh - By: Beam Davis (Beam_Davis@symantec.com)  (01/06/11)
#
# Usage: cacti_getavfilesize.sh <Path> ...
#        cacti_getavfilesize.sh [-h|-v]
#
# Exit Statuses:
#
#  0 = Normal
#  1 = Invalid or missing command line argument
#  2 = Unable to get file size of one or more specified paths
# 10 = -h or -v argument specified on command line
#
# Major Revision History:
#
# 01/05/11 -	First production version.
#
# Subroutines.
#
execerrmsg() {
# Usage: execerrmsg <Message> [-F]
#
# -F =	Fatal error message
	echo -e "$strname: $(if [ "$2" = "-F" ];then echo "FATAL ";fi)ERROR: $1" 1>&2
}
execinvarg() {
# Usage: execinvarg
	execerrmsg "Invalid or missing command line argument." -F
	exit 1
}
execusage() {
# Usage: execusage
	cat <<EOM
Usage: $strname <Path> ...
       $strname [-h|-v]
EOM
}
execverinfo() {
# Usage: execverinfo
	echo "$strname - By: Beam Davis (Beam_Davis@symantec.com)$(echo -n "                          "|/bin/dd bs=1 count=$((26-${#strname})) 2>/dev/null)($strverdate)"
}
#
# Constants.
#
typeset -i intf=0
typeset -i into=1
strname="$(basename "$0")"
strverdate="01/05/11"
#
# Initializations.
#
unset strfilesize
unset strout
unset strsp
#
# Main routine.
#
case "$*" in
	"")	execinvarg;;
	-h)	execusage
		exit 10;;
	-v)	execverinfo
		exit 10;;
esac
for strfn in "$@"
do
	intf=intf+1
	if [ -s "$strfn" ]
	then
		strfilesize[$intf]="$(/bin/ls -l --color=never "$strfn"|/bin/awk '{print $5}')"
	elif [ ! -d "$strfn" ]
	then
		strfilesize[$intf]="0"
	fi
done
while [ $into -le $intf ]
do
	if [ -z "${strfilesize[$into]}" ]
	then
		execerrmsg "Unable to get file size of one or more specified paths." -F
		exit 2
	else
		if [ $into -le 1 ]
		then
			# Cacti has issues with "filesize1"!
			strout="filesize:${strfilesize[1]}"
		else
			strout="$strout filesize$into:${strfilesize[$into]}"
		fi
	fi
	into=into+1
done
echo -n "$strout"


# # #  End of cacti_getavfilesize.sh  # # #

