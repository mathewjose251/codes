#!/opt/perl/bin/perl

# grab the latest statsigs if we're the "primary" ard system (which
# Sean/Sandy have defined as "supposed to be running list_builder")

# $Id: fetch_statsigs.pl,v 1.1 2018/10/30 10:11:58 mathew Exp $
# $Name:  $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/opt/BMIops/fetch_statsigs.pl,v $

BEGIN {
    $ENV{BLOC_CONFIG_FILE} = '/space/orabloc/server/conf/bloc-config';
    require '/space/orabloc/server/conf/inc.pl';
}

use BLOC::Job;

use HTTP::Request;
use HTTP::Date;
use IO::File;
use LWP::UserAgent;

my ($job) = BLOC::Job->retrieve_multiple(
    host_name => BLOC::Job::hostname(),
    job_name  => 'list_builder'
);

exit 0 unless $job and $job->should_be_running;

# the full and the update are the same file, so we only really have to
# look for the full.  But we don't have a VIP, so cycle through all of
# the possible servers until we get a response.  Yes, this is dumb,
# but this is statsig "paper."
my @URLS   = qw{
    http://www01.sac.brightmail.com:8080/statsigs
    http://www02.sac.brightmail.com:8080/statsigs
    http://www01.tuc.brightmail.com:8080/statsigs
    http://www02.tuc.brightmail.com:8080/statsigs
};

my @FILES = qw{
  /space/orabloc/htdocs/aztec/rules2/statsigs
  /space/orabloc/htdocs/aztec/rules2/statsigs.update
  /space/orabloc/htdocs/aztec/rules2litea/statsigs
  /space/orabloc/htdocs/aztec/rules2litea/statsigs.update
};

my $ua = LWP::UserAgent->new(
    agent   => 'fetch_statsig',
    timeout => 60
);

my $mtime;
if ( -e $FILES[0] ) {
    ($mtime) = ( stat( $FILES[0] ) )[9];
}

foreach my $url (@URLS) {
    my $req = HTTP::Request->new( GET => $url );
    $req->push_header( 'If-Modified-Since' => time2str($mtime) )
        if $mtime;
    my $response = $ua->request($req) or next;
    next unless $response->code == 200;

    foreach my $file (@FILES) {
        my $tmpfile = sprintf( "%s.tmp", $file );
        my $fh = IO::File->new( ">$tmpfile" )
            or die "couldn't open $tmpfile: $!";
        $fh->print( $response->content );
        $fh->close;
        
        my $new_mtime = $response->last_modified;
        utime( $new_mtime, $new_mtime, $tmpfile )
            or die "error setting mtime for $tmpfile: $!";
        rename( $tmpfile, $file )
            or die "error renaming $tmpfile to $file: $!";
    }
    last;
}

exit 0;
