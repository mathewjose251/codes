#!/usr/bin/perl


### Simple Script to Caculate the time difference between System time and Ruleset Creation time \William #####


use Time::Local;

$time=timelocal(localtime);

$blrm_file="/opt/aztec/htdocs/rules2/blrm.bin";
$hashes_file="/opt/aztec/htdocs/rules2/hashes.bin";

($BLRM_READTIME, $BLRM_WRITETIME) = (stat($blrm_file))[8,9];
($HASH_READTIME, $HASH_WRITETIME) = (stat($hashes_file))[8,9];

$blrm_time_diff=$time-$BLRM_WRITETIME;
$hash_time_diff=$time-$HASH_WRITETIME;

print " Time difference for blrm is $blrm_time_diff\n";
print " Time difference for hashes is $hash_time_diff\n";

if ($blrm_time_diff >=900 && $hash_time_diff >=900) {
    send_alert();
}

exit;

sub send_alert()
{
$blrm_time_diff_min=$blrm_time_diff/60;
$hash_time_diff_min=$hash_time_diff/60;
$blrm_int_diff=int($blrm_time_diff_min);
$hash_int_diff=int($hash_time_diff_min);
if ($blrm_int_diff >= $hash_int_diff) {
        $int_diff=$blrm_int_diff;
} else {
        $int_diff=$hash_int_diff;
}
$hostname=`/usr/bin/hostname`;
chop($hostname);
open(SENDMAIL, "|/usr/lib/sendmail -oi -t") || die "$!";
print SENDMAIL <<"EOF";
From:<root\@$hostname>
To: <it-only\@cfio.brightmail.com>,<pageit\@cfio.brightmail.com>
Subject: $hostname haven't receive updated ruleset for $int_diff minutes .


$hostname haven't receive updated blrm ruleset for $blrm_int_diff  minutes .
$hostname haven't receive updated hashes ruleset for $hash_int_diff  minutes .


EOF

close (SENDMAIL)
}
