#!/opt/perl/bin/perl

use strict;
use warnings;

BEGIN {
    require '/space/orabloc/server/conf/inc.pl';  
}

use BLOC::Constants;
use BLOC::RulePropLatency;
use BLOC::RulePropLatency::Config;
use BLOC::RulePropLatency::Finder;

my $offset = 30;
my $start_time = time - (time % 60);
my $max_time = $start_time - ($offset * 60);
my $min_time = $max_time - 61;

# factored this out because it just takes up too much space on a line
sub rule_type_as_string {
    return BLOC::Rule->type_as_string( shift );
}

my @latencies;
POLICY:
for my $pol (
    sort { $a->id <=> $b->id } BLOC::RulePropLatency::Config->retrieve_multiple
) {
    for my $data_center ( qw(sac tuc) ) {
        my @rpl_recs
            =   BLOC::RulePropLatency->retrieve_multiple(
                    rule_type           => $pol->rule_type,
                    ruleset             => $pol->ruleset_path,
                    data_center         => $data_center,
                    creation_time_lt    => $max_time,
                    creation_time_gt    => $min_time,
                );

        my %data = (
            path        => $pol->ruleset_path,
            r_type      => rule_type_as_string( $pol->rule_type ),
            rs_type     => $pol->ruleset_format,
            dc          => $data_center,
        );

        if ( @rpl_recs ) {
            my $rec = $rpl_recs[0];

            my ( $create_time, $prop_time )
                = ( $rec->rule_creation_time, $rec->rule_propagation_time );

            my $latency = $prop_time ? $prop_time - $create_time
                        :              $start_time - $create_time
                        ;

            push @latencies, {
                %data,
                latency     => $latency,
                rule_id     => $rec->rule_id,
            };
        }
        else {
            push @latencies, {
                %data,
                latency     => 0,
                rule_id     => 'NA',
            };
        }
    }
}

my $msg =   join q{ }, map {
                my $cacti_str = sprintf "%s_%s_%s_%s:%d",
                    $_->{dc}, $_->{rs_type}, $_->{r_type}, $_->{path},
                    $_->{latency};
                $cacti_str =~ s/[\/\.]/_/g;
                $cacti_str
            } @latencies;

print $msg, "\n";
