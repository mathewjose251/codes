#!/bin/bash
# cacti_spamhunter.4_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/spamhunter.4 
# /space/orabloc/htdocs/aztec/rules2/spamhunter.4.update
# /space/orabloc/htdocs/aztec/rules2litea/spamhunter.4
# /space/orabloc/htdocs/aztec/rules2litea/spamhunter.4.update
#
# /space/orabloc/htdocs/aztec/rules2full/spamhunter.4
# /space/orabloc/htdocs/aztec/rules2_bulk/spamhunter.4
# /space/orabloc/htdocs/aztec/rules2_newsletter/spamhunter.4
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/spamhunter.4"
file2="/space/orabloc/htdocs/aztec/rules2litea/spamhunter.4"
file3="/space/orabloc/htdocs/aztec/rules2/spamhunter.4.update"
file4="/space/orabloc/htdocs/aztec/rules2litea/spamhunter.4.update"
file5="/space/orabloc/htdocs/aztec/rules2full/spamhunter.4" 
file6="/space/orabloc/htdocs/aztec/rules2_bulk/spamhunter.4"
file7="/space/orabloc/htdocs/aztec/rules2_newsletter/spamhunter.4"

if ( [ -f $file1 ] && [ -f $file2 ] && [ -f $file3 ] && [ -f $file4 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"
	fs3="`/bin/ls -l $file3 | /bin/gawk -F " " '{print $5}'`"
	fs4="`/bin/ls -l $file4 | /bin/gawk -F " " '{print $5}'`"
	fs5="`/bin/ls -l $file5 | /bin/gawk -F " " '{print $5}'`"
	fs6="`/bin/ls -l $file6 | /bin/gawk -F " " '{print $5}'`"
	fs7="`/bin/ls -l $file7 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
        echo "SH4:0 SH42:0 SH4U:0 SH42U:0 SH42F:0 SH42B:0 SH42N:0"
	exit 1
fi

echo SH4:$fs1 SH42:$fs2 SH4U:$fs3 SH42U:$fs4 SH42F:$fs5 SH42B:$fs6 SH42N:$fs7
