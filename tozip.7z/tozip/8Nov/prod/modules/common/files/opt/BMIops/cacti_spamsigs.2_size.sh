#!/bin/bash
# cacti_spamsigs.2_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/spamsigs.2 
# /space/orabloc/htdocs/aztec/rules2/spamsigs.2.update
# /space/orabloc/htdocs/aztec/rules2litea/spamsigs.2
# /space/orabloc/htdocs/aztec/rules2litea/spamsigs.2.update
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/spamsigs.2"
file2="/space/orabloc/htdocs/aztec/rules2litea/spamsigs.2"
file3="/space/orabloc/htdocs/aztec/rules2/spamsigs.2.update"
file4="/space/orabloc/htdocs/aztec/rules2litea/spamsigs.2.update"

if ( [ -f $file1 ] && [ -f $file2 ] && [ -f $file3 ] && [ -f $file4 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"
	fs3="`/bin/ls -l $file3 | /bin/gawk -F " " '{print $5}'`"
	fs4="`/bin/ls -l $file4 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
	echo "SS2:0 SS22:0 SS2U:0 SS22U:0"
	exit 1
fi

echo SS2:$fs1 SS22:$fs2 SS2U:$fs3 SS22U:$fs4
