#!/usr/bin/perl

chop($os=`uname -s`);

# Validate the os
SWITCH:
{
  if ($os =~ /^SunOS$/){last SWITCH;}
  if ($os =~ /^Linux$/){last SWITCH;}

  # DEFAULT: Die if we can't figure out what the os is
  die "Can't figure out which OS the machine is.\n";
}

# Execute the appropriate subroutine based on the os
&$os;

exit(0);

#=======================================================
# Subroutines: names of subroutines are supported OSs.
#========================================================
sub SunOS {

    # Calculate used swap space
    $swap = `swap -s`;
    $swap =~ /^total:\s+(\w+)\s+bytes\s+allocated\s+\+\s(\w+)\s+reserved\s+\=\s+(\w+)\s+used,\s+(\w+)\s+available/;
    chop($used= $3);
    chop($available = $4);
    $swap_total= $used + $available;
    $swap_used = $used / $swap_total;

    # Format total physical memory
    $mem = `prtconf | grep Memory`;
    $mem =~ /^Memory\s+size:\s+(\d+)\s+/;
    $mem_total = $1 * 1024;

    # Format free memory
    $vmstat=`vmstat 1 2 | tail -1`;
    $vmstat =~ /^\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+/;
    $mem_free = $5;
    $mem_used = ($mem_total - $mem_free) / $mem_total;
    $mem_buffers = 0 / $mem_total;
    $mem_cached = 0 / $mem_total;

    print "used:$mem_used buffers:$mem_buffers cached:$mem_cached swap_used:$swap_used";

}

sub Linux {

    # Real memory
    $mem = `free | grep Mem`;
    $mem =~ /^Mem:\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+/;
    $mem_used = ($2 - $5 - $6 )/ $1;
    $mem_buffers = $5 / $1;
    $mem_cached = $6 / $1;

    # Swap
    $swap = `free | grep Swap`;
    $swap =~ /^Swap:\s+(\d+)\s+(\d+)/;
    $swap_used = $2/ $1;

    print "used:$mem_used buffers:$mem_buffers cached:$mem_cached swap_used:$swap_used";
}
