#!/bin/bash

COUNTFILE=/var/lib/bizintel/data/Aggr/zombie.txt

if [ -f  $COUNTFILE ]
then
        LINES="`/usr/bin/wc -l $COUNTFILE | awk -F" "   '{print $1}'`"
        echo "$LINES"
else
	echo "0"
        exit 1
fi

