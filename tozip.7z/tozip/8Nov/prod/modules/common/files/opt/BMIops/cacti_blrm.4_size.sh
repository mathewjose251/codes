#!/bin/bash
# cacti_blrm.4_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/blrm 
# /space/orabloc/htdocs/aztec/rules2/blrm.4.update
# /space/orabloc/htdocs/aztec/rules2litea/blrm
# /space/orabloc/htdocs/aztec/rules2litea/blrm.4.update
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/blrm.4"
file2="/space/orabloc/htdocs/aztec/rules2litea/blrm.4"
file3="/space/orabloc/htdocs/aztec/rules2/blrm.4.update"
file4="/space/orabloc/htdocs/aztec/rules2litea/blrm.4.update"

if ( [ -f $file1 ] && [ -f $file2 ] && [ -f $file3 ] && [ -f $file4 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"
	fs3="`/bin/ls -l $file3 | /bin/gawk -F " " '{print $5}'`"
	fs4="`/bin/ls -l $file4 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
	echo "BLRM4:0 BLRM42:0 BLRM4U:0 BLRM42U:0"
	exit 1
fi

echo BLRM4:$fs1 BLRM42:$fs2 BLRM4U:$fs3 BLRM42U:$fs4
