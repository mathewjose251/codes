#!/opt/perl/bin/perl

=pod

  SYMANTEC PROPRIETARY/CONFIDENTIAL--INTERNAL USE ONLY
  Copyright (c) 2011 Symantec Corporation.  All rights reserved.

=head1 NAME

cacti_silo_summary.pl - Output SILO SUMMARY tables' row counts

=head1 RCS

    $Id: cacti_silo_summary.pl,v 1.1 2018/10/30 10:11:57 mathew Exp $
    $Name:  $

=head1 SYNOPSIS

cacti_silo_summary.pl

=head1 DESCRIPTION

This script outputs data in a cacti-consumable format.  The data it generates
represents row-counts from SILO's summary schema for several tables ( see the C<%summary_tables>
hash in the code for a list of tables. ) for a fixed number of prior day's data (usually 1).

=cut

use strict;
use warnings;

use File::Basename;
BEGIN { require "/space/orabloc/server/conf/inc.pl" }

use BLOC::DB;
use BLOC::DB::Tools qw(:all);
use BLOC::Config    qw(config);
use Storable	    qw(nstore retrieve);
use Time::Local;

use constant	SILO_SUMMARY_PERSISTENT_CACHE => '/tmp/silo_summary_cache.asc';
use constant	SILO_SUMMARY_CACHE_TTL	      => 3600;

# Midnight
use constant    GAP_COVERAGE_HOUR_BEGINS      =>  0;
# .. to 8AM
use constant    GAP_COVERAGE_HOUR_ENDS        =>  8;

my %summary_tables = (
    av_stats_summary            => { seq => 0, date_col => 'creation_time', row_count => 0, days => 1, },
    av_virus_summary            => { seq => 10, date_col => 'creation_time', row_count => 0, days => 1, },
    cpu_stats_summary           => { seq => 20, date_col => 'creation_time', row_count => 0, days => 1, },
    dragnet_customer_summary    => { seq => 30, date_col => 'creation_time', row_count => 0, days => 1, },
    ip_country_summary          => { seq => 40, date_col => 'creation_time', row_count => 0, days => 1, },
    junkyard_summary            => { seq => 50, date_col => 'creation_time', row_count => 0, days => 1, },
    messages_summary            => { seq => 60, date_col => 'creation_date', row_count => 0, days => 1, },
    messages_lang_summary       => { seq => 70, date_col => 'creation_time', row_count => 0, days => 1, },
    messages_resolved_summary   => { seq => 80, date_col => 'creation_time', row_count => 0, days => 1, },
    rule_stats_summary          => { seq => 90, date_col => 'creation_time', row_count => 0, days => 2, },
    rule_stats_history          => { seq => 100, date_col => 'creation_time', row_count => 0, days => 1, },
    spam_stats_summary          => { seq => 110, date_col => 'creation_time', row_count => 0, days => 1, },
    submissions_summary         => { seq => 120, date_col => 'creation_date', row_count => 0, days => 1, },
    verdict_stats_summary       => { seq => 130, date_col => 'creation_time', row_count => 0, days => 1, },
);

my $q_template = 'SELECT COUNT(*) COUNT FROM summary.%s WHERE %s >= (TRUNC(sysdate)-%s)';

sub db_connect {
    return BLOC::DB->new(
        config   => config(),
        driver   => 'Oracle',
        host     => 'silo.brightmail.com',
        sid      => config()->get('silo_db_sid'),
        username => config()->get('silo_db_username'),
        password => config()->get('silo_db_password')
    );
}

sub normalized {
    my ( $label ) = @_;
    return unless $label;
    $label = lc $label;
    $label =~ s/_summary$//;
    $label =~ y/_//d;
    return $label;
}

sub during_coverage_gap {
    my $now      = time();
    my @current  = localtime( $now );
    my $gc_begin = timelocal( 0, 0, GAP_COVERAGE_HOUR_BEGINS, @current[3..5] );
    my $gc_end   = timelocal( 0, 0, GAP_COVERAGE_HOUR_ENDS, @current[3..5] );

    return 1 if ( $now >= $gc_begin && $now <= $gc_end );
    return;
}

sub check_summary_cache {
    my ( $cache_summary_table ) = @_;
    my $cache_file = SILO_SUMMARY_PERSISTENT_CACHE;
    my $cache_ttl  = SILO_SUMMARY_CACHE_TTL;

    return unless -f $cache_file;
    my $mtime = ( stat $cache_file )[9];
    return unless $mtime;

    #
    # There is a period of time early in the morning just after midnight
    # that the SILO summary tables have not been populated with the prior
    # day's data.  During this period simply serve up the cached data.
    #
    # Otherwise, if the cache file has not expired, load it and return true
    #
    if ( during_coverage_gap() || $mtime > ( time() - $cache_ttl ) ) {
	%{$cache_summary_table} = %{ retrieve( $cache_file ) };
	return 1;
    }

    return;
}

sub update_cache {
    my ( $cache_summary_table ) = @_;
    my $cache_file = SILO_SUMMARY_PERSISTENT_CACHE;
    nstore( $cache_summary_table, $cache_file );
    return;
}

MAIN: {
    $| = 1;

    my $db;
    my $use_cached_summary    = undef();
    my %cached_summary_tables = ();

    $use_cached_summary = check_summary_cache( \ %cached_summary_tables );

    unless ($use_cached_summary) {
	$db = db_connect() || die("Could not connect to SILO!\n");
    }

    for my $table (sort { $summary_tables{$a}->{seq} <=> $summary_tables{$b}->{seq} } keys %summary_tables) {
        my $th           = $summary_tables{$table};
        my $query        = sprintf( $q_template, $table, $th->{date_col}, $th->{days} );
        # print STDOUT $query, "\n";
	if ($use_cached_summary) {
	    $th->{row_count} = $cached_summary_tables{$table}->{row_count};
	}
	else {
	    $th->{row_count} = dbi_exec_for_scalar( $db, DBI_CACHE_STMT, $query ) || 0;
	}
    }

    unless ( $use_cached_summary ) {
	$db->disconnect();
	update_cache( \ %summary_tables );
    }

    ##
    ## Dump the results in a cacti-happy format
    ##
    printf STDOUT join(
        ' ' => map( {
                sprintf(
                    '%s:%s' =>
                    normalized($_),
                    $summary_tables{$_}->{row_count},
                )
            }
            sort { $summary_tables{$a}->{seq} <=> $summary_tables{$b}->{seq} } keys %summary_tables
        )
    );

    exit(0);
}

