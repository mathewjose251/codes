#!/bin/bash
# cacti_intsigs_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/intsigs 
# /space/orabloc/htdocs/aztec/rules2/intsigs.update
# /space/orabloc/htdocs/aztec/rules2litea/intsigs
# /space/orabloc/htdocs/aztec/rules2litea/intsigs.update
#
# See HD0000002289321 for details on the request.

typeset -i anyfail=0
typeset -i c=1
typeset -i maxc=7

file[1]="/space/orabloc/htdocs/aztec/rules2/intsigs"
file[2]="/space/orabloc/htdocs/aztec/rules2litea/intsigs"
file[3]="/space/orabloc/htdocs/aztec/rules2/intsigs.update"
file[4]="/space/orabloc/htdocs/aztec/rules2litea/intsigs.update"
file[5]="/space/orabloc/htdocs/aztec/rules2_bulk/intsigs"
file[6]="/space/orabloc/htdocs/aztec/rules2_newsletter/intsigs"
file[7]="/space/orabloc/htdocs/aztec/rules2_suspicious_url/intsigs"

while [ $c -le $maxc ]
do
	if [ -e "${file[$c]}" ] || [ -L "${file[$c]}" ]
	then
		fs[$c]="$(/bin/ls -l "${file[$c]}" |/bin/gawk -F " " '{print $5}')"
	else
		# If a file does not exist, we will graph a "0".
		fs[$c]="0"
		anyfail=1
	fi
	c=c+1
done
echo "INTSIGS:${fs[1]} INTSIGS2:${fs[2]} INTSIGSU:${fs[3]} INTSIGS2U:${fs[4]} INTSIGSB:${fs[5]} INTSIGSN:${fs[6]} INTSIGSSURL:${fs[7]}"
if [ $anyfail = 1 ]
then
	exit 1
fi
