#!/bin/sh
#
# Requires /root/check_throughput.sh be running in cron on the system
# (13Aug09 - running on bloc-db20.sac and bloc-db30.tuc)
#
# /root/check_throughput.sh creates the output file /var/tmp/rcmd.log
#

if [ -f /var/tmp/rcmd.log ];then
  tail -1 /var/tmp/rcmd.log| awk '{print $7}'
fi

