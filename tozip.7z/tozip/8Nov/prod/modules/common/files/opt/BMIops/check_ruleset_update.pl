#!/usr/bin/perl


### Script to find out stale ruleset on any system #####
### Author: Manoj Bansal
### Created: May 03, 2004
### Version: 1.01 


use Time::Local;
use Getopt::Long;
use Pod::Usage;

                         # store current time for comparison
$time=timelocal(localtime);
                         # store hostname to include in alerts and remove any newline chars if any
$hostname=`hostname`;
chop($hostname);

my ( @opt_files, $opt_email, $opt_page, $opt_timeout, $opt_page_minutes, $opt_min_page_duration);
GetOptions( 'files=s' => \$opt_files,
            'email_to=s' => \$opt_email,
            'page_to=s' => \$opt_page,
            'email_at=i' => \$opt_timeout,
            'page_after=i' => \$opt_page_minutes,
            'page_every=i' => \$opt_min_page_duration
           );

if (!$opt_files) {
  print "--files parameter is missing. Can't work without that. Good bye...";
  exit;
}

if (!$opt_timeout) {     # if no timeout defined then following is default
  $opt_timeout = 15;
}

                         # if no page duration defined then 5 minutes is default
if (!$opt_min_page_duration) {
   $opt_min_page_duration = 5;
}

                         # following variables are used to maintain page file
my $EntriesExpired = 0;
my $SomethingToPage = 0;
my %PageFileErrors;
    # if there are expired "All" paging events then page again if applicable
my $PAGE=1;
                         # store all pages in the following file
my $PageFile="/tmp/LastPagedOnRulesetStaleness.txt";

                         # if pagefile exists then find out if it is stale already.
                         # if not store the unexpired content in a perl table
if (  -e "$PageFile" ) {
  my ($mtime) = (stat ($PageFile) )[9];

  if  ( ($time - $mtime ) < ($opt_min_page_duration * 60)) {

# Following few lines suppose to read all values and their timestamp
# and remove all expired entries.
     if (!(open(PAGEFILE,"<$PageFile"))) {
         die "Unable to open file <<<<$PageFile>>>> for reading";
     }

     my $line;
     while ($line=<PAGEFILE>) {
       chop($line);
       if ($line) {
          (my $page_file_name, my $page_timestamp) = split(/:/,$line, 2);
          if   ( ($time - $page_timestamp) < ($opt_min_page_duration * 60)) { # if entry has not expired then keep
              $PageFileErrors{$page_file_name} = $page_timestamp;
              if  ($page_file_name eq "all_the_files") {
                  $PAGE=0;
              }
          } else {
              $EntriesExpired = 1; # entries have expired. This will be used to maintain this file.
          }
      }

     }
     close(PAGEFILE);    # close after being read
  }
}

%file_data=();           # initialize perl table. Will store file information

my $seq_no = 1;
my $ALERT=0;             # Alert is off. Value reset if alert is being sent
my $FILE_LEVEL_PAGE=0;   # If file level alert is going to be sent 
my @opt_files=split(/,/,$opt_files); # Split command line value into records
my $no_of_file= scalar(@opt_files);  # find out how many files are in the set. If one file then all alert
                                     # is not sent

#print "There are :  $no_of_file files to test and opt timeout is $opt_timeout";


                         # Scan each file and find out last update time
foreach $line (@opt_files) {
  (my $filename, my $file_timeout) = split(/:/,$line);


  if (!$file_timeout) {     # if no timeout defined then opt_timeout is default
    $file_timeout = $opt_timeout;
  }

  (my $file_writetime) = (stat($filename))[9]; # write time of the file

  if  (!$file_writetime) {
     print "$filename may not exist\n";
    $no_of_file = $no_of_files - 1;  # change total number of files
  } else {
    my $file_time_diff=$time-$file_writetime;    # difference from the current time.

    $file_data{$seq_no}[0] = $filename;          # store data in perl table
    $file_data{$seq_no}[1] = $file_time_diff;

    if ($file_time_diff >= ($file_timeout*60)) { # send alert if file is older than timeout value
       $ALERT=1;

               # get filename signature
       my $string=$filename;
       &file_signature(\$string);

                         # if timeout is pageable and hasn't been paged before then mark it to page
       if  ($file_time_diff >= (($file_timeout+$opt_page_minutes)*60) and (! exists $PageFileErrors{$string})) {
          $file_data{$seq_no}[2] = 2; # Page Alert
          $FILE_LEVEL_PAGE=1;
          $file_data{$seq_no}[3] = " (Failed Timeout+ Paging Threshold check)";

          $file_data{$seq_no}[4] = "$string";
          $SomethingToPage = 1;   # Something to page so maintain paging log file afterwards
       } else {            # otherwise just email the alert
          $file_data{$seq_no}[2] = 1; # Email Alert
          $file_data{$seq_no}[3] = " (Failed Timeout check)";
       }

    } else {               # otherwise set no alert is required
       $PAGE=0;
       $file_data{$seq_no}[2] = 0; # No Alert
    }

    $seq_no = $seq_no+1;
  }
}

          # Something is getting paged or Entries have expired. Maintain page log file

if ($SomethingToPage > 0 or
        $EntriesExpired > 0 ) {
       open(PAGEFILE,">$PageFile")
        or die "Unable to open file <<<<$PageFile>>>> for writing";
}

if ( $PAGE and $no_of_file > 1) {   # if event is pageable and no of files are more than one then
                                    # send all rulesets are stale alert
        # Record that all files were stale and current timestamp.
   print PAGEFILE "all_the_files:$time\n";

               # 99 is special code for all alerts
   send_alert(99, 
              $opt_page ."," . $opt_email,
              "[Paging Event] All rulesets are stale on $hostname.");
   
} else {
   if  ($ALERT) {                   # if alert is required to be sent
       if ($FILE_LEVEL_PAGE) {      # and file level paging is needed then page
           send_alert(2,
                      $opt_page ."," . $opt_email,
                      "[Paging Event] Some rulesets are stale on $hostname.");
       } 
       send_alert(1,                # otherwise just email
                  $opt_email,
                  "Some rulesets are stale on $hostname.");

   }
}

if ($SomethingToPage > 0 or $EntriesExpired > 0 ) {   # maintain paging log.
       foreach my $page_file_name (keys %PageFileErrors) {
          print PAGEFILE "$page_file_name:",$PageFileErrors{$page_file_name},"\n";
       }
       close(PAGEFILE) 
}

exit;


sub send_alert()
{
   my $alert_level=shift;
   my $recipients=shift;
   my $subject=shift;
   
   my $email_body;



   foreach my $seq_no (keys %file_data) { # create mail body by matching alert levels to stroed values
       if  ($file_data{$seq_no}[2] eq $alert_level or $alert_level eq 99) {
          $email_body = $email_body . 
                         "   $file_data{$seq_no}[0] is " . int($file_data{$seq_no}[1]/60) . " minutes old" .
                         "$file_data{$seq_no}[3].\n";
          if ($alert_level > 1) {
             print PAGEFILE "$file_data{$seq_no}[4]:$time\n";
          } 
       }
   }

   if ($email_body) {  # send alert
     $email_body = "Current time is: ". scalar localtime(time()). "\n". 
                     "haven't received updated ruleset:\n $email_body";
     open(SENDMAIL, "|/usr/lib/sendmail -oi -t") || die "$!";
         print SENDMAIL "To: ".$recipients."\n";
         print SENDMAIL "Subject: $subject\n";
         print SENDMAIL "From: root\@$hostname\n";
         print SENDMAIL "\n";
         print SENDMAIL "$email_body\n";
         close(SENDMAIL);

         die "sendmail error: $?" if $?;

     close (SENDMAIL)
   } 
}

sub file_signature
{
    my $string = shift;

    # remove anything that's not a lowercase letter or whitespace from
    # $$string.
    $$string =~ s/[^a-z_\s]//g;

    # truncate one or more spaces or underscores into a single underscore
    $$string =~ s/[\s_]+/_/g;
}
