#!/bin/bash
# cacti_hashes_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/hashes 
# /space/orabloc/htdocs/aztec/rules2/hashes.update
# /space/orabloc/htdocs/aztec/rules2litea/hashes
# /space/orabloc/htdocs/aztec/rules2litea/hashes.update
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/hashes"
file2="/space/orabloc/htdocs/aztec/rules2litea/hashes"
file3="/space/orabloc/htdocs/aztec/rules2/hashes.update"
file4="/space/orabloc/htdocs/aztec/rules2litea/hashes.update"

if ( [ -f $file1 ] && [ -f $file2 ] && [ -f $file3 ] && [ -f $file4 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"
	fs3="`/bin/ls -l $file3 | /bin/gawk -F " " '{print $5}'`"
	fs4="`/bin/ls -l $file4 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
	echo "HASH:0 HASH2:0 HASHU:0 HASH2U:0"
	exit 1
fi

echo HASH:$fs1 HASH2:$fs2 HASHU:$fs3 HASH2U:$fs4
