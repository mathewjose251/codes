#!/opt/perl/bin/perl
# cacti_unprocessed_probes.pl                                        (04/14/11)
# By: Beam Davis (beam_davis@symantec.com)
#
# Usage: cacti_unprocessed_probes.pl
#
# Exit Statuses:
#
# 0 = Normal
# 1 = Error
#
# Major Revision History:
#
# 04/14/11 -	First production version.
#
# Modules.
#
use strict;
use warnings;
BEGIN { require("/space/orabloc/server/conf/inc.pl"); }
use BLOC::DB;
use BLOC::DB::Tools qw(:all);
use Getopt::Long;
#
# Constants.
#
my @submission_types=(-1, -2, -3, -4, -5, -6, -7, -8);
my %submission_types=(
	-1=>'junk',
	-2=>'good',
	-3=>'fraud',
	-4=>'consumer_good',
	-5=>'consumer_junk',
	-6=>'newsletter',
	-7=>'marketing_mail',
	-8=>'suspicious_url'
);
#
# Declairations.
#
my @msg		=();
my %counts;
#my $config	=BLOC::Config->new();
my $count;
my $db		=BLOC::DB->db();
my $name;
my $type;
#
# Subroutines.
#
sub usage {
# Usage: &usage
	warn "Usage: $name\n";
	exit 1;
}
#
# Main routine.
#
($name=$0)=~s#.*/##;
# Print usage and exit if anything was specified on the command-line.
&usage if(defined(@ARGV));
# Retrieve counts of unprocessed probes from the database.
#
%counts=dbi_exec_for_hoh(
	$db, DBI_CACHE_STMT,
		q{
			SELECT probe_id, COUNT(*) AS count
			FROM messages
			WHERE probe_id < 0
			AND verdict    = 0
			AND alert_print_time IS NULL
			GROUP BY probe_id
		}
);
#
# Loop through the submission types and store the retrieved data.
#
foreach $type (@submission_types) {
	$count=$counts{$type}{'count'};
	$count=0 if(!defined($count));
	push(@msg, sprintf("%s:%s", $submission_types{$type}, $count));
}
#
# Format and print output.
print join(" ", @msg);
# Always exit clean if we've made it this far.



# # #  End of cacti_unprocessed_probes.pl  # # #

