#!/bin/sh
HOST=`/bin/hostname`
LOAD1=`/usr/bin/uptime | /bin/sed 's/,//g' | /bin/awk '{print $10*100}'`
LOAD5=`/usr/bin/uptime | /bin/sed 's/,//g' | /bin/awk '{print $11*100}'`
UPTIME=`/usr/bin/uptime | /bin/sed 's/,//g' | /bin/awk '{printf "%s days, %s hours\n",$3,$5}'`

echo "$LOAD1"
echo "$LOAD5"
echo "$UPTIME"
echo "$HOST"
