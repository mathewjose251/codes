#!/bin/bash
# cacti_root_space.sh
# Script for Cacti to graph disk usage on zombie MySQL servers.
# See HD HD0000002116526 for details on the request.

FS1="/"
FS2="/var/lib/mysql"
FS3="/var/lib/mysql/zbl_data"

if ( [ -x /usr/bin/du ] && [ ! -L /usr/bin/du ] )
then
        if ( [ -d $FS1 ] && [ -d $FS2 ] && [ -d $FS3 ] )
        then
                FSB1="`/usr/bin/du -ksx $FS1 | /bin/cut -f 1`"
                FSB2="`/usr/bin/du -ksx $FS2 | /bin/cut -f 1`"
                FSB3="`/usr/bin/du -ksx $FS3 | /bin/cut -f 1`"
        else
                echo "ERROR: One or more filesystems does not exist, please check"
        fi
fi

if ( [ -x /bin/df ] && [ ! -L /bin/df ] && [ -x /bin/grep ] && [ ! -L /bin/grep ] && [ -x /bin/gawk ] && [ ! -L /bin/gawk ] )
then
        FSTOTAL="`/bin/df -k / | /bin/grep dev | /bin/gawk -F " " '{print $2}'`"
        echo FSTOTAL:$FSTOTAL ROOT:$FSB1 MYSQL:$FSB2 MYSQLDATA:$FSB3
else
        echo "ERROR: Could not find necessary OS tools, please verify the location of df, grep and awk"
fi
