#!/bin/sh

 tail -1 /var/tmp/traceroute.log | awk '{print $4}'
