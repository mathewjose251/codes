#!/usr/bin/perl

## checkwithperl.pl, 7/3/04
## updated to work within Brightmail 4/11/08
## by Geoffrey Gloistein mailto:ggloistein@taos.com
## This script will require several perl modules.

## Molule List: perl-ldap, Convert-ASN1, TimeLocal
## Time-modules, libnet, ExtUtils-AutoInstall.

## This script will be run nightly by cron in
## order to find accounts about to expire and
## notify the owner of the account via email.

use Net::LDAP;
use Net::SMTP;
use Time::Local;
use integer;

$ldapserver = "ldap-mstr.brightmail.com";
$base = "dc=brightmail,dc=com";
$searchstring = "(&(objectclass=shadowaccount)(uid=*)(shadowlastchange=*)(!(loginshell=/sbin/nologin))(|(mail=*)(maillocaladdress=*)))" ;
$searchbase = "ou=people,$base";
$attrs = ['cn','shadowmax','mail','maillocaladdress','shadowlastchange', 'uid'];
$login_dn = "uid=ldapproxy,ou=people,$base";
$login_pw = "secret";
$today = time();
$today = ($today / 86400);
print "Today is $today.\n";

## connect and gather information
 
$ldap = Net::LDAP->new ( $ldapserver ) or die "$@\n";
$mesg = $ldap->bind($login_dn, password => $login_pw, version => 3);
$mesg = $ldap->search ( base	=>  $searchbase,
				  scope	=> "sub",
				  filter	=>  $searchstring,
				  attrs	=>	$attrs
						);
@entries = $mesg->entries;
foreach $entr ( @entries ){
	$user_cn = $entr->get_value ( 'cn' );
	$uid = $entr->get_value ( 'uid' );
	$passexpire = $entr->get_value ( 'shadowlastchange' );
	$shadowmax = $entr->get_value ( 'shadowmax' );
	$mail = $entr->get_value ( 'mail' );
	$maillocaladdress= $entr->get_value ( 'maillocaladdress' );
	if (!$mail) {
		$mail = $maillocaladdress;
	}
	$mailhost = 'smtp-a.sac.brightmail.com';
	$days = ($shadowmax - ($today - $passexpire));
	print "\n*****checking account $uid\n";
	print "$mail is the address for $user_cn\n";
	print "Account $uid will expire in $days days.\n";

## Send email message to matching accounts

	if ($days == 1) {
	} elsif ($days == 3) {
	} elsif ($days == 5) {
	} elsif ($days == 7) {
	} elsif ($days == 14) {
	} elsif ($days < 0) {
		print "Account $uid has expired.\n";
		next;
	} else {
		next;
	}
	print "Sending message to: $user_cn\n";
	$smtp = Net::SMTP->new($mailhost,Timeout => 60);
	if (!$smtp) {
		next;
	}
	$smtp->mail('DL-IT-SF-CFIO@symantec.com');
	$smtp->to ($mail);
	$testmail = "DL-IT-SF-CFIO\@symantec.com";
	$testcn = "Brightmail MSO";
	$smtp->bcc ($testmail);
	$smtp->data();
	$smtp->datasend("To: \"$user_cn\" <$mail>\n");
	#$smtp->datasend("To: \"$testcn\" <$testmail>\n");
	$smtp->datasend("From: \"Brightmail MSO\" <DL-IT-SF-CFIO\@symantec.com>\n");
	$smtp->datasend("Subject: Brightmail Production LDAP Password will expire in $days day(s).\n");
	$smtp->datasend("\n");
	$smtp->datasend("$user_cn,\n\n");
	$smtp->datasend("Your Brightmail Production Linux Account Password will expire in $days day(s) and your account will be automaticaly locked.\n\n");
	$smtp->datasend("Please log in to a Brightmail Production system now to change your password with the \"passwd\" command.\n\n");
	$smtp->datasend("Thank you.\n");
	$smtp->dataend();
	$smtp->quit;
}

sub LDAPsearch
{
	my ($ldap,$searchString,$attrs,$base) = @_;
}

$mesg = $ldap->unbind;
print "Expiration check is complete\n";
