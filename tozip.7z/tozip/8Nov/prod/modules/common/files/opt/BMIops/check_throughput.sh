#!/usr/bin/perl

use strict;

$|=1;
my ($arg ,$aref,$val,$t,%arg,$key);

# size in K
my $TRACEROUTEFILE='/var/tmp/traceroute.log';
my $RCMDFILE='/var/tmp/rcmd.log';
my %args;
my %argkeys = ( 'd','debug','t', 'sleeptime', 's', 'size', 'c', 'command', 'r', 'remotehost', 'sdir', 'sourcedir', 'tdir', 'targetdir');
my %settings;
my $DD='dd';
my $TR='/usr/sbin/traceroute';

my $testrand='testrand';

my $hostname=`hostname`;
chop $hostname;

$aref= get_args(@ARGV);

%settings=%{$aref};

runcmd(\%settings);

sub runcmd {
  my $href = shift;
  my %settings = %{$href};
  my ($cmd,$EXEC,$CMD,$tstr,$LOG);

  my $srcfile=$settings{sourcedir}.'/'.$testrand.'-'.$hostname;
  my $dstfile=$settings{targetdir}.'/'.$testrand.'-'.$hostname;
  unlink $srcfile;
  $settings{srcfile}=$srcfile;
  $settings{dstarg}=$settings{remotehost}.':'.$dstfile;

  $cmd = join(" ",($DD,'if=/dev/urandom of='.$srcfile,'bs=1024','count='.$settings{size}));
  if ( $settings{debug}>0) {print $cmd,"\n";}
  open($EXEC,"$cmd 2>&1 |") || die "can't open command pipe\n";

  while(<EXEC>) { if ($settings{debug}>0) {print;} };
  close $EXEC;

  $cmd="";

  $tstr = get_tstr();

  foreach $key ('command','srcfile','dstarg') {
    $cmd.=$settings{$key}." ";
  }

  if ( $settings{debug}>0) {print $cmd,"\n";}

  open($LOG,">>$RCMDFILE") || die "could not open $RCMDFILE for append\n";

  print $LOG $tstr," ",$settings{size}," ",`time $cmd 2>&1 \| awk '/^real/ {print \$NF}'`;

  close $LOG;

  open($LOG,">>$TRACEROUTEFILE") || die "could not open $TRACEROUTEFILE for append\n";

  $cmd = "$TR $settings{remotehost}";
  $tstr = get_tstr();
  print $LOG $tstr," ", `$cmd 2>&1`;

  close $LOG;
}

sub get_tstr {

  my @a=localtime; return(sprintf("%d %02d %02d %02d %02d",$a[5]+1900,$a[4]+1,$a[3],$a[2],$a[1]));
  
}


sub get_args {
  my @arr = @_;
  my @tarr = @_;
  my %args;
 
  foreach $arg ( @arr ) { 
    if ($arg=~s/^-(\w+)/\1/) { 
      $args{$arg} = $tarr[1];
      #print "args{$arg}=$args{$arg}\n";
    }
  shift @tarr;
  }

  foreach $key ( keys %args ) { 
#      print "arg{$key}=$args{$key}\n";
      $settings{$argkeys{$key}} = $args{$key};
   }
  return(\%settings);
}

