#!/bin/sh

### Query queue size of Stats #####
q1=`ls -l /space/orabloc/spool/stats |wc -l`;
echo $q1;
echo `hostname`;
exit

