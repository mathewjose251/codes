#!/usr/bin/perl
#
# $Id: cacti_bind9_stats.pl,v 1.1 2018/10/30 10:11:57 mathew Exp $
# $Author: mathew $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/opt/BMIops/cacti_bind9_stats.pl,v $
#

# Use built-in option syntax
use Getopt::Std;

# use $opt_d to override default named.stats dir location
getopt('d');

$STATFILE = $opt_d ? "$opt_d/named.stats" : '/var/named/chroot/var/named/named.stats';
$cmd_ndc  = '/usr/sbin/rndc stats > /dev/null 2>&1';

# Generate stats now (this could be turned off and run via cron as well)
unlink($STATFILE,$MEMFILE);
qx($cmd_ndc);
$status = $?;
die "Failed command: $cmd_ndc: EXIT_CODE: $status" if $status;

# Die unless we can locate the stats file
if (!open(STATS,$STATFILE)) {
        die "Failed to open $STATFILE: $!\n";
}

chop($host=`uname -n`);

# Parse the stats file
while (<STATS>) {
        if ($host =~ /^brs-ns|^brs-dns/){
                next if !/msgsecurity.juniper.net/;
        }
        else {
                next if /^[\-\+]/;
                next if /(localhost|127.in-addr.arpa)$/;
        }
        chomp();
        @data = split();
	print $data[0],":",$data[1]," ";
}
close (STATS);
