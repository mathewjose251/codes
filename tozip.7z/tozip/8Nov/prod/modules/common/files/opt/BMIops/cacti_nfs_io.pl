#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Basename;
#use vars qw($PROGNAME $VERSION);
use lib "/usr/nagios/libexec";
use lib "/usr/lib/nagios/plugins";

#$PROGNAME = basename($0);
#$VERSION = '$Revision: 1.1 $';
#$ENV{LC_ALL} = 'POSIX';

my ($opt_d, $opt_f, $now, $wstarttime, $wendtime, $wtime, $rstarttime, $rendtime, $rtime);;

$now = (time);

# set default values
$opt_d = "/var/lib/bizintel/nfs-check-io-cacti.$now";
$opt_f = "$opt_d/testfile.$now";

mkdir $opt_d;

# Write Starttime
$wstarttime = (time);
system( "dd if=/dev/zero of=$opt_f bs=16k count=16384 > /dev/null 2>&1");
# Write Endtime
$wendtime = (time);
$wtime = ($wendtime-$wstarttime);
# Read Starttime
$rstarttime = (time);
system( "dd if=$opt_f of=/dev/null bs=16k > /dev/null 2>&1");
# Read Endtime
$rendtime = (time);
$rtime = ($rendtime-$rstarttime);

print "Write:$wtime Read:$rtime";

#print "Removing $opt_d\n";
unlink $opt_f;
rmdir $opt_d;
