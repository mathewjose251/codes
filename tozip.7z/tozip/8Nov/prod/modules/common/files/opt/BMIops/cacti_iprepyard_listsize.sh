#!/bin/sh

listdir=/var/iprepyard/fs/lists
cd $listdir || exit

cd ..

  for i in zodiac dakota;do 
    wc -l $i 2>/dev/null| grep -v '\.' | awk '!/total/ && !/lists/ {printf("%s:%s ",$2,$1);}'
  done

cd $listdir || exit

  
  for i in xbl smtp sbl safe pbl opl dnbl cas brs21 zombie;do 
    if [ -e $i ]
    then
        wc -l $i | grep -v total | awk '!/total/ {printf("%s:%s ",$2,$1);}' 
    else
	echo -n "$i:0 "
    fi
  done

#  echo | awk '{printf("\n");}'

