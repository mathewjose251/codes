#!/bin/sh

### Query queue size of Acks #####
q1=`ls -l /space/orabloc/spool/acks |wc -l`;
echo $q1;
echo `hostname`;
exit

