#!/bin/bash
# cacti_spamsigs_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/spamsigs 
# /space/orabloc/htdocs/aztec/rules2/spamsigs.update
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/spamsigs"
file2="/space/orabloc/htdocs/aztec/rules2/spamsigs.update"

if ( [ -f $file1 ] && [ -f $file2 ] && [ -f $file3 ] && [ -f $file4 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
	echo "SS:0 SSU:0" 
	exit 1
fi

echo SS:$fs1 SSU:$fs2 
