#!/usr/bin/perl
# $Header: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/opt/BMIops/cacti_mail_stats.pl,v 1.1 2018/10/30 10:11:57 mathew Exp $
$TRACE = $ARGV[0];
$mailfrom =`/opt/BMIops/mrtg-mailstats.plx -S from`;
chomp $mailfrom;
$mailto =`/opt/BMIops/mrtg-mailstats.plx -S to`;
chomp $mailto;
$mailrej =`/opt/BMIops/mrtg-mailstats.plx -S rej`;
chomp $mailrej;
$maildis=`/opt/BMIops/mrtg-mailstats.plx -S dis`;
chomp $maildis;
$mailq_tmp = `mailq | grep -i "Request" `; 
if ($mailq_tmp =~ /\((\d+)\W+(Requests|Request)\)/ig) {
	print "Requests IS $mailq_tmp\n" if ($TRACE);
	$mailq=$1;
	print "RequestsMAILQ is |$mailq|\n" if ($TRACE);
}
if ($mailq_tmp =~ /Total\W+Requests\:\W*(\d+)/ig) {
	print "TOTAL REQUESTS IS $mailq_tmp\n" if ($TRACE);
	$mailq=$1;
	print "TOTALRequestsMAILQ is |$mailq|\n" if ($TRACE);
}
#}
$mailq=~s/#.*//; # no comments
$mailq=~s/^\s+//; # no leading white
$mailq=~s/\s+$//; # no trailing white
chomp $mailq;
unless (length $mailq) {
	$mailq = "0";
}
print "from:$mailfrom to:$mailto reject:$mailrej discard:$maildis queue:$mailq";
