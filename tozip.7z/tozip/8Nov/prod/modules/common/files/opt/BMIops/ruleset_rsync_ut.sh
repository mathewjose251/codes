#!/bin/sh
LOCKFILE=/tmp/.ruleset_rsync-$1.lock
LOG=/var/log/rsynclog/$1.log
HOST=$1

if [ "X$1" == "X" ]
then
   echo "Usage: $0 hostname"
   exit
fi

# test for an existing lockfile.  If the lockfile's there, test
# whether the pid still exists.  This isn't perfect, but if the rsync
# dies badly we should recover the next time the cron job kicks off
if [ -f "$LOCKFILE" ]; then
    ps -p `cat $LOCKFILE` > /dev/null && exit 0
fi

# get the lock
echo $$ > $LOCKFILE

# rsync forever
CMD_PULL="/usr/bin/rsync -e ssh -av --stats --exclude=.* --exclude=ruleset_daemon_* --update $HOST:/export/vol01/orabloc/rulesets/ /space/orabloc/rulesets/"
CMD_PUSH="/usr/bin/rsync -e ssh -av --stats --exclude=.* --exclude=ruleset_daemon_* --update /space/orabloc/rulesets/ $HOST:/export/vol01/orabloc/rulesets/"

while true;
do
  /bin/echo "RSYNC START `/bin/date`" >> $LOG
  $CMD_PULL >> $LOG 2>&1
  /bin/echo "PUSH START `/bin/date`" >> $LOG
  $CMD_PUSH >> $LOG 2>&1
  /bin/echo "RSYNC END `/bin/date`" >> $LOG
  sleep 10; 
done

