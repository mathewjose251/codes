#!/usr/bin/perl

chop($host=`uname -n`);

# Validate the hostname
SWITCH:
{
  if ($host =~ /^bt/){
	$cluster=BT;
	last SWITCH;
	}
  # DEFAULT: Die if we can't figure out what the os is
  die "Can't figure out which type of machine this is.\n";
}

# Execute the appropriate subroutine based on the os
&$cluster;

exit(0);

#===============================================================
# Subroutines: names of subroutines are supported host cluster .
#===============================================================
sub BT  {
        $probes =`ls -1 /space/orabloc/spool/probes/| wc -l` + 0;
        $stats =`ls -1 /space/orabloc/spool/stats/| wc -l` + 0;
        $acks =`ls -1 /space/orabloc/spool/acks/| wc -l` + 0;
        $dayzero =`ls -1 /space/orabloc/spool/dayzero/| wc -l` + 0;
        $out_mqueue =`ls -1 /space/orabloc/spool/out_mqueue/| wc -l` + 0;
        $unfiltered =`ls -1 /space/orabloc/spool/unfiltered/| wc -l` + 0;
        print "acks:$acks dayzero:$dayzero out_mqueue:$out_mqueue probes:$probes stats:$stats unfiltered:$unfiltered ";

}
sub DEFAULT {
        chop($total =` ps ax |  grep -v grep | grep -c :`);
	print "total:$total";
}
