#!/bin/bash
#
#This will only work on ES version 3 as the sar command changes in 4 and 5
#you need to specify on the command line which disk to look at like sda or sdb
#
#get the disk to check from the first option
DISK=$1
#
AWKS1='BEGIN{ ORS=" "}$1 ~ /Average/ && $2 ~ /^'
AWKS2='/{ print $2 "_TPS:" $3 " " $2 "_R:" $4 " " $2 "_W:" $5 }'
sar -d -p 5 1 | awk "${AWKS1}${DISK}${AWKS2}"
