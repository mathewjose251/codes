#!/usr/bin/perl


### Script to find out stale ruleset on any system #####
### Author: Manoj Bansal
### Created: May 03, 2004
### Version: 2 originally check_ruleset_update

use Sys::Syslog;
use Time::Local;
use Getopt::Long;

 #$PRIORITY = 'err';

# define default values for the object
use constant Default_Ident             => 'ruleset_age_monitor';
use constant Default_Logopt            => 'pid';
use constant Default_Syslog_Facility   => 'local4';
use constant Default_Language_Module   => 'English';


Sys::Syslog::setlogsock('unix');
openlog (Default_Ident,Default_Logopt,Default_Syslog_Facility);

                         # store current time for comparison
$time=timelocal(localtime);
                         # store hostname to include in alerts and remove any newline chars if any
$hostname=`hostname`;
chop($hostname);

my ( @req_files, $opt_timeout, $opt_page_minutes);

# files parameter should be in <file name>:<timeout> format. if :<timeout> is not specified then default value will be used

GetOptions( 'files=s' => \$req_files,
            'notice_at=i' => \$opt_timeout,
            'critical_at=i' => \$opt_page_minutes
           );

if (!$req_files) {
  print "--files parameter is missing. Can't work without that. Good bye...";
  exit;
}

if (!$opt_timeout) {     # if no timeout defined then following is default
  $opt_timeout = 15;
}

if (!$opt_page_minutes) {     # if no paging threshold is defined then following is default
  $opt_page_minutes = 10;
}

my @opt_files=split(/,/,$req_files); # Split command line value into records

                         # Scan each file and find out last update time
foreach $line (@opt_files) {
  (my $filename, my $file_timeout) = split(/:/,$line);


  if (!$file_timeout) {     # if no timeout defined then opt_timeout is default
    $file_timeout = $opt_timeout;
  }

  (my $file_writetime) = (stat($filename))[9]; # write time of the file

  if  (!$file_writetime) {
     syslog('Err',"[INFO] file=$filename may not exist.");
     #print "$filename may not exist\n";
  } else {
    my $file_time_diff=$time-$file_writetime;    # difference from the current time.
    my $timeout_in_min=sprintf("%.0f", ($file_time_diff/60));

    if ($file_time_diff >= ($file_timeout*60)) { # send alert if file is older than timeout value
       if  ($file_time_diff >= (($file_timeout+$opt_page_minutes)*60)) {
          syslog('err',"[ALERT] Ruleset on $hostname is $timeout_in_min minutes old - (file=$filename failed Timeout + Paging Threshold check).");
       } else {            # otherwise just email the alert
          syslog('err',"[NOTICE] Ruleset on $hostname is $timeout_in_min minutes old - (file=$filename failed Timeout check).");
       }

    } else {               # otherwise set no alert is required
       syslog('info',"[INFO] Ruleset on $hostname is upto date - file=$filename is $timeout_in_min minutes old.");
    }

  }
}

closelog;

exit;
