#!/bin/sh
if [ -s "$1" ]
then
	tail -1 $1 |sed -e 's/^name:[^ ]* //'
fi


# # #  End of cacti_get_from_file.sh  # # #

