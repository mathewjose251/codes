#!/usr/bin/perl

chop($host=`uname -n`);

# Validate the hostname
SWITCH:
{
  if ($host =~ /(^mx-)|(^smtp)|(^biz-)/){
	$cluster=MX;
	last SWITCH;
	}
  if ($host =~ /^avwall/){
	$cluster=MX;
	last SWITCH;
	}
  if ($host =~ /^bt-ard/){
	$cluster=BTARD;
	last SWITCH;
	}
  if ($host =~ /^bt-alert/){
	$cluster=BTALERT;
	last SWITCH;
	}
  if ($host =~ /^bt-rpc/){
	$cluster=BTRPC;
	last SWITCH;
	}
  if ($host =~ /(^asu)|(^log)|(^ldap)|(^cfm)|(^bastion)|(^ks)|(^mon)|(^spamlab-markup)|(^ts)/){
	$cluster=DEFAULT;
	last SWITCH;
	}
  if ($host =~ /^bt-bbl/){
	$cluster=BTBBL;
	last SWITCH;
	}
  if ($host =~ /^bt-monk/){
	$cluster=BTMONK;
	last SWITCH;
	}
  if ($host =~ /^bt-prop/){
	$cluster=BTPROP;
	last SWITCH;
	}
  if ($host =~ /^bt-probe/){
	$cluster=BTCOLLECT;
	last SWITCH;
	}
  if ($host =~ /^bt-statack/){
	$cluster=BTSTATACK;
	last SWITCH;
	}
  if ($host =~ /^bt-web/){
	$cluster=BTWEB;
	last SWITCH;
	}
  if ($host =~ /^bt-misc/){
	$cluster=BTMISC;
	last SWITCH;
	}
  if ($host =~ /(^aztec)/){
	$cluster=AZ;
	last SWITCH;
	}
  if ($host =~ /^rda/){
	$cluster=RDA;
	last SWITCH;
	}
  if ($host =~ /^rules/){
	$cluster=RDA;
	last SWITCH;
	}
  if ($host =~ /^junkyard/){
	$cluster=JUNK;
	last SWITCH;
	}
  if ($host =~ /^bloc-d(b|w)/){
	$cluster=DB;
	last SWITCH;
	}
  if ($host =~ /^silo/){
	$cluster=DB;
	last SWITCH;
	}
  if ($host =~ /^nms/){
	$cluster=NMS;
	last SWITCH;
	}
  if ($host =~ /(^ns)|(^brs-)/){
	$cluster=NS;
	last SWITCH;
	}
  if ($host =~ /^www/){
	$cluster=WWW;
	last SWITCH;
	}
  if ($host =~ /^ipr-web/){
	$cluster=IPRWEB;
	last SWITCH;
	}
  if ($host =~ /^wl-(harvest|ipryd|web)/){
	$cluster=WL;
	last SWITCH;
	}
  # DEFAULT: Die if we can't figure out what the os is
  die "Can't figure out which OS the machine is.\n";
}

# Execute the appropriate subroutine based on the os
&$cluster;

exit(0);

#===============================================================
# Subroutines: names of subroutines are supported host cluster .
#===============================================================
sub MX {
        chop($total = `ps -deaf | grep -v grep | grep -c : `);
        chop($smtp = `ps -deaf | grep -v grep | grep -c sendmail `);
	print "total:$total smtp:$smtp";
}
sub BTARD {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($aztec = `ps auxww | grep -v grep | grep -c aztec_ruleset_daemon`);
        chop($httpd = `ps auxww | grep -v grep | grep -c httpd`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
	print "total:$total aztec:$aztec httpd:$httpd qreader:$qreader ";
}
sub BTRPC {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($httpd = `ps auxww | grep -v grep | grep -c httpd`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
	print "total:$total httpd:$httpd qreader:$qreader ";
}
sub BTBBL {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($new_proxy_checker = `ps auxww | grep -v grep | grep -c new_proxy_checker`);
        chop($old_proxy_checker = `ps auxww | grep -v grep | grep -c old_proxy_checker`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
	print "total:$total new_proxy_checker:$new_proxy_checker old_proxy_checker:$old_proxy_checker qreader:$qreader";
}
sub BTCOLLECT {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($collector = `ps auxww | grep -v grep | grep -c collector`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
	print "total:$total collector:$collector qreader:$qreader ";
}
sub BTMONK {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($attack_grouper = `ps auxww | grep -v grep | grep -c attack_grouper`);
        chop($easy_sig_monkey = `ps auxww | grep -v grep | grep -c easy_sig_monkey`);
        chop($ip_monkey = `ps auxww | grep -v grep | grep -c ip_monkey`);
        chop($propagate = `ps auxww | grep -v grep | grep -c propagate_daemon`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
        chop($rule_monkey = `ps auxww | grep -v grep | grep -c rule_monkey`);
        chop($oracle_job_daemon = `ps auxww | grep -v grep | grep -c oracle_job_daemon`);
	print "total:$total attack_grouper:$attack_grouper easy_sig_monkey:$easy_sig_monkey ip_monkey:$ip_monkey propagate:$propagate qreader:$qreader rule_monkey:$rule_monkey oracle_job_daemon:$oracle_job_daemon";
}
sub BTPROP {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($alert = `ps auxww | grep -v grep | grep -c alert_daemon`);
        chop($conduit = `ps auxww | grep -v grep | grep -c conduit_propagate_daemon`);
        chop($propagate = `ps auxww | grep -v grep | grep -c propagate_daemon`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
	print "total:$total alert:$alert conduit:$conduit propagate:$propagate qreader:$qreader ";
}
sub BTALERT {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($alert = `ps auxww | grep -v grep | grep -c alert_daemon`);
	print "total:$total alert:$alert ";
}
sub BTSTATACK {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($ack = `ps auxww | grep -v grep | grep -c ack_daemon`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
        chop($stats = `ps auxww | grep -v grep | grep -c stats_daemon`);
        chop($sendmail = `ps auxww | grep -v grep | grep -c sendmail`);
	print "total:$total ack:$ack qreader:$qreader stats:$stats sendmail:$sendmail";
}
sub BTWEB {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($av = `ps auxww | grep -v grep | grep -c av_daemon`);
        chop($fp_alert = `ps auxww | grep -v grep | grep -c fp_alert_daemon`);
        chop($httpd = `ps auxww | grep -v grep | grep -c httpd`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
        chop($ruleset = `ps auxww | grep -v grep | grep -c ruleset_daemon`);
	print "total:$total av:$av fp_alert:$fp_alert httpd:$httpd qreader:$qreader ruleset:$ruleset";
}
sub BTMISC {
        chop($total = ` ps ax |  grep -v grep | grep -c :  `);
        chop($fp_alert = `ps auxww | grep -v grep | grep -c fp_alert_daemon`);
        chop($qreader = `ps auxww | grep -v grep | grep -c qreader`);
        chop($ruleset = `ps auxww | grep -v grep | grep -c ruleset_daemon`);
	print "total:$total fp_alert:$fp_alert qreader:$qreader ruleset:$ruleset";
}
sub AZ {
        chop($total = ` ps ax | grep -v grep | grep -c : `);
        chop($http = `ps auxww | grep -v grep | grep -c httpd `);
	print "total:$total http:$http";
}
sub WWW {
        chop($total = ` ps ax | grep -v grep | grep -c : `);
        chop($http = `ps auxww | grep -v grep | grep -c httpd `);
	print "total:$total http:$http";
}
sub RDA {
        chop($total = ` ps ax |  grep -v grep | grep -c : `);
        chop($http = `ps auxww | grep -v grep | grep -c httpd `);
	print "total:$total http:$http";
}
sub DB {
        chop($total = ` ps -deaf | grep -v grep | grep -c : `);
        chop($oracle = `ps -deaf | grep -v grep | egrep -c "ora_s0[0-9][0-9]|oraclesilo|oraclebloc|oraclemsga|oracleorcl|oraclecrdb"`);
	print "total:$total oracle:$oracle";
}
sub JUNK {
        chop($total = ` ps ax |  grep -v grep | grep -c : `);
        chop($casey = `ps auxww | grep -v grep | grep -c casey`);
        chop($mysql = `ps auxww | grep -v grep | grep -c mysqld`);
        chop($smtp = `ps auxww | grep -v grep | grep -c sendmail `);
	print "total:$total casey:$casey mysql:$mysql smtp:$smtp";
}
sub NMS {
        chop($total = ` ps ax |  grep -v grep | grep -c : `);
        chop($nagios = `ps auxww | grep -v grep | grep -c nagios`);
        chop($mysql = `ps auxww| grep -v grep | grep -c mysql`);
        chop($cacti = `ps auxww | grep -v grep |grep -v cacti_ | grep -c cacti`);
	print "total:$total cacti:$cacti mysql:$mysql nagios:$nagios";
}
sub NS {
        chop($total = ` ps ax |  grep -v grep | grep -c : `);
        chop($named = `ps auxww | grep -v grep | grep -c named `);
        chop($ntpd = `ps auxww | grep -v grep | grep -c ntpd `);
        chop($smtp = `ps auxww | grep -v grep | grep -c sendmail `);
	print "total:$total named:$named ntpd:$ntpd smtp:$smtp";
}
sub IPRWEB {
        chop($total = ` ps ax | grep -v grep | grep -c : `);
        chop($iprs = `ps auxww | grep -v grep | grep httpd | grep -c ipr_server `);
        chop($iprb = `ps auxww | grep -v grep | grep httpd | grep -c brs_responder `);
	print "total:$total ipr_server:$iprs brs_responder:$iprb";
}
sub WL {
        chop($total = ` ps ax | grep -v grep | grep -c : `);
        chop($http = `ps auxww | grep -v grep | grep -c httpd `);
	print "total:$total http:$http";
}
sub DEFAULT {
        chop($total = ` ps ax |  grep -v grep | grep -c : `);
	print "total:$total";
}
