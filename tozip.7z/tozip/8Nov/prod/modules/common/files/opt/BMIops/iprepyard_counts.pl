#!/usr/bin/perl

use strict;
use warnings;

=pod

=head1 NAME

iprepyard_counts.pl - Generate metadata for populate_ipryd_counts.pl on IPRepyard host

=head1 SYNOPSIS

iprepyard_counts.pl [interval]

=head1 DESCRIPTION

This script runs on the IPRepyard systems.   The default of C<10> is assumed for the runtime
interval unless a different interval (integer) is specified on the command line.  This script
must be run privileged so that it may C<su> to the C<postgres> user-id.

=cut

BEGIN {
    use lib "/opt/iprepyard/lib";
}

use Sys::Hostname;
use IPRepyard::Config;
use IPRepyard::Site;

my $config = IPRepyard::Config->new();
my $min    = shift @ARGV || 10;
my $table  = "iprepyard";
my $master = IPRepyard::Site->i_am_the_master($config);

my $now   = time();
my $intvl = $now - int( $now % ( $min * 60 ) );

my $host  = hostname();
die("I am not an IPREPYARD host (do not match wl-ipryd or stg-wl-ipryd)\n")
    unless ( $host =~ /^(?:stg-)?wl-ipryd\d+/ );

my ($dc)  = $host =~ /\.(\S+)$/;
$dc = lc($dc);

my $sql   = sprintf 
    q{SELECT COUNT(*) FROM %s},
    $table;

my $cmd   = sprintf 
    q{/bin/su - postgres -c "/usr/bin/psql --pset tuples_only --port=5431 --command='%s' iprepyard"},
    $sql;

my $count = qx{$cmd};
$count =~ s/^\s*|\s*$//g;

printf "INTERVAL=%s\n", $intvl;
printf "COUNT=%s\n", $count;
printf "NODE=%s\n", $host;
printf "DC=%s\n", $dc;
printf "MASTER=%s\n", ( $master ) ? "Y" : "N";

exit(0);

