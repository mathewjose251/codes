#!/bin/sh
#
# Requires /root/check_throughput.sh be running in cron on the system
# (13Aug09 - running on bloc-db20.sac and bloc-db30.tuc)
#
# /root/check_throughput.sh creates the output file /var/tmp/rcmd.log
#

  tail -1 /var/tmp/bloc-alert.log | awk '{print $6,$7}'

