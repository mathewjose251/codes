#!/bin/sh
LOCKDIR=/var/lock/ard_sync
LOCKFILE=$LOCKDIR/lists_rsync-$1.lock
LOG=/var/log/rsynclog/lists-$1.log
HOST=$1

if [ "X$1" == "X" ]
then
   echo "Usage: $0 hostname"
   exit
fi

if [ ! -d $LOCKDIR ]
then 
   echo "$LOCKDIR does not exist. exiting."
   exit
fi

# test for an existing lockfile.  If the lockfile's there, test
# whether the pid still exists.  This isn't perfect, but if the rsync
# dies badly we should recover the next time the cron job kicks off
if [ -f "$LOCKFILE" ]; then
    ps -p `cat $LOCKFILE` > /dev/null && exit 0
fi

# get the lock
echo $$ > $LOCKFILE

# rsync forever
CMD="/usr/bin/rsync -e ssh -av --stats --exclude=.* --exclude=*.tmp* --exclude=zombie.txt* --update $HOST:/space/orabloc/htdocs/lists/ /space/orabloc/htdocs/lists/"

while true;
do
  /bin/echo "RSYNC START `/bin/date`" >> $LOG
  $CMD >> $LOG 2>&1
  /bin/echo "RSYNC END `/bin/date`" >> $LOG
  sleep 10; # or 5, but the lower the better
done

