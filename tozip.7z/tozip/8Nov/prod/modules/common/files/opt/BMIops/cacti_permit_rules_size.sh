#!/bin/bash
# cacti_permit_rules_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/permit_rules 
# /space/orabloc/htdocs/aztec/rules2/permit_rules.update
# /space/orabloc/htdocs/aztec/rules2litea/permit_rules
# /space/orabloc/htdocs/aztec/rules2litea/permit_rules.update
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/permit_rules"
file2="/space/orabloc/htdocs/aztec/rules2litea/permit_rules"
file3="/space/orabloc/htdocs/aztec/rules2/permit_rules.update"
file4="/space/orabloc/htdocs/aztec/rules2litea/permit_rules.update"

if ( [ -f $file1 ] && [ -f $file2 ] && [ -f $file3 ] && [ -f $file4 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"
	fs3="`/bin/ls -l $file3 | /bin/gawk -F " " '{print $5}'`"
	fs4="`/bin/ls -l $file4 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
	echo "PR:0 PR2:0 PRU:0 PR2U:0"
	exit 1
fi

echo PR:$fs1 PR2:$fs2 PRU:$fs3 PR2U:$fs4
