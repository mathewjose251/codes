#!/bin/bash
# cacti_spamhunter_size.sh
# Script for Cacti to graph the size of:
# /space/orabloc/htdocs/aztec/rules2/spamhunter 
# /space/orabloc/htdocs/aztec/rules2/spamhunter.update
#
# See HD0000002289321 for details on the request.

file1="/space/orabloc/htdocs/aztec/rules2/spamhunter"
file2="/space/orabloc/htdocs/aztec/rules2/spamhunter.update"

if ( [ -f $file1 ] && [ -f $file2 ] )
then
	fs1="`/bin/ls -l $file1 | /bin/gawk -F " " '{print $5}'`"
	fs2="`/bin/ls -l $file2 | /bin/gawk -F " " '{print $5}'`"

else
	# If the file does not exist, we will graph a 0
	echo "SH:0 SHU:0"
	exit 1
fi

echo SH:$fs1 SHU:$fs2 
