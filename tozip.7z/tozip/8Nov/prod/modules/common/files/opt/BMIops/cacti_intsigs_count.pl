#!/opt/perl/bin/perl

##
## $Id: cacti_intsigs_count.pl,v 1.1 2018/10/30 10:11:57 mathew Exp $
## $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/opt/BMIops/cacti_intsigs_count.pl,v $
##

## NOTE: This script must be executed on a host that has the blocperl and bloctools packages installed ##

=pod

  SYMANTEC PROPRIETARY/CONFIDENTIAL--INTERNAL USE ONLY
  Copyright (c) 2011 Symantec Corporation.  All rights reserved.

=head1 NAME

cacti_intsigs_count.pl - Count the BS3 rulesets per rule package

=head1 SYNOPSIS

cacti_intsigs_count.pl [-sE<verbar>--skip=comma-sep-pkg-list]

=head1 OPTIONS

The B<-s> option constrains the BS3 rule count by omitting any packages named in the comma-separated
list supplied by this argument.

=head1 EXAMPLE

cacti_intsigs_count.pl --skip='facebook, ccone'

=head1 DESCRIPTION

This prints (to stdout) the intsig rule count for every package in the WALLS table that matches the
reference wall defined by the variable C<$REF_PREFIX>.  At the time this script was written that variable
defaults to B<aztec_reference_wall_intsig>.

The rule count is obtained by querying against the BLOC PROPAGATION_HISTORY table

=cut

use strict;
use warnings;

use File::Basename;
BEGIN { require "/space/orabloc/server/conf/inc.pl" }

use BLOC::DB;
use BLOC::DB::Tools qw(:all);
use Getopt::Long;

my $REF_PREFIX = 'aztec_reference_wall_intsig_';

sub main {
    my ($skiplist) = @_;
    my @skips  = map {
        $_ =~ /^${REF_PREFIX}/ ? $_ : "${REF_PREFIX}$_"
    } grep { $_ } split( /\s*,\s*/, $skiplist ) if $skiplist;

    my $db = eval { BLOC::DB->db() };
    die("Error connecting to database: $@\n") if $@;

    ##
    ## Prepare the SQL query and get a wall list
    ##
    my $query = prepare_prop_query($db);
    my $walls = fetch_wall_names($db);
    die("No aztec reference walls for intsigs exist!?\n") unless defined $walls;

    ##
    ## At this point it's as easy as deleting any walls that should be skipped
    ##
    delete @{$walls}{@skips} if @skips;

    ##
    ## Iterate over all of the results and query the rule_count from
    ## propagation_history.  The keys rule_count and wall_intsig_name are written into
    ## the hash.
    ##
    for my $wall ( keys %$walls ) {
        $query->execute( $walls->{$wall}->{wall_id} );
        $walls->{$wall}->{rule_count} = ( $query->fetchrow_array || 0 )[0];
        ##
        ## Create a "simple" intsig name
        ##
        ( $walls->{$wall}->{wall_intsig_name} = $walls->{$wall}->{wall_name} )
          =~ s/^${REF_PREFIX}//;
    }

    ##
    ## Dump the results in a cacti-happy format
    ##
    printf STDOUT join(
        ' ' => map( {
                sprintf(
                    '%s:%s' =>
                    $_->{wall_intsig_name},
                    $_->{rule_count},
                )
            }
            sort { $a->{wall_intsig_name} cmp $b->{wall_intsig_name} }
              values(%$walls) )
    );
    return 0;
}

sub prepare_prop_query {
    my ($db) = @_;
    my $query = $db->prepare(
        qq[
            SELECT rule_count
            FROM   propagation_history
            WHERE  prop_history_id = (
                SELECT MAX(prop_history_id)
                FROM   propagation_history
                WHERE  wall_id = ?
            )
        ]
    );
    return $query;
}

sub fetch_wall_names {
    my ($db) = @_;
    my $sth = dbi_prepare_and_exec(
        $db,
        DBI_CACHE_STMT,
        qq[
            SELECT w.wall_name, w.wall_id
            FROM walls w
            WHERE wall_name LIKE '${REF_PREFIX}%'
        ]
    );

    my %walls = dbi_fetch_hoh($sth);
    return \%walls;
}

my $skiplist;
GetOptions( 's|skip=s', \$skiplist );
exit( main($skiplist) );

