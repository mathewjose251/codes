#!/usr/bin/perl
# $Header: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/opt/BMIops/cacti_ruleset_timeliness.pl,v 1.1 2018/10/30 10:11:57 mathew Exp $
#This is used by cactic to check ruleset timeliness
#To debug use the following
#perl  ./cacti_ruleset_timeliness.pl 1 1 hostname file_path
#e.g perl  ./cacti_ruleset_timeliness.pl 1 1 bt-prob-00001 /home/wlee/tmp 
#

use Time::Local;
# Define global variable here #
my ($host,$cluster,$time,$DEBUG,$TRACE,%RULESETS,$root_dir);
$DEBUG = $ARGV[0];
$TRACE = $ARGV[1];
$time=timelocal(localtime);
chomp($host=`uname -n`);
$host =  $ARGV[2] if ($DEBUG);
$root_dir = $ARGV[3]  if ($DEBUG);
# Define global variable here #


# Validate the hostname
SWITCH:
{
  if ($host =~ /^mx-/){
	$cluster=MX;
	last SWITCH;
	}
  if ($host =~ /^bt-prop/){
	$cluster=BT_PROP;
	last SWITCH;
	}
  if ($host =~ /^aztec/){
	$cluster=AZ;
	last SWITCH;
	}
  if ($host =~ /^rda/){
	$cluster=RDA;
	last SWITCH;
	}
  if ($host =~ /^rules/){
	$cluster=RDA;
	last SWITCH;
	}
  if ($host =~ /^junkyard/){
	$cluster=JUNK;
	last SWITCH;
	}
  if ($host =~ /^bt-ard/){
	$cluster=BT_ARD;
	last SWITCH;
	}
  # DEFAULT: Die if we can't figure out what the os is
  die "Can't figure out which OS the machine is.\n";
}

# Execute the appropriate subroutine based on the os
&$cluster;

exit(0);

#===============================================================
# Subroutines: names of subroutines are supported host cluster .
#===============================================================
sub MX {
	&no_check;
}
sub BT_PROP {
	my ($blrm,$hashes,$permit_rules,$spamsig,$spamsig2);	
	my ($spamhunter,$av);
	if (-e "$root_dir/space/orabloc/tmp/hotmail/blrm") {
		$blrm = "$root_dir/space/orabloc/tmp/hotmail/blrm";
		($RULESETS{blrm}[0], $RULESETS{blrm}[1]) = &timeliness($blrm);
		print "[SUB $cluster - BLRM] $RULESETS{blrm}[0],$RULESETS{blrm}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/tmp/hotmail/hashes") {
		$hashes = "$root_dir/space/orabloc/tmp/hotmail/hashes";
		($RULESETS{hashes}[0], $RULESETS{hashes}[1]) = &timeliness($hashes);
		print "[SUB $cluster - HASHES] $RULESETS{hashes}[0],$RULESETS{hashes}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/tmp/12341/permit_rules") {
		$permit_rules = "$root_dir/space/orabloc/tmp/12341//permit_rules";
		($RULESETS{permit_rules}[0], $RULESETS{permit_rules}[1]) = &timeliness($permit_rules);
		print "[SUB $cluster - PERMIT_RULES] $RULESETS{permit_rules}[0],$RULESETS{permit_rules}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/tmp/hotmail/spamsigs") {
		$spamsig = "$root_dir/space/orabloc/tmp/hotmail/spamsigs";
		($RULESETS{spamsig}[0], $RULESETS{spamsig}[1]) = &timeliness($spamsig);
		print "[SUB $cluster - SPAMSIG] $RULESETS{spamsig}[0],$RULESETS{spamsig}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/tmp/hotmail/spamsigs.2") {
		$spamsig2 = "$root_dir/space/orabloc/tmp/hotmail/spamsigs.2";
		($RULESETS{spamsig2}[0], $RULESETS{spamsig2}[1]) = &timeliness($spamsig2);
		print "[SUB $cluster - SPAMSIG2] $RULESETS{spamsig2}[0],$RULESETS{spamsig2}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/tmp/hotmail/spamhunter") {
		$spamhunter = "$root_dir/space/orabloc/tmp/hotmail/spamhunter";
		($RULESETS{spamhunter}[0], $RULESETS{spamhunter}[1]) = &timeliness($spamhunter);
		print "[SUB $cluster - SPAMHUNTER] $RULESETS{spamhunter}[0],$RULESETS{spamhunter}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/tmp/1115/av") {
		$av = "$root_dir/space/orabloc/tmp/1115/av";
		($RULESETS{av}[0], $RULESETS{av}[1]) = &timeliness($av);
		print "[SUB $cluster - AV] $RULESETS{av}[0],$RULESETS{av}[1]\n" if ($TRACE);
	}
	&print_output;
}
sub AZ {
	my ($blrm,$hashes,$permit_rules,$spamsig,$spamsig2);	
	my ($spamhunter,$av,$spamhunter2,$spamnhunter3);
	if (-e "$root_dir/var/aztec/htdocs/rules/blrm.bin.gz") {
		$blrm = "$root_dir/var/aztec/htdocs/rules/blrm.bin.gz";
		($RULESETS{blrm}[0], $RULESETS{blrm}[1]) = &timeliness($blrm);
		print "[SUB $cluster - BLRM] $RULESETS{blrm}[0],$RULESETS{blrm}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/hashes.bin.gz") {
		$hashes = "$root_dir/var/aztec/htdocs/rules/hashes.bin.gz";
		($RULESETS{hashes}[0], $RULESETS{hashes}[1]) = &timeliness($hashes);
		print "[SUB $cluster - HASHES] $RULESETS{hashes}[0],$RULESETS{hashes}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/permit_rules.bin.gz") {
		$permit_rules = "$root_dir/var/aztec/htdocs/rules/permit_rules.bin.gz";
		($RULESETS{permit_rules}[0], $RULESETS{permit_rules}[1]) = &timeliness($permit_rules);
		print "[SUB $cluster - PERMIT_RULES] $RULESETS{permit_rules}[0],$RULESETS{permit_rules}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/spamsigs.bin.gz") {
		$spamsig = "$root_dir/var/aztec/htdocs/rules/spamsigs.bin.gz";
		($RULESETS{spamsig}[0], $RULESETS{spamsig}[1]) = &timeliness($spamsig);
		print "[SUB $cluster - SPAMSIG] $RULESETS{spamsig}[0],$RULESETS{spamsig}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/spamsigs.2.bin.gz") {
		$spamsig2 = "$root_dir/var/aztec/htdocs/rules/spamsigs.2.bin.gz";
		($RULESETS{spamsig2}[0], $RULESETS{spamsig2}[1]) = &timeliness($spamsig2);
		print "[SUB $cluster - SPAMSIG2] $RULESETS{spamsig2}[0],$RULESETS{spamsig2}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/spamhunter.bin.gz") {
		$spamhunter = "$root_dir/var/aztec/htdocs/rules/spamhunter.bin.gz";
		($RULESETS{spamhunter}[0], $RULESETS{spamhunter}[1]) = &timeliness($spamhunter);
		print "[SUB $cluster - SPAMHUNTER] $RULESETS{spamhunter}[0],$RULESETS{spamhunter}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/spamhunter.2.bin.gz") {
		$spamhunter2 = "$root_dir/var/aztec/htdocs/rules/spamhunter.2.bin.gz";
		($RULESETS{spamhunter2}[0], $RULESETS{spamhunter2}[1]) = &timeliness($spamhunter2);
		print "[SUB $cluster - SPAMHUNTER2] $RULESETS{spamhunter2}[0],$RULESETS{spamhunter2}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/spamhunter.3.bin.gz") {
		$spamhunter3 = "$root_dir/var/aztec/htdocs/rules/spamhunter.3.bin.gz";
		($RULESETS{spamhunter3}[0], $RULESETS{spamhunter3}[1]) = &timeliness($spamhunter3);
		print "[SUB $cluster - SPAMHUNTER3] $RULESETS{spamhunter3}[0],$RULESETS{spamhunter3}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/var/aztec/htdocs/rules/av.symantec.linux.i386.bin.gz") {
		$av = "$root_dir/var/aztec/htdocs/rules/av.symantec.linux.i386.bin.gz";
		($RULESETS{av}[0], $RULESETS{av}[1]) = &timeliness($av);
		print "[SUB $cluster - AV] $RULESETS{av}[0],$RULESETS{av}[1]\n" if ($TRACE);
	}
	&print_output;
}
sub BT_ARD {
	my ($blrm,$hashes,$permit_rules,$spamsig,$spamsig2);	
	my ($spamhunter,$av,$spamhunter2,$spamnhunter3);
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/blrm") {
		$blrm = "$root_dir/space/orabloc/htdocs/aztec/rules2/blrm";
		($RULESETS{blrm}[0], $RULESETS{blrm}[1]) = &timeliness($blrm);
		print "[SUB $cluster - BLRM] $RULESETS{blrm}[0],$RULESETS{blrm}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/hashes") {
		$hashes = "$root_dir/space/orabloc/htdocs/aztec/rules2/hashes";
		($RULESETS{hashes}[0], $RULESETS{hashes}[1]) = &timeliness($hashes);
		print "[SUB $cluster - HASHES] $RULESETS{hashes}[0],$RULESETS{hashes}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/permit_rules") {
		$permit_rules = "$root_dir/space/orabloc/htdocs/aztec/rules2/permit_rules";
		($RULESETS{permit_rules}[0], $RULESETS{permit_rules}[1]) = &timeliness($permit_rules);
		print "[SUB $cluster - PERMIT_RULES] $RULESETS{permit_rules}[0],$RULESETS{permit_rules}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/spamsigs") {
		$spamsig = "$root_dir/space/orabloc/htdocs/aztec/rules2/spamsigs";
		($RULESETS{spamsig}[0], $RULESETS{spamsig}[1]) = &timeliness($spamsig);
		print "[SUB $cluster - SPAMSIG] $RULESETS{spamsig}[0],$RULESETS{spamsig}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/spamsigs.2") {
		$spamsig2 = "$root_dir/space/orabloc/htdocs/aztec/rules2/spamsigs.2";
		($RULESETS{spamsig2}[0], $RULESETS{spamsig2}[1]) = &timeliness($spamsig2);
		print "[SUB $cluster - SPAMSIG2] $RULESETS{spamsig2}[0],$RULESETS{spamsig2}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/spamhunter") {
		$spamhunter = "$root_dir/space/orabloc/htdocs/aztec/rules2/spamhunter";
		($RULESETS{spamhunter}[0], $RULESETS{spamhunter}[1]) = &timeliness($spamhunter);
		print "[SUB $cluster - SPAMHUNTER] $RULESETS{spamhunter}[0],$RULESETS{spamhunter}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/spamhunter.2") {
		$spamhunter2 = "$root_dir/space/orabloc/htdocs/aztec/rules2/spamhunter.2";
		($RULESETS{spamhunter2}[0], $RULESETS{spamhunter2}[1]) = &timeliness($spamhunter2);
		print "[SUB $cluster - SPAMHUNTER2] $RULESETS{spamhunter2}[0],$RULESETS{spamhunter2}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/spamhunter.3") {
		$spamhunter3 = "$root_dir/space/orabloc/htdocs/aztec/rules2/spamhunter.3";
		($RULESETS{spamhunter3}[0], $RULESETS{spamhunter3}[1]) = &timeliness($spamhunter3);
		print "[SUB $cluster - SPAMHUNTER3] $RULESETS{spamhunter3}[0],$RULESETS{spamhunter3}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/space/orabloc/htdocs/aztec/rules2/av.symantec.linux.i386") {
		$av = "$root_dir/space/orabloc/htdocs/aztec/rules2/av.symantec.linux.i386";
		($RULESETS{av}[0], $RULESETS{av}[1]) = &timeliness($av);
		print "[SUB $cluster - AV] $RULESETS{av}[0],$RULESETS{av}[1]\n" if ($TRACE);
	}
	&print_output;
}
sub RDA {
	my ($blrm,$hashes,$permit_rules,$spamsig,$spamsig2);	
	my ($spamhunter,$av);
	if (-e "$root_dir/apache/rda/hotmail/blrm") {
		$blrm = "$root_dir/apache/rda/hotmail/blrm";
		($RULESETS{blrm}[0], $RULESETS{blrm}[1]) = &timeliness($blrm);
		print "[SUB $cluster - BLRM] $RULESETS{blrm}[0],$RULESETS{blrm}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/apache/rda/hotmail/hashes") {
		$hashes = "$root_dir/apache/rda/hotmail/hashes";
		($RULESETS{hashes}[0], $RULESETS{hashes}[1]) = &timeliness($hashes);
		print "[SUB $cluster - HASHES] $RULESETS{hashes}[0],$RULESETS{hashes}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/apache/rda/12341/permit_rules") {
		$permit_rules = "$root_dir/apache/rda/12341/permit_rules";
		($RULESETS{permit_rules}[0], $RULESETS{permit_rules}[1]) = &timeliness($permit_rules);
		print "[SUB $cluster - PERMIT_RULES] $RULESETS{permit_rules}[0],$RULESETS{permit_rules}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/apache/rda/hotmail/spamsigs") {
		$spamsig = "$root_dir/apache/rda/hotmail/spamsigs";
		($RULESETS{spamsig}[0], $RULESETS{spamsig}[1]) = &timeliness($spamsig);
		print "[SUB $cluster - SPAMSIG] $RULESETS{spamsig}[0],$RULESETS{spamsig}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/apache/rda/hotmail/spamsigs.2") {
		$spamsig2 = "$root_dir/apache/rda/hotmail/spamsigs.2";
		($RULESETS{spamsig2}[0], $RULESETS{spamsig2}[1]) = &timeliness($spamsig2);
		print "[SUB $cluster - SPAMSIG2] $RULESETS{spamsig2}[0],$RULESETS{spamsig2}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/apache/rda/hotmail/spamhunter") {
		$spamhunter = "$root_dir/apache/rda/hotmail/spamhunter";
		($RULESETS{spamhunter}[0], $RULESETS{spamhunter}[1]) = &timeliness($spamhunter);
		print "[SUB $cluster - SPAMHUNTER] $RULESETS{spamhunter}[0],$RULESETS{spamhunter}[1]\n" if ($TRACE);
	}
	if (-e "$root_dir/apache/rda/1115/av") {
		$av = "$root_dir/apache/rda/1115/av";
		($RULESETS{av}[0], $RULESETS{av}[1]) = &timeliness($av);
		print "[SUB $cluster - AV] $RULESETS{av}[0],$RULESETS{av}[1]\n" if ($TRACE);
	}
	&print_output;
}
sub DB {
	&no_check;
}
sub JUNK {
	&no_check;
}
sub no_check {
	print "$cluster is NOT required to check ruleset\n";
	exit 0;
}
#Get file stats and timeliness
sub timeliness {
	my ($file,@FILE_TIMELINESS,$file_readtime,$file_writetime);
	$file = shift;
	($file_readtime,$file_writetime) =  (stat($file))[8,9];
	print "[SUB TIMELINESS] $file_readtime,$file_writetime\n" if ($TRACE);
	$FILE_TIMELINESS[1] = ($time - $file_writetime) / 60;
	$FILE_TIMELINESS[0] = ($time - $file_readtime) /60;
	print "[SUB TIMELINESS] @FILE_TIMELINESS\n" if ($TRACE);
	return @FILE_TIMELINESS;
}
#Print required format for cacti
sub print_output {
        print "blrm:$RULESETS{blrm}[1] ";
        print "hashes:$RULESETS{hashes}[1] ";
        print "permit_rules:$RULESETS{permit_rules}[1] ";
        print "spamsig:$RULESETS{spamsig}[1] ";
        print "spamsig2:$RULESETS{spamsig2}[1] ";
        print "spamhunter:$RULESETS{spamhunter}[1] ";
        print "av:$RULESETS{av}[1] ";
        print "spamhunter2:$RULESETS{spamhunter2}[1] ";
        print "spamhunter3:$RULESETS{spamhunter3}[1]";
        print "\n" if ($TRACE);
}
                
