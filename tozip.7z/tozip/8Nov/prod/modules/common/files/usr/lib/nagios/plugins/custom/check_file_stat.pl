#!/usr/bin/perl -w
# $Id: check_file_stat.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $

# check_file.pl Copyright (C) 2003 Steven Grimm <koreth-nagios@midwinter.com>
#
# Checks a file's size and modification time to make sure it's not empty
# and that it's sufficiently recent.
#
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# you should have received a copy of the GNU General Public License
# along with this program (or with Nagios);  if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA

use strict;
use English;
use Getopt::Long;
use File::stat;
use File::Find;
use vars qw($PROGNAME);

use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS &print_revision &support);

sub print_help ();
sub print_usage ();

use vars
  qw($opt_r @opt_d @opt_D $opt_a $opt_s $opt_h $opt_V $opt_m @opt_e $opt_v $opt_t $opt_T @files);
my ( @finalResult, @splitArg, @ltime, @age );
my ( $string, $fileName, $timeMax, $sizeMax, $timedef, $timeWarn, $sizeMin );
my ( $time, $size, $exitStatus, $st, $print, $textSep, $nofile );
my ( $badsizeMax, $badsizeMin, $badtimeWarn, $badtimeMax );
my ( $dir, $mailwall );

$exitStatus = $ERRORS{'WARNING'};
$textSep    = ',';
$PROGNAME   = 'check_file_stat.pl';

Getopt::Long::Configure('bundling');
GetOptions(
    "V"               => \$opt_V,
    "version"         => \$opt_V,
    "h"               => \$opt_h,
    "help"            => \$opt_h,
    "r=s"             => \$opt_r,
    "regex"           => \$opt_r,
    "d=s@"            => \@opt_d,
    "dir=s@"          => \@opt_d,
    "D=s@"            => \@opt_D,
    "exludeDir=s@"    => \@opt_D,
    "a=s"             => \$opt_a,
    "age=s"           => \$opt_a,
    "m"               => \$opt_m,
    "mailwall"        => \$opt_m,
    "e=s@"            => \@opt_e,
    "excludeRegex=s@" => \@opt_e,
    "s=s"             => \$opt_s,
    "size=s"          => \$opt_s,
    "v=s"             => \$opt_v,
    "t"               => \$opt_t,
    "tempfiles"       => \$opt_t,
    "T=s"	      => \$opt_T,
);

if ($opt_V) {
    print_revision( $PROGNAME,
        '$Id: check_file_stat.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $' );
    exit $ERRORS{'OK'};
}

# Set these so we don't get complaints
$opt_a = ',' if ( !$opt_a );
$opt_s = ''  if ( !$opt_s );

if ($opt_h) {
    print_help();
    exit $ERRORS{'OK'};
}

# Make sure that we have all of the arguments necessary
if ( @opt_d and !$opt_r ) {
    print "CRITICAL - When specifying a dir, you must also give a regex.\n";
    exit $ERRORS{'CRITICAL'};
}
elsif ( $opt_r and !@opt_d ) {
    print "CRITICAL - When specifying a regex, you must also give a dir.\n";
    exit $ERRORS{'CRITICAL'};
}
if ( !@ARGV and !@opt_d ) {
    print "ERROR: Missing argument\n";
    print_help();
    exit $ERRORS{'UNKNOWN'};
}

#
# This allows someone to do nifty template path formulation so you do not have to specifiy multiple long
# directory arguments with -d.  For example:
# check_file_stat.pl -T /opt/spamlab-markup/brightmail%s/bm_ruleset.2.intsig_rules -m \
#   -d bs2,bs3,hr,hash -r '^intsigs$'
#
# This will expand the -d file list (@opt_d) into:
#
# /opt/spamlab-markup/brightmailbs2/bm_ruleset.2.intsig_rules
# /opt/spamlab-markup/brightmailbs3/bm_ruleset.2.intsig_rules
# /opt/spamlab-markup/brightmailhr/bm_ruleset.2.intsig_rules
# /opt/spamlab-markup/brightmailhash/bm_ruleset.2.intsig_rules
#
if ( $opt_T && @opt_d ) {
    my @new_opt_d = ();
    for my $d_part ( @opt_d ) {
	push @new_opt_d, map { sprintf $opt_T, $_ } ( split /\s*,\s*/, $d_part );
    }
    @opt_d = @new_opt_d if @new_opt_d;
}

# Process the command line arguments or read from STDIN
@files = @ARGV;

if (@opt_d) {

    # If this is a mailwall we need to find the right directories to check
    if ($opt_m) {
        @opt_d = find_mailwall_dir(@opt_d);
    }

    while (<@opt_d>) {
        $dir = $_;

        if ( !-d "$dir" ) {
            print "CRITICAL - $!: $dir\n";
            exit $ERRORS{'CRITICAL'};
        }
        else {
            find( \&wanted, $dir );
        }
    }

}

# Process each file and run the appropriate checks
$exitStatus = $ERRORS{'OK'};
foreach (@files) {
    chomp;
    @splitArg = split( /:/, $_ );
    $string = '';
    undef $time;
    undef $size;
    undef $nofile;
    undef $badsizeMin;
    undef $badsizeMax;
    undef $badtimeWarn;
    undef $badtimeMax;

    $fileName = shift(@splitArg);
    $timedef  = shift(@splitArg);
    @age      = split( /,/, $timedef ) if ( $timedef =~ /,/ );

    if (@age) {
        $timeWarn = shift(@age);
        $timeMax  = shift(@age);
    }
    else {
        $timeMax = $timedef;
    }
    ( $sizeMin, $sizeMax ) = split( ",", shift(@splitArg) ) if @splitArg;

    next if -d $fileName;

    if ( !-f "$fileName" ) {
        $nofile = 1;
    }

    if ( !$nofile ) {
        $st   = File::stat::stat($fileName);
        $time = $st->mtime if ($timeMax);
        $size = $st->size if ($sizeMax);
    }

    # Check file size
    if ( defined($size) and !$nofile ) {
        $badsizeMax = 1 if ( $size >= $sizeMax );
        $badsizeMin = 1 if ( $size <= $sizeMin );
    }

    # Check file mod time
    if ( $time and !$nofile ) {
        $badtimeMax = 1 if ( ( time - $time ) >= $timeMax );
        if ($timeWarn) {
            $badtimeWarn = 1
              if ( $timeWarn && ( time - $time ) >= $timeWarn );
        }
    }

    # Set the exit status and never let it go below critical
    $exitStatus = $ERRORS{'CRITICAL'} if ($nofile);
    $exitStatus = $ERRORS{'CRITICAL'} if ($badsizeMax);
    $exitStatus = $ERRORS{'CRITICAL'} if ($badsizeMin);
    $exitStatus = $ERRORS{'CRITICAL'} if ($badtimeMax);
    if ( $exitStatus != $ERRORS{'CRITICAL'} and $badtimeWarn ) {
        $exitStatus = $ERRORS{'WARNING'};
    }

    $string .= " $fileName Does not exist$textSep" if ($nofile);

    if ($badsizeMax) {
        $string .= "$fileName ($size bytes) is too big";
        $string .= "$textSep";
    }
    elsif ($badsizeMin) {
        $string .= "$fileName ($size bytes) is too small";
        $string .= "$textSep";
    }

    if ( $badtimeWarn or $badtimeMax ) {
        $string .= "$fileName is ";
        $string .= time_diff($time) . " old";
        $string .= "$textSep";
    }

    push( @finalResult, $string ) if ($string);

}

# Properly format what is going to be printed
foreach ( keys(%ERRORS) ) {
    chomp $_;
    unshift( @finalResult, "$_ -" ) if ( $ERRORS{$_} == $exitStatus );
}

if ( $exitStatus == $ERRORS{'OK'} ) {
    undef $string;

    if ($timeWarn) {
        $string = "All files updated in the last";
        $string .= " $timeWarn secs";
        $string .= "$textSep";
    }
    elsif ($timeMax) {
        $string = " All files updated in the last";
        $string .= " $timeMax secs";
        $string .= "$textSep";
    }

    push( @finalResult, $string ) if ($string);
    undef $string;

    if ($sizeMax) {
        $string =
          "All files within size threshold (Min:$sizeMin,Max:$sizeMax bytes)";
        $string .= "$textSep";
    }

    push( @finalResult, $string ) if ($string);
    undef $string;
}

# Reformat the final result so that it prints properly
$print = join( ' ', @finalResult );
chop($print) if ( $print =~ /^.*$textSep$/ );
$print .= '.';

# Print the output and exit
print "$print\n";
exit $exitStatus;

# Fancy-shmancy subroutines for the whole family
sub wanted() {
    my $currentFile = "$_";
    my $baseDir     = "$File::Find::dir";
    my $index       = 0;
    my $found       = 0;

    # Ignore dot files
    return 1 if $currentFile =~ m/^\.\.?/;

    # Handle vcdiff directories
    if ( $opt_v and $baseDir =~ /$opt_v/ ) {
        return 1 if ( $currentFile !~ /latest/ );
    }
    else {
        return 1 if ( $currentFile !~ /$opt_r/ or $currentFile eq '.' );
    }

    if (@opt_D) {
        return 1 if map { $baseDir =~ /$_/ } @opt_D;
    }

    if ( defined(@opt_e) ) {
        foreach my $ex (@opt_e) {
            return 1 if ( $currentFile =~ /$ex/ );
        }
    }

    ##
    ## Hardcode our loathe of tmp file alerts directly into the code
    return 1 if ( !defined($opt_t) && $currentFile =~ m/\.tmp(?:\.gz)?$/ );

    if ( $#files >= 0 ) {
        foreach $index ( 0 .. $#files ) {
            next if ( $files[$index] !~ /$currentFile$/ );
            $found++;
            last;
        }
        push( @files, "$baseDir/$currentFile:$opt_a:$opt_s" ) if ( !$found );
    }
    else {
        push( @files, "$baseDir/$currentFile:$opt_a:$opt_s" );
    }
    return 0;
}

sub find_mailwall_dir {
    my ( $mw_dir, $mw_prefix );
    my ( $file,   @dirs );
    my $latest;

    while (<@_>) {
	$latest = '';
        ( $mw_dir, $mw_prefix ) = /(\S+)\/(.*\z)/;
        opendir( DIR, "$mw_dir" );
        while ( $file = readdir(DIR) ) {
            next unless ( -d "$mw_dir/$file" );
            if ( $file =~ /$mw_prefix.*$/ ) {
                if ( $file gt $latest ) {
                    $latest = $file;
                }
            }
        }
        push( @dirs, "$mw_dir/$latest" ) if -d "$mw_dir/$latest";
    }
    return @dirs;
}

sub time_diff {
    my ( $then, $now, $diff, $sec, $min, $hours, @time_vals );

    $then = shift || 0;

    @time_vals = qw(hours min sec);
    $now       = time();
    $diff      = ( $now - $then );
    $sec       = $diff % 60;
    $diff      = ( $diff - $sec ) / 60;
    $min       = $diff % 60;
    $hours     = ( $diff - $min ) / 60;

    while (<@time_vals>) {
        if ( eval "\$$_" < 10 ) {
            eval "\$$_ = '0'.\$$_";
        }
    }

    return "$hours:$min:$sec";
}

sub print_usage () {
    print "Usage:\n";
    print "  $PROGNAME [options] file[:[secsWarn,secsMax]:[bytes]] ...\n";
    print "  $PROGNAME [-h | --help]\n";
    print "  $PROGNAME [-V | --version]\n";
    print
"  $PROGNAME [-d dir -D exlude_dir_regex -r regex -e exclude_file_regex -a secsWarn,secsMax -s sizeMin,sizeMax -v vcdiff_regex]\n";
}

sub print_help () {
    print_revision( $PROGNAME,
        '$Id: check_file_stat.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $' );
    print "Copyright (c) 2005 Symantec\n\n";
    print_usage();
    print "\n";
    print
      "  <secs>,<secs>  File must be no more than this many seconds old\n";
    print "  <bytes>  File size must be no more than this many bytes\n";
    print "  For secs: First value is the warning age and second value is\n";
    print "  the critical age.  If only one value is given then it's the\n";
    print "  critical age.\n";
    print "\n";
    support();
}

