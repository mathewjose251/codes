#!/usr/bin/perl

# Functions for various parsing routines

# Find out where our basedir is from where the parent script resides
use FindBin qw($Bin);

# Where our libraries are
use lib "$Bin/../lib";

# Everything needs this
require "libmain.pl";

# Debugging variables
use vars qw($DEBUG $debugLevel $debugPrepend);

# Import the common constants
require "TableOfConstants";

# Returns a hash with a set of configuration variables and their values.
# One required argument and one optional argument.
# First argument is a file, second optional argument is a section of the
# file.  The sections are delimited by "[$section]".
# Returns greater than zero as a hash with the results if any results
# came about.  Returns null/false otherwise.
sub getConfig() {
	my $fileName	= shift;
	my $section		= shift;
	my (
		%return,
		@entry
	);
	my (
		$fileHandle,
		$key,
		$value,
		$myFunc
	);

	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n"	if ($DEBUG);

	# If the given file does not exist, exit with a value of zero
	return %return		if (! -e "$fileName");

	# Open the file and get a filehandle
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": Opening file: $fileName\n"	if ($DEBUG); 
	$fileHandle		= openFile($fileName);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": File handle for $fileName: $fileHandle\n"	if ($DEBUG); 

	# Open a loop on the filehandle and start processing input
	while (<$fileHandle>) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": While loop, processing: $_"	if ($DEBUG); 
		next if /^#|^\s+/;			# Skip if the line is a comment or empty
		# If a section was specified, skip until we find the section
		next if (! /^\[$section\]/ and $section gt 1);
		# If the section is still a value greater than zero and matches the
		# line, set $section to zero and skip to the next line
		if ($section gt 1 and /^\[$section\]/) {
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				": Found '[$section]' in config\n"	if ($DEBUG); 
			$section		= 1;
			next;
		}
		# If $section is set to zero, it means that we found the section
		# and are currently reading the lines in, but we want to stop
		# reading once we reach the next section
		last if (/^\[/ and $section == 1);
		chomp $_;
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": Processing line: $_\n"	if ($DEBUG); 
		# Our configuration files should be in a key=value format, so
		# we need to split the line at the '=' and toss the two pieces
		# into the appropriate variables to use later
		@entry			= split(/=/, $_);
		$key			= "$entry[0]";
		$value			= "$entry[1]";
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$key=$key\n"	if ($DEBUG); 
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$value=$value\n"	if ($DEBUG); 
		# Cut out all whitespace at the end of the key (some people
		# put spaces after the key and before the '=' when editing
		# the configuration files.  Also, we want to chop out any
		# comments on the same line and in the same string as the key.
		for ($key) {
			s/^(.*)#.*/$1/;
			s/^(.*)\s+$/$1/;
		}
		# Cut out all whitespace at the beginning of the value
		# (some people put spaces after the '=' and before the
		# value) and remove all comments from the value.
		for ($value) {
			s/^\s+//;
			s/^(.*)#.*/$1/;
			s/\s+$//;
		}
		# If a key and value already exist in the return hash, append
		# this value to the existing key and use a comma to separate
		# the value from the prexisting value.
		if ($return{$key}) {
			$return{$key}		.= ",$value";
		}
		# If the key does not already exist with a value, create the
		# key and value in the return hash.
		else {
			$return{$key}		= "$value";
		}
	}
	# Close the file
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": Closing file with handle: $fileHandle\n"	if ($DEBUG); 
	closeFile($fileHandle);

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \%return=%return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 

	# Return the hash
	return %return;
}

return 1;
