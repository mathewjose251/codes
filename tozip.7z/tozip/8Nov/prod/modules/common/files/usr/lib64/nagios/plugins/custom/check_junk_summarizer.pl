#!/opt/perl/bin/perl -w
# $Id: check_junk_summarizer.pl,v 1.1 2018/10/30 10:12:01 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/check_junk_summarizer.pl,v $
#
# Program       : Junkyard summarization check
# Author        : Sean Heshmati 10/2009
# Description   : This plugin verifies that the junk summarizers are summarizing.
#
BEGIN { require "/opt/junkyard/server/conf/inc.pl" }

use strict;
use Getopt::Long qw/GetOptions/;
use BLOC::DB;
use BLOC::DB::Tools qw/:all/;

use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS &print_revision &support);

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
my $REVISION   = $1;
my $PROGNAME   = "check_junk_summarizer";
my $exitstatus = $ERRORS{'UNKNOWN'};

my ( $db, @good, @bad, $output, $opt_c, $opt_v, $opt_h );

my %queries = (
    "summarized_by_from_email" =>
      "SELECT COUNT(*) FROM messages WHERE summarized_by_from_email=0",
    "summarized_by_rcpt_domain",
    "SELECT COUNT(*) FROM messages WHERE summarized_by_rcpt_domain=0",
    "summarized_by_domain",
    "SELECT COUNT(*) FROM messages  WHERE summarized_by_domain=0"
);

GetOptions(
    "c=i" => \$opt_c,
    v     => \$opt_v,
    h     => \$opt_h
);

# process options
if ($opt_v) {
    print_revision( $PROGNAME, $REVISION );
    exit $ERRORS{'OK'};
}
elsif ($opt_h) {
    print_help();
    exit $ERRORS{'OK'};
}

unless ($opt_c) {
    print_help();
    exit $ERRORS{'UNKNOWN'};
}

# Run queries and process results
while ( my ( $title, $query ) = each(%queries) ) {
    my $count = query($query);
    if (defined($count)) {
        if ( $count > $opt_c ) {
            push( @bad, sprintf( "%s(%d)", $title, $count ) );
            $exitstatus = $ERRORS{'CRITICAL'};
        }
        else {
            push( @good, sprintf( "%s(%d)", $title, $count ) );
        }
    }
    else {
        push( @bad, sprintf( 'NO DATA: %s', $db->errstr ) );
        $exitstatus = $ERRORS{'CRITICAL'};
    }
}

# compose check output
if (@bad) {
    for my $status ( keys %ERRORS ) {
        $output = "$status - " if $ERRORS{$status} == $exitstatus;
        last if $output;
    }
    $output .= join( ", ", @bad );
}
else {
    $output = "OK - ";
    $output .= join( ", ", @good );
    $exitstatus = $ERRORS{'OK'};
}

# print final message and exit with proper status
print "$output (Critical=$opt_c)\n";
exit $exitstatus;

##############################################################################
# Subs
##############################################################################
sub query {
    my $query = shift;
    my $retval;

    if ( !$db ) {
        $db = BLOC::DB->new();
        $db->{RaiseError} = 0;
    }

    eval { $retval = dbi_exec_for_row_list( $db, $query ); };
    
    return if ($@);

    return $retval;
}

sub print_help {
    print_revision( $PROGNAME, $REVISION );
    print "\nUsage:\n";
    print "  $PROGNAME <-c max_unsummarized>\n";
    print "  $PROGNAME [-h | --help]\n";
    print "  $PROGNAME [-v | --version]\n";
    print "\nOptions:\n";
    print "  -c max_unsummarized\n";
    print "     Maximum number of unsummarized messages\n";
    print "\n";
}
