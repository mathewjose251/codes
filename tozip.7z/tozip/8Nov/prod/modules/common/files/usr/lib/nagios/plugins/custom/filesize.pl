#!/usr/bin/perl 
## $Id: filesize.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $
##	julien.touche@touche.fr.st
##
## Added use strict, warning, treshold for min size
##
## from http://www.nagiosexchange.org/NRPE_Plugins.66.0.html?&tx_netnagext_pi1[p_view]=81
#################################################
# Small quick and dirty perl example from Larry #
#################################################

use strict;

if($#ARGV+1!=3 || ! -f $ARGV[0]){
	print "Usage: \"Filename\" \"Critical filesize\" \"Warning filesize\"\n";
	print "	exemples: $0 <file> 1024 512\n";
	print "	exemples: $0 <file> 16:1024 128:512\n";
	exit 0;
}
my $exit=0;
my ($file,$maxwarn,$maxcrit,$minwarn,$mincrit);
$file = $ARGV[0];
$mincrit = $ARGV[1];
if ($mincrit =~ m/([0-9].+):([0-9].+)/) {
	$mincrit = $1;
	$maxcrit = $2;
}
$minwarn = $ARGV[2];
if ($minwarn =~ m/([0-9].+):([0-9].+)/) {
	$minwarn = $1;
	$maxwarn = $2;
}

my $size= (-s $file);

if ($size<$mincrit) {
	print "CRITICAL: Filesize of '$file' too small $size < $mincrit.\n";$exit=2;
} elsif (defined($maxcrit) && $size > $maxcrit) {
	print "CRITICAL: Filesize of '$file' too large $size > $mincrit.\n";$exit=2;
} elsif ($size<$minwarn) {
	print "WARNING: Filesize of '$file' $size < $minwarn.\n";$exit=1;
} elsif (defined($maxwarn) && $size > $maxwarn) {
	print "WARNING: Filesize of '$file' $size > $maxwarn.\n";$exit=1;
} else {
	print "OK: Filesize of '$file' $size.\n"; $exit = 0;
}
exit $exit;

