
package DNSSerial;

=pod

=head1 NAME

DNSSerial - Manipulate serial numbers in DNS SOA resource records

=head1 SYNOPSIS

  use DNSSerial;

  my $dns = DNSSerial->new( '/path/to/zone/file' );

  # Obtain current serial number
  my $serial = $dns->serial();

  # Change DNS serial number
  $dns->serial('2013091501');

  # Omit the output filename to overwrite current zone file
  # Note that the save method simply overwrites the contents of the target
  # file -- it does not paste the serial number on top of the serial number
  # of an existing zone file -- it clobbers the file and overwrites its contents.
  $dns->save( '/path/to/alternate/zone/file' );
  $dns->close();

  # If you use YYYYMMDDNN (where 'NN' is an auto increment type field)
  $dns->auto_increment();
  $dns->save();
 
  # If the date is different then auto_increment will automatically change it
  # to the current date.  These methods returns their own object so you can
  # increment, save and close in one command:
  $dns->auto_increment()->save()->close();

  # Or manipulate the fields directly
  $dns->year(2013);
  $dns->month(10);
  $dns->day(31);
  $dns->increment(1);

  $dns->save();
  $dns->close();

=head1 DESCRIPTION

This perl module envelops an API for C<getting> or C<setting> the SOA serial number in DNS zone files.

=head2 METHODS

=over

=item B<DNSSerial-E<gt>new("/var/named/chroot/var/named/mydomain.com")>

The B<new> constructor takes the name of a zone file to open and parse.  The file must exist on disk
and be readable.

=item B<$self-E<gt>auto_increment()>

DNS serial numbers ideally follow a particular format.  The B<auto_increment> and its sub-component
object methods makes use of this optional format.

The B<auto_increment> method assumes that the serial number in use follows the template:
B<YYYYMMDDNN>; where B<YYYY> is the full four digit year (century plus year), B<MM> is a two digit
zero prefixed month, <DD> is a two digit zero-prefixed day and B<NN> is a zero-prefixed increment
starting with 0 and maxing out at 99.

=item B<Accessors and Mutators>

The following accessor and mutators exist for the components of the serial number.  Passing a parameter
to these methods changes the field internally in memory.

=over

=item B<$self-E<gt>serial>

This represents the whole serial number

=item B<$self-E<gt>year>

The 4-digit year field

=item B<$self-E<gt>month([integer])>

=item B<$self-E<gt>day([integer])>

=item B<$self-E<gt>increment([integer])>

All return their current values or optionally change the current value in memory.

=back

=item B<$self-E<gt>save( [ filename ] )>

Invoking the B<save> method saves the serial number back to the originally opened zone file.  You may pass
an optional parameter -- the name of a new zone file to write the results to and the original zone file 
remains untouched.

=back

=head1 AUTHOR

L. Davis <cpan@upt.org>

=begin RCS

$Id: DNSSerial.pm,v 1.1 2018/10/30 10:12:08 mathew Exp $

=end RCS

=cut

use strict;
use warnings;
use Carp;
use IO::File;

use constant MAX_INCREMENT  => 99;

our $VERSION = (qw$Revision: 1.1 $)[ -1 ];

BEGIN {
    no strict 'refs';

    #
    # Accessor/Mutator => Field Width
    #
    my %sub_fields = (
        year        => 4,
        month       => 2,
        day         => 2,
        increment   => 2,
    );

    while (my ($meth, $width) = each %sub_fields) {
        *{$meth} = sub {
            my ($self, $data) = @_;
            my $key = sprintf('__%s', $meth);
            if (defined($data) && $data =~ /^\d+$/) {
                $self->{$key} = sprintf('%0*d', $width, $data);
                $self->{__changed} = 1;
            }
            return $self->{$key};
        };       
    }
}

sub mode {
    my ( $class, $file, $mode ) = @_;
    return unless -e $file;
    if ( defined $mode ) {
        $mode = "0${mode}" if ( $mode !~ /^0/ );
        chmod $mode, $file;
    }
    return ( stat $file )[ 2 ];
}

sub new {
    my ( $class, $zonefile ) = @_;
    return unless ( $class && $zonefile && -f $zonefile );
    my $this = {
        __zonefile => $zonefile,
        __zonemode => $class->mode( $zonefile ),
    };
    my $self = bless $this, $class;   
    $self->_init();
    return $self;
}

sub open {
    my ( $self ) = @_;
    croak(sprintf "Invalid, missing or unreadable zone file '%s'\n", $self->{__zonefile})
        unless ( -r $self->{__zonefile} );
    $self->{__contents} = 
        sub {
            my ($s) = @_;
            local(*ARGV, $/);
            @ARGV = ( $s->{__zonefile} );
            $/ = undef();
            <>
        }->( $self );
    return $self;
}

sub close {
    my ( $self ) = @_;
    delete @{ $self }{ qw[ __contents __zonefile __zonemode __changed ] };
    return $self;
}

sub _init {
    my ( $self ) = @_;
    $self->open();
    $self->serial();
    return $self;
}

sub _serial_sub_fields {
    my ( $self ) = @_;
    if ( $self->{__serial} =~ /^\d{10}$/ ) {
        @{ $self }{
            qw[
                __year __month __day __increment
            ]
        } = $self->{__serial} =~ /^(\d{4})(\d\d)(\d\d)(\d\d)$/;
    }
    return $self;
}

sub _parse_serial {
    my ( $self ) = @_;
    my ( $serial ) = $self->{__contents} =~ /\S+\s+IN\s+SOA\s+\S+\s+\S+\s+\(\s+(\d+)/ms;
    croak("Could not parse out SOA header from file contents\n")
        unless( $serial );
    if ( $serial ) {
        $self->{__serial} = $serial;
        $self->_serial_sub_fields();
    }
    return $serial;
}

sub serial {
    my ( $self, $newserial ) = @_;
    #
    # First parse the zone file and ensure there is a place to write the serial number
    # (even if we are discarding it immediately by accepting a setter for the value).
    #
    $self->_parse_serial() unless $self->{__serial};
    if ( $newserial ) {
        croak("Serial numbers must contain only numeric data.\n")
            if ($newserial =~ /\D/);

        $self->{__serial} = $newserial;
        $self->_serial_sub_fields();
        $self->{__changed} = 1;
    }
    return $self->{__serial};
}

sub auto_increment {
    my ( $self )    = @_;
    my $format      = '%04d%02d%02d';
    my ($Y, $M, $D) = ( localtime )[ 5, 4, 3 ];
    my $serial_date = sprintf( $format, $self->year, $self->month, $self->day );
    my $today       = sprintf( $format, $Y + 1900, $M + 1, $D );

    if ( $serial_date ne $today ) {
        $self->year($Y + 1900);
        $self->month($M + 1);
        $self->day($D);
        $self->increment(0);
    }
    else {
        my $inc = $self->increment();
        croak(sprintf("Current increment is already at maximum (%s)\n", MAX_INCREMENT))
            if ($inc >= MAX_INCREMENT);
        $self->increment($inc + 1);
    }

    $self->_save_serial();
    return $self;
}

sub _savefile {
    my ( $self, $file ) = @_;
    my ( $open_file, $open_mode ) = 
      ( $file && -r $file )
        ? ( $file, $self->mode( $file ) )
        : ( $self->{__zonefile}, $self->{__zonemode} );
    my $fh = IO::File->new("> $open_file");
    croak("Could not open file '$open_file': $!\n")
        unless defined($fh);
    print $fh $self->{__contents};
    $fh->close();
    $self->mode( $open_file, $open_mode );
    return $self;
}

sub _save_serial {
    my ( $self ) = @_;
    #
    # The serial number doesn't HAVE to be comprised of year/month/date/increment -- but if it is
    # then regenerate it as thus.
    #
    if ( defined($self->year) && defined($self->month) && defined($self->day) ) {
        $self->{__serial}  = 
            sprintf('%04d%02d%02d%02d', @{ $self }{ qw[__year __month __day __increment] });
    }

    return $self;
}


sub save {
    my ( $self, $alt_zone_file ) = @_;

    #
    # NOOP if nothing has changed
    #
    return $self unless $self->{__changed};

    $self->_save_serial();

    my $serial = $self->{__serial};
    $self->{__contents} =~ s/(\S+\s+IN\s+SOA\s+\S+\s+\S+\s+\(\s+)(\d+)/${1}${serial}/ms;

    $self->_savefile( $alt_zone_file );
    $self->{__changed} = 0;
    return $self;
}

1;
