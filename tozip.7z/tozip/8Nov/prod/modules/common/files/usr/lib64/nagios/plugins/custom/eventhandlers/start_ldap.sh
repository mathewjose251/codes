#!/bin/bash
# 
# Program       : start_ldap.sh
# Author        : Tim Anderson 3/2009
# Description   : This script is called by the eh-start_ldap eventhandler
#

CMD="/sbin/service cdsserver restart"
TAIL="/usr/bin/tail"

if [ -e /usr/bin/sudo ]
then
	SUDO=/usr/bin/sudo
else
	SUDO=/usr/local/bin/sudo
fi


MSG=`$SUDO $CMD | $TAIL -1`

echo "$MSG"
exit 0
