#!/bin/bash

# $Id: check_sun_array.bash,v 1.1 2018/10/30 10:12:00 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/check_sun_array.bash,v $
#
# Program       : Sun Storage array plugin for Nagios
# Author        : Dave Patterson 6/2006
# License       : GPL
# Description   : This plugin checks:  disk state, controler-cache state, controler state, and battery state
#               : Added check for FRUs - TJA 13Feb13
#


. /usr/lib/nagios/plugins/utils.sh

PROGNAME=`/bin/basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1 $' | /bin/sed -e 's/[^0-9.]//g'`

CMD="/usr/bin/sudo /opt/SUNWsscs/sbin/sccli"
TMPERR1=0 
TMPERR2=0 
TMPERR3=0 
TMPERR4=0 
TMPERR5=0 

print_usage() {
        echo "Usage: $0"
        echo " $0 (-H ) HOSTNAME or IP"
        echo " $0 (-V | --version)"
        echo " $0 (-h | --help)"
}

print_help() {
    print_revision $PROGNAME $REVISION
    echo ""
    print_usage
    echo ""
    echo "This plugin checks the state of Sun 3000 series storage arrays."
    echo ""
    support
}

exitstatus=$STATE_UNKNOWN

    case "$1" in
        -H)
            if [ "$#" != 2 ] ; then
                print_usage
                exit 5
            fi
            HOST=$2
            ;;
        --help)
            print_help
            exit $STATE_OK
            ;;
        -h)
            print_help
            exit $STATE_OK
            ;;
        --version)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -V)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        *)
            echo "This script needs an argument"
            print_usage
            exit $STATE_UNKNOWN
            ;;
    esac
    shift

######   ++++ get data ++++ ########################################################
cache=`$CMD $HOST show cache|grep cur|awk '{print $2}' `  
control=`$CMD $HOST show redundancy-mode|grep  status |awk '{print $3}' ` 
batt=`$CMD $HOST show peripheral-device-status|grep Bat|awk '{print $2 $3 $4}' |egrep 'Warning|Not present|Bad|N/A|Expired'` 
disks=`$CMD $HOST show disks|egrep -i "FAIL|OFFLINE|INIT|REBUILD|BAD|ABSENT|MISS" `
frus=`$CMD $HOST show fru |egrep 'FRU Location:|FRU Status:'|awk '/FRU Status: [Absent|Bad|Fail|Fault]/  {print x};{x=$0}'` 
####################################################################################
TMPERR4=0 


#if [ $cache == write-back ]; then
#		CACHE_STATE=$STATE_OK
#	else 	
#		TMPERR1=1 
#		CACHE_STATE=$STATE_CRITICAL
#fi

if [ $control == Enabled ]; then
		CONTROLER_STATE=$STATE_OK
	else
		TMPERR2=1 
		CONTROLER_STATE=$STATE_CRITICAL
fi


if [ -z $batt ] ; then
	 	BATT_STATE=$STATE_OK
	else 
		TMPERR3=1 
	 	BATT_STATE=$STATE_CRITICAL
fi 


if [ -z $disks ]; then
		DISK_STATE=$STATE_OK
	else
		TMPERR4=1 
		DISK_STATE=$STATE_CRITICAL
fi 

if [ "$frus" == "" ]; then
		FRU_STATE=$STATE_OK
	else
		TMPERR5=1 
		FRU_STATE=$STATE_CRITICAL
fi 

# Tell Nagios whats up .....


if [ "$TMPERR1" -ne 1 -a "$TMPERR2" -ne 1 -a "$TMPERR3" -ne 1 -a "$TMPERR4" -ne 1 -a "$TMPERR5" -ne 1 ];  
	then
#		echo "ARRAY OK - disk: OK, cache-policy: OK, controler: OK, battery: OK"
		echo "ARRAY OK - disk: OK, controler: OK, battery: OK, fru: OK"

		exitstatus=$STATE_OK
	else
#		if [ $CACHE_STATE -eq $STATE_OK ] ; then
#			cache_stat="OK"
#		else
#			cache_stat="$cache"
#		fi
		if [ $CONTROLER_STATE -eq $STATE_OK ] ; then
			con_stat="OK"
		else
			con_stat="$control"
		fi
		if [ $BATT_STATE -eq $STATE_OK ] ; then
			batt_stat="OK"
		else
			batt_stat="$batt"
		fi
		if [ $DISK_STATE -eq $STATE_OK ] ; then
			disk_stat="OK"
		else
			disk_stat="$disks"
		fi
		if [ $FRU_STATE -eq $STATE_OK ] ; then
			fru_stat="OK"
		else
			fru_stat="$frus"
		fi

#		echo "ARRAY CRITICAL -  disk: $disk_stat, cache-policy: $cache_stat, controler: $con_stat, battery: $batt_stat "
		echo "ARRAY CRITICAL -  disk: $disk_stat, controler: $con_stat, battery: $batt_stat, fru: $fru_stat "
			exitstatus=$STATE_CRITICAL
fi

exit $exitstatus

