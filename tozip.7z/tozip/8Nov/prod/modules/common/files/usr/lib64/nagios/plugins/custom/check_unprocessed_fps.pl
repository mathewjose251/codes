#!/opt/blocperl/bin/perl
use strict;
use warnings;

BEGIN { require("/space/orabloc/server/conf/inc.pl") }

use File::Basename;
use BLOC::DB;
use BLOC::DB::Tools qw(:all);
use Getopt::Long;

my $db     = BLOC::DB->db();
my $config = BLOC::Config->new();
my %opts   = ();
my @msg    = ();

##
## These are const values for nagios status lines
use constant OK   => [ 0, "OK" ];
use constant WARN => [ 1, "WARNING" ];
use constant CRIT => [ 2, "CRITICAL" ];
use constant UNKN => [ 3, "UNKNOWN" ];

##
## The submission types we care about
my @submission_types = ( -2, -4 );
my %submission_types = (
    -2 => 'FPs',
    -4 => 'Consumer FPs'
);

##
## What's my name?
sub service_name {
    my $name = shift || $0;
    $name = File::Basename::basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

##
## Usage
sub usage {
    print "\nUsage:\n";
    print service_name() . " -c <critical number of unprocessed fps>\n";
    exit UNKN->[0];
}

sub main {
    GetOptions( \%opts, "c=i" );

    ##
    ## bail and pring usage if critical and warning thresholds were not there
    usage() if ( !$opts{c} );

    ##
    ## Pull unprocessed FP count from database
    my %counts = dbi_exec_for_hoh(
        $db, DBI_CACHE_STMT,
        q{
            SELECT probe_id, COUNT(*) AS count
            FROM messages
            WHERE probe_id   < 0
            AND verdict      = 0
            AND alert_status = 0
            GROUP BY probe_id
        }
    );

    ##
    ## The order of assignment is important...
    my $level = OK;
    my @msg;

    ##
    ## Loop through the submission types we care about and check counts
    foreach my $type (@submission_types) {
        my $count = $counts{$type}{'count'} || 0;
        $level = CRIT if ( $count >= $opts{c} );
        push( @msg, sprintf( "%s=%s", $submission_types{$type}, $count ) );
    }

    ##
    ## Print output and return appropriate exit code
    printf "%s: unprocessed FP counts (%s)\n", $level->[1], join( ",", @msg );

    return $level->[0];
}

exit( main() );
