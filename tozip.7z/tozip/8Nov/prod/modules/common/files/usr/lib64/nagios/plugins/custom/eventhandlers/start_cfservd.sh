#!/bin/bash
# 
# $Id: start_cfservd.sh,v 1.1 2018/10/30 10:12:04 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/eventhandlers/start_cfservd.sh,v $
#
# Program       : start-cfservd.sh
# Author        : Sean Heshmati 9/2005
# Description   : This script is called by the eh-start-cfservd eventhandler
#

CMD="/sbin/service cfservd restart"
TAIL="/usr/bin/tail"

if [ -e /usr/bin/sudo ]
then
	SUDO=/usr/bin/sudo
else
	SUDO=/usr/local/bin/sudo
fi


MSG=`$SUDO $CMD | $TAIL -1`

echo "$MSG"
exit 0
