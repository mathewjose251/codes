#!/bin/bash
#
# $Id: check_syncprov.sh,v 1.1 2018/10/30 10:12:00 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/check_syncprov.sh,v $
#
# Program	: LDAP Syncprov plugin for Nagios
# Author	: Geoffrey Gloistein 01/2007
# License	: GPL
# Description	: This plugin checks if the LDAP servers contain the same
# number of records in the database.
#

. /usr/lib/nagios/plugins/utils.sh

PROGNAME=`/bin/basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1 $' | /bin/sed -e 's/[^0-9.]//g'`

print_usage() {
        echo "Usage:"
        echo " $0 "
        echo " $0 (-V | --version)"
        echo " $0 (-d | --debug)"
        echo " $0 (-h | --help)"
}

print_help() {
    print_revision $PROGNAME $REVISION
    echo ""
    print_usage
    echo ""
    echo "This plugin checks if LDAP databases are equal."
    echo ""
    support
}

exitstatus=$STATE_UNKNOWN
debug=0

while test -n "$1"; do
    case "$1" in
        --help)
            print_help
            exit $STATE_OK
            ;;
        -h)
            print_help
            exit $STATE_OK
            ;;
        --version)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -V)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -d)
            debug=1
            ;;
        --debug)
            debug=1
            ;;
        *)
            echo "Unknown argument: $1"
            print_usage
            exit $STATE_UNKNOWN
            ;;
    esac
    shift
done

master_server="ldap01.sfo"
replica_servers="ldap02.sfo ldap01.sac ldap02.sac"

search="ldapsearch -x -wsecret -Duid=ldapproxy,ou=people,dc=brightmail,dc=com -h"
master_count=`$search $master_server | grep numEntries | cut -d' ' -f3`
if [ $debug -eq 1 ]
then
    echo "Master server $master_server count: $master_count"
fi

for replica in `echo $replica_servers`
do
    replica_count=`$search $replica | grep numEntries | cut -d' ' -f3`
    if [ $debug -eq 1 ]
    then
        echo "Replica $replica count: $replica_count"
    fi
    if [ $master_count -ne $replica_count ]
    then
	not_synced="$not_synced $replica"
    fi
done

# Finally Inform Nagios of what we found...
if [ "$not_synced" ]
then
	echo "CRITICAL - servers(s):$not_synced not synced to $master_server!"
	exitstatus=$STATE_CRITICAL
else
	echo "OK - all servers are synced to $master_server"
	exitstatus=$STATE_OK
fi

exit $exitstatus
