#!/bin/bash
#
# $Id: check_junkyard.sh,v 1.1 2018/10/30 10:12:00 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/check_junkyard.sh,v $
#
# Program	: Junkyard plugin for Nagios
# Author	: Sean Heshmati 5/2005
# License	: GPL
# Description	: This plugin checks if junkyard is running.
#

. /usr/lib/nagios/plugins/utils.sh

PROGNAME=`/bin/basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1 $' | /bin/sed -e 's/[^0-9.]//g'`

print_usage() {
        echo "Usage:"
        echo " $0 "
        echo " $0 (-v | --version)"
        echo " $0 (-h | --help)"
}

print_help() {
    print_revision $PROGNAME $REVISION
    echo ""
    print_usage
    echo ""
    echo "This plugin checks if junkyard is running."
    echo ""
    support
}

exitstatus=$STATE_UNKNOWN

while test -n "$1"; do
    case "$1" in
        --help)
            print_help
            exit $STATE_OK
            ;;
        -h)
            print_help
            exit $STATE_OK
            ;;
        --version)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -V)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        *)
            echo "Unknown argument: $1"
            print_usage
            exit $STATE_UNKNOWN
            ;;
    esac
    shift
done

junk_procs="junk_collector.pl junk_alert_daemon.pl"

for proc in `echo $junk_procs`
do
    if [[ ! `ps ho pid -C $proc` ]]
    then
	not_running="$not_running $proc"
    fi
done

# Finally Inform Nagios of what we found...
if [ "$not_running" ]
then
	echo "CRITICAL -$not_running not running!"
	exitstatus=$STATE_CRITICAL
else
	echo "OK - Junkyard processes are running"
	exitstatus=$STATE_OK
fi

exit $exitstatus
