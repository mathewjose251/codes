#!/usr/bin/perl
#
# Program       : Network Interface link speed and duplex check
# Author        : Brendan Harris 5/2005
# Description   : This plugin checks if the link speed and duplex of network
#					interfaces.
#
use strict;
use Getopt::Long;

use lib "/usr/lib/nagios/plugins";
use vars qw($PROGNAME $REVISION);
use utils qw (%ERRORS &print_revision &support);

my ($opt_s, $opt_d, $opt_V, $opt_h, $opt_i);
my ($exitstatus,$message,$mdstatFile);
my (@mdstat,@device,@finalresult);
my (%option,%md);
use vars qw($DEBUG);
my $textsep	= ',';
my $loop	= 0;

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
$REVISION=$1;
$PROGNAME="check_av_status";
$exitstatus=$ERRORS{'UNKNOWN'};

Getopt::Long::Configure('bundling');
%option	= GetOptions(
    "V"   => \$opt_V, "version" => \$opt_V,
    "h"   => \$opt_h, "help"    => \$opt_h,
	"D"		=> sub { $DEBUG='[DEBUG]' },
	"debug"	=> sub { $DEBUG='[DEBUG]' });

# The abs path to the mdstat file
$mdstatFile		= '/proc/mdstat';

##################################################################
## Action

# If the /proc/mdstat does not exist then exit quietly
if (! -e "$mdstatFile")
{
	print "OK - No mirrors on this host.\n";
	exit $ERRORS{'OK'};
}

# Get the mdstat data
open MDSTAT, "$mdstatFile";
@mdstat		= <MDSTAT>;
close MDSTAT;

# Check for mirrors and report back
$exitstatus	= $ERRORS{'OK'};
foreach (@mdstat)
{
	next if !/^md/;
	next if !/raid1/;
	chomp;
	@device		= split(/\s/, $_);
	$md{$device[0]}		= "$device[2]";
	$exitstatus			= $ERRORS{'CRITICAL'}	if ($md{$device[0]} !~ /active/);
}

# Build the exit string
foreach (keys (%md) )
{
	chomp;
	push (@finalresult,"$_ = $md{$_}$textsep");
}
foreach (keys (%ERRORS) )
{
	chomp;
	unshift (@finalresult,"$_ -")	if ($ERRORS{$_} == $exitstatus);
}
$message		= join(' ', @finalresult);
chop ($message);
$message		.= '.';

print "$message\n";
exit $exitstatus;

##################################################################

sub print_usage
{
    print "Usage:\n";
    print "  $PROGNAME \n";
    print "  $PROGNAME [-h | --help]\n";
    print "  $PROGNAME [-V | --version]\n";
}

sub print_help
{
    print_revision($PROGNAME, $REVISION);
    print_usage();
    print "\n";
    print "  <>  \n";
    print "\n";
    support();
}
