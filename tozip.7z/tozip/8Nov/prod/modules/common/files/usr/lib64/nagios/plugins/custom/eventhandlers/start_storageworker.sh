#!/bin/bash
# start_storageworker.sh - By: Beam Davis (Beam_Davis@symantec.com)  (08/18/11)
# This script is called by the eh-start_storageworker eventhandler.
#
# Usage: start_storageworker.sh
#
# Constants.
#
CMD="/sbin/service storageworker restart"
TAIL="/usr/bin/tail"
#
# Main routine.
#
if [ -e "/usr/bin/sudo" ]
then
	SUDO="/usr/bin/sudo"
else
	SUDO="/usr/local/bin/sudo"
fi
MSG=`$SUDO $CMD | $TAIL -1`
echo "$MSG"


# # #  End of start_storageworker.sh  # # #

