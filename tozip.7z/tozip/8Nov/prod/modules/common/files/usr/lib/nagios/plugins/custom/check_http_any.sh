#!/bin/bash

args="$*"
/usr/lib/nagios/plugins/check_http -I localhost $args -p 80 2>/dev/null 1>&2 && echo "HTTP ok: HTTP/1.1 302 Found"  ||  /usr/lib/nagios/plugins/check_http -I localhost $args -p 81 
