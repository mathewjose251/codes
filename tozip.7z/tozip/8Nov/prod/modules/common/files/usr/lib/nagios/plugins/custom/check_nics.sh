#!/bin/bash

# check_nics.sh -       plugin for nagios to check that the physical
#                       network link is up with the proper speed and duplex setting
# 
# Author : Sunny Jaisinghani
#

# Includes
. /usr/lib/nagios/plugins/utils.sh

#
## Set the desired values of interface speed and duplex setting
#
SPEED=1000
AUTO_NEG=on
DUPLEX=Full

#
## Check OS
#
OS=`/bin/uname -a | awk '{print $1}'`

##
## NIC exclude config file
##
EXCLUDE_CFG="/usr/lib/nagios/plugins/custom/check_nics.conf"

function check_exclude {

    if [ -z "$1" ]
    then
        return 1
    fi

    if [ -r $EXCLUDE_CFG ]
    then
        if [ `grep ^$HOSTNAME:$1$ $EXCLUDE_CFG` ]
        then
            EXCLUDED=(${EXCLUDED[@]} "$1")
            continue
        fi
    fi
}

function print_msg {

    if [ ${#EXCLUDED[@]} -gt 0 ]
    then
        MSG="$1 (Excluding ${EXCLUDED[@]})"
    else
    MSG=$1
    fi

    echo "$MSG"
}

case $OS in

"Linux" )

for i in `/sbin/ifconfig | grep -i hwadd | awk '{print $1}' | grep -v bond`
do

    ##
    ## Should this NIC be excluded?
    ##
    check_exclude $i

    GOT_LINK=`sudo /sbin/ethtool $i | grep "Link detected" | cut -d ':' -f 2 | xargs`
    REAL_SPEED=`sudo /sbin/ethtool $i | grep "Speed" | cut -d ':' -f 2 | cut -d "M" -f 1 | xargs`
    REAL_DUPLEX=`sudo /sbin/ethtool $i | grep -i duplex | cut -d ":" -f 2 | xargs`
#   REAL_AUTO_NEG=`sudo /sbin/ethtool eth0 | grep  Auto-neg | cut -d ":" -f 2 | xargs`


    if [ ${GOT_LINK} != "yes" ]; then
        echo "CRITICAL: No link detected in interface $i"
        exit $STATE_CRITICAL
    fi

    if [ $REAL_SPEED = $SPEED ] && [ $REAL_DUPLEX = $DUPLEX ] ; then
            res=0
    else
            res=1
        echo "CRITICAL : Interface $i is $REAL_SPEED Mb/s $REAL_DUPLEX duplex. Should be $SPEED Mb/s $DUPLEX duplex"
        exit $STATE_CRITICAL
    fi

done

if [ $res -eq 0 ]; then
    print_msg "OK : All Interfaces are $SPEED Mb/s $DUPLEX duplex."
    exit $STATE_OK
fi

;;

"SunOS" )

## Get the list of valid NICS
LISTOFNICS=`ifconfig -a | awk -F: '/^[^l\t][^o]/ {print $1}' | sort -u`

for NIC in $LISTOFNICS
do
    ##
    ## Should this NIC be excluded?
    ##
    check_exclude $NIC

    case $NIC in
    e1000g* )
              ## Just in case we have this NIC in future
        INTERFACE=e1000g
        INT_INST=`echo ${NIC#??????}`
    ;;
        * )
        INTERFACE=`echo $NIC | tr -d '[0-9]'`
        INT_INST=`echo  $NIC | tr -d '[a-z]'`
    ;;
    esac

    case $NIC in
        clprivnet*|dman*|sppp*|be*|lpfc*|jnet*|aggr* )
        ## Ignore all these guys instead of trying to grep -v them all out
        continue
        ;;
    nxge* )
        if [ `kstat -p $INTERFACE:$INT_INST:mac:link_up | awk '{print $2}'` -eq 0 ]; then
            echo "CRITICAL : Interface $NIC is Down"
                        exit $STATE_CRITICAL
        elif [ `kstat -p $INTERFACE:$INT_INST:mac:link_duplex | awk '{print $2}'` -ne 2 ]; then
            echo "CRITICAL : Interface $NIC is half duplex. It should be Full duplex"
                        exit $STATE_CRITICAL
        elif [ `kstat -p "$INTERFACE:$INT_INST:Port Stats:link_speed" | awk '{print $3}'` -eq 1000 ]; then
            continue
        fi
    ;;
    bge* )
        if [ `kstat -p $INTERFACE:$INT_INST:mac:link_up | awk '{print $2}'` -eq 0 ]; then
            echo "CRITICAL : Interface $NIC is Down"
            exit $STATE_CRITICAL        
        elif [ `kstat -p $INTERFACE:$INT_INST:mac:link_duplex | awk '{print $2}'` -ne 2 ]; then
            echo "CRITICAL : Interface $NIC is half duplex. It should be Full duplex"
            exit $STATE_CRITICAL
        elif [ `kstat -p "$INTERFACE:$INT_INST:parameters:link_speed" | awk '{print $2}'` -eq 1000 ]; then
            continue
        fi
    ;;
    ce* )
        if [ `kstat -p $INTERFACE:$INT_INST:$NIC:link_up | awk '{print $2}'` -eq 0 ]; then
                        echo "CRITICAL : Interface $NIC is Down"
                        exit $STATE_CRITICAL
                elif [ `kstat -p $INTERFACE:$INT_INST:$NIC:link_duplex | awk '{print $2}'` -ne 2 ]; then
                        echo "CRITICAL : Interface $NIC is half duplex. It should be Full duplex"
                        exit $STATE_CRITICAL
                elif [ `kstat -p "$INTERFACE:$INT_INST:$NIC:link_speed" | awk '{print $2}'` -eq 1000 ]; then
                        continue
                fi  
    ;;
    eri* )
        ## eri interfaces do not support 1000Mbps speed. Also none of the commands supported by solaris 8 give the exact spped of the n/w interface.
        ## Hence, i am only checking for the link status and link duplex mode here.

        if [ `kstat -p $INTERFACE:$INT_INST:$NIC:link_up | awk '{print $2}'` -eq 0 ]; then
            echo "CRITICAL : Interface $NIC is Down"
                        exit $STATE_CRITICAL
        elif [ `kstat -p $INTERFACE:$INT_INST:$NIC:link_duplex | awk '{print $2}'` -eq 0 ]; then
            echo "CRITICAL : Interface $NIC is half duplex. It should be Full duplex"
                        exit $STATE_CRITICAL
        else
            echo "OK : ALL eri interfaces are 100Mbps Full duplex"
            exit $STATE_OK
        fi
    ;;
    esac
done

print_msg "OK : All Interfaces are 1000Mbps Full duplex."
exit $STATE_OK

;;
esac
