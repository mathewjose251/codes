#!/usr/bin/perl -w
# $Id: check_rrd_pct_change.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/check_rrd_pct_change.pl,v $
#
# Program       : Check RRD percent change
# Author        : Sean Heshmati 2/2009
# Description   : This plugin queries a RRD database and calculates
#                 percentage of change for the specified interval.
#
use strict;
use RRDs;
use Data::Dumper;
use Getopt::Long;

use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS &print_revision &support);

my ( $opt_v, $opt_h, $opt_i, $opt_d, $opt_c, $opt_r, $opt_s, $opt_n );
my ( %opt_l, $opt_f, $opt_u, $opt_e, $opt_x, %data, @mesg, $output );

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
my $REVISION   = $1;
my $PROGNAME   = "check_rrd_pct_change";
my $exitstatus = $ERRORS{'UNKNOWN'};

GetOptions(
    "v"       => \$opt_v,
    "version" => \$opt_v,
    "h"       => \$opt_h,
    "help"    => \$opt_h,
    "i=i"     => \$opt_i,
    "d=i"     => \$opt_d,
    "c=i"     => \$opt_c,
    "l=s%"    => \%opt_l,
    "r=s"     => \$opt_r,
    "s=i"     => \$opt_s,
    "f=s"     => \$opt_f,
    "u=i"     => \$opt_u,
    "e=s"     => \$opt_e,
    "x=i"     => \$opt_x,
    "n=s"     => \$opt_n,
);

# set defaults
$opt_s ||= 1;
$opt_u ||= 1800;
$opt_f ||= 'LAST';
$opt_n ||= 'bytes';

# process options
if ($opt_v) {
    print_revision( $PROGNAME, $REVISION );
    exit $ERRORS{'OK'};
}
elsif ($opt_h) {
    print_help();
    exit $ERRORS{'OK'};
}
elsif (( $opt_r && defined($opt_i) && !defined($opt_d) && !defined($opt_c) )
    or ( $opt_r && defined($opt_d) && !defined($opt_i) && !defined($opt_c) )
    or ( $opt_r && defined($opt_c) && !defined($opt_i) && !defined($opt_d) )
    or ( $opt_r && defined($opt_x) ) )
{
    check_rrd();
}
else {
    print_help();
    exit $ERRORS{'UNKNOWN'};
}

# make sure RRD file exists
unless ( -f $opt_r ) {
    print "CRITICAL - Failed to open $opt_r: $!\n";
    exit $ERRORS{'CRITICAL'};
}

# compose check output
if (@mesg) {
    for my $status ( keys %ERRORS ) {
        $output = "$status - " if $ERRORS{$status} == $exitstatus;
        last if $output;
    }
    $output .= join( ", ", @mesg );
}
else {
    $output     = "CRITICAL - RRD did not return any data sources!";
    $exitstatus = $ERRORS{'CRITICAL'};
}

# print final message and exit with proper status
print "$output\n";
exit $exitstatus;

sub check_rrd {

    # get last update time
    my $last = RRDs::last($opt_r);

    # RRD hasn't been updated for a while so return critical
    if ( time - $last > $opt_u ) {
        push( @mesg,
            "$opt_r hasn't been updated in the last $opt_u seconds!" );
        $exitstatus = $ERRORS{'CRITICAL'};
        return;
    }

    # calculate interval
    my $interval = RRDs::info($opt_r)->{step} * $opt_s;

    # get rrd data
    my ( $rstart, $step, $names, $array ) =
      RRDs::fetch( $opt_r, $opt_f, "-s", $last - ($interval * 2), "-e", $last );

    # bail if we could not fetch the data
    if ( my $rrd_error = RRDs::error ) {
        push( @mesg, "RRD fetch failed: $rrd_error" );
        $exitstatus = $ERRORS{'CRITICAL'};
        return;
    }

    my $start = $rstart;

    # loop through each line of data return and stuff the data into a hash.
    # hash => rrd_time_interval => cf_name => rrd_value
    foreach my $line (@$array) {
        for ( my $i = 0 ; $i < @$names ; $i++ ) {
            next unless @$line[$i];
            $data{$start}{ @$names[$i] } = sprintf( "%d", @$line[$i] );
        }
        $start += $step;
    }

    # loop throught DSs and calculate change percentage
    foreach my $name (@$names) {

        # skip DS if it matches exclude regex
        next if ( $opt_e and $name =~ /$opt_e/ );

        my $start_value = $data{$rstart}->{$name};
        my $last_value  = $data{ $rstart + $interval }->{$name};

        if ( !$start_value ) {
            push( @mesg,
                    get_label($name)
                  . " did not return a start value for "
                  . scalar localtime($rstart) );
            $exitstatus = $ERRORS{'CRITICAL'};
            next;
        }
        elsif ( !$last_value ) {
            push( @mesg,
                    get_label($name)
                  . " did not return a value for "
                  . scalar localtime( $rstart + $interval ) );
            $exitstatus = $ERRORS{'CRITICAL'};
            next;
        }

        my $diff_value = $last_value - $start_value;
        my $change = sprintf( "%.2f", $diff_value / $start_value * 100 );

        # handle increase
        if ( defined($opt_i) && $change >= $opt_i ) {
            push( @mesg, get_label($name) . " increased by $change%" );
            $exitstatus = $ERRORS{'CRITICAL'};
        }

        # handle decrease
        elsif ( defined($opt_d) && ( abs($change) >= abs($opt_d) ) ) {
            push( @mesg, get_label($name) . " decreased by $change%" );
            $exitstatus = $ERRORS{'CRITICAL'};
        }

        # handle increase and decrease
        elsif ( defined($opt_c) && ( abs($change) >= abs($opt_c) ) ) {
            push( @mesg, get_label($name) . " changed by $change%" );
            $exitstatus = $ERRORS{'CRITICAL'};
        }

        # All is good
        else {
            push( @mesg, get_label($name) . " ($change%) within threshold" );
            $exitstatus = $ERRORS{'OK'}
              if $exitstatus != $ERRORS{'CRITICAL'};
        }

        # handle size
        if ( defined($opt_x) && $last_value >= $opt_x ) {
            push( @mesg,
                get_label($name) . " ($last_value ${opt_n}) is too big " );
            $exitstatus = $ERRORS{'CRITICAL'};
        }

        # it's all good
        else {
            push( @mesg,
                get_label($name) . " ($last_value ${opt_n}) within threshold" );
            $exitstatus = $ERRORS{'OK'}
              if $exitstatus != $ERRORS{'CRITICAL'};
        }

    }
}

sub get_label {
    my $name = shift;

    # if label was provided for this DS return it, otherwise return the DS
    return $name unless $opt_l{$name};
}

sub print_help {
    print_revision( $PROGNAME, $REVISION );
    print "\nUsage:\n";
    print " $PROGNAME -r <rrd> -i <increase> | -d <decrease> "
      . "| -c <change> | -x <size>\n";
    print "\t\t\t[-l <DS=label>] [-s <steps>] [-f <CF>]\n";
    print "\t\t\t[-u <seconds>] [-e ds_exclude_regex]\n";
    print " $PROGNAME [-h | --help]\n";
    print " $PROGNAME [-v | --version]\n";
    print "\nOptions:\n";
    print "  -r rrd_file\n";
    print "     Full path to RRD file\n";
    print "  -i increase (INTEGER)\n";
    print "     Percent increase to result in critical status.\n";
    print "  -d decrease (INTEGER)\n";
    print "     Percent decrease to result in critical status.\n";
    print "  -c change (INTEGER)\n";
    print "     Percent increase or decrease to result in critical status.\n";
    print "  -l label (DS=STRING)\n";
    print "     Specify optional label(s) for DS name.\n";
    print "     (example -l load_1min=one_minute_load)\n";
    print "  -s steps_back (INTEGER)\n";
    print "     Number of steps back from most recent data point to\n";
    print "     use for calculations. For example, if RRD has a base\n";
    print "     interval of 300 seconds and steps_back is set to 2, the\n";
    print "     last 600 seconds of data will be used to perform the\n";
    print "     calculation (default: 1)\n";
    print "  -f CF (STRING)\n";
    print "     Consolidation function to fetch. (default: LAST)\n";
    print "  -u seconds_since_last_update (INTEGER)\n";
    print "     Result in critical status if RRD has not been updated for\n";
    print "     specified period of time (default: 1800)\n";
    print "  -e ds_exclude_regex\n";
    print "     Any data source matching this regex will be excluded\n";
    print "  -x size (INTEGER)\n";
    print "     Size to result in a critical status. Can be used with options -i, -d or -c.\n";
    print "  -n label (STRING)\n";
    print "     Set a unit label which is printed in the output (default: bytes).\n";
    print "\n";
}
