#!/bin/sh

#
# file time check for domain_feeds application
#
#  Files are put in a variety of places and the directory name changes by day as it is named by the date,
#  so lets find current files, index them, and interrogate them
# 
# this is adapted to run on an active/passive pair of nodes w/o knowing in advance which is active.
# it will exit with OK if there is no active file system mount.  
# the alternative would be to use check_by_ssh as ssh is enabled on the VIP, but I don't see that
# we have default access for that check from the mon server, so will settle for this working now.
  
export INDEXARR WARN CRITICAL 

# removing biz files as they need a separate monitor due to only getting a new feed once per day
# ipglue-biz
# diff-biz
# ns-biz
# biz
INDEXARR="ipglue-info
ipglue-net
ipglue-com
ipglue-info
diff-net
diff-com
diff-info
ns-net
ns-com
ns-info
info
net
com
"


d=/var/opt/domain_feeds/spool/hashes

exit_err() {
   echo $1
   exit 2
}
 
[ $# -ge 2 ] || exit_err "Usage: $0 <warn-seconds> <critical-seconds> [-v]"

cd $d || exit 2 # we have larger issues 

WARN=$1
CRITICAL=$2

run_check() {
  find . -type f -mtime -8 | perl -ne '{
  next unless m%([^/]+cdb)$%; 
  $m=$1;$name=$m;
  $m=~s/-[^-]+$/\./; 
  $m=~/^(.+?)\./;
  $m=$1;$t=$_;
  chop $t;
  @a=stat($t); 
  $ft=(stat($t))[9]; 
  $age = time - $ft; 
  if (!$agearr{$m}) { 
    $agearr{$m}=$age; 
    $name{$m} = $name;
  } 
  if( $age < $agearr{$m}) { 
    $agearr{$m} =$age; 
    $name{$m}=$name };
}
END { 
  foreach $k ( split(/\n/,$ENV{INDEXARR}) ) { 
    if( !$agearr{$k} ) { printf("CRITICAL: Current $k files not found!\n"); exit 2;}
    if ( $agearr{$k} > $ENV{CRITICAL}) { 
      printf("CRITICAL: %-30s%10d seconds old\n",$name{$k},$agearr{$k});
      exit 2;
    } 
    elsif ( $agearr{$k} > $ENV{WARN}) { 
      printf("WARN: %-30s%10d seconds old\n",$name{$k},$agearr{$k}); 
      exit 1;
    }
  }
print "OK: all files OK\n";
}'  
exit $?
}

run_info() {
  find . -type f -mtime -8 | perl -ne '{
  next unless m%([^/]+cdb)$%; 
  $m=$1;$name=$m;
  $m=~s/-[^-]+$/\./; 
  $m=~/^(.+?)\./;
  $m=$1;$t=$_;
  chop $t;
  @a=stat($t); 
  $ft=(stat($t))[9]; 
  $age = time - $ft; 
  if (!$agearr{$m}) { 
    $agearr{$m}=$age; 
    $name{$m} = $name;
  } 
  if( $age < $agearr{$m}) { 
    $agearr{$m} =$age; 
    $name{$m}=$name };
}
END { 
  foreach $k ( split(/\n/,$ENV{INDEXARR}) ) { 
    if( !$agearr{$k} ) { printf("CRITICAL: Current $k files not found!\n"); }
    if ( $agearr{$k} > $ENV{CRITICAL}) { 
      printf("CRITICAL: %-30s%10d seconds old\n",$name{$k},$agearr{$k});
    } 
    elsif ( $agearr{$k} > $ENV{WARN}) { 
      printf("WARN: %-30s%10d seconds old\n",$name{$k},$agearr{$k}); 
    }
  }
print "OK: all files OK\n";
}'  
exit $?
}

if [ $# -eq 3 ];then 
  run_info
else
  run_check
fi
