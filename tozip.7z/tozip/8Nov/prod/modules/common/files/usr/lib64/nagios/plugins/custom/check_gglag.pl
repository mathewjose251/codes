#!/usr/bin/perl

use strict;
use warnings;

BEGIN { $ENV{"LD_LIBRARY_PATH"} = '/apps/oh/db11202/lib' }

use File::Basename qw(basename);
use File::Spec::Functions;
use List::Util qw(sum);
use File::Path qw(mkpath);
use POSIX      qw(strftime);
use Getopt::Long;
use Time::Local;
use Pod::Usage;
use IO::Handle;
use IO::File;

=pod

=head1 NAME

gglag.pl - GoldenGate EXTRACT and REPLICAT group status checks

=head1 SYNOPSIS

gglag.pl [--help] [--simulate=output-file] [--ignore='bucket, ...'] [-A|--autoackwindow=HH1:MM1-HH2:MM2] [--warn='W'] [--crit='C']

=head1 DESCRIPTION

This script examines all of the extract and replicat groups in the current
GoldenGate configuration.  It checks to ensure that all groups are functioning
properly by examining their state and checkpoint lag.

=head1 OPTIONS

If B<--ignore> is specified on the command line then a comma-separated list of
extract or replicat identifier names are expected.  This script will skip any
groups named in this list.

The B<--autoackwindow> command line switch forces a nagios OK response if the 
current local time falls within the hour and minute range specified by the
specification given with the parameter.  If the B<HH2:MM2> time is a value that is
earlier than B<HH1:MM1> then a day overlap is assumed (e.g., C<23:30-01:30>).
Note that a 24-hour time format must be used and that seconds are not given and
are assumed to be "00".

if B<--simulate> is given, instead of reading the live output from Golden Gate's CLI
utility the specified file is read and used as the actual data for the check.  This 
is useful for checking the output of a prior GoldenGate CLI session for debugging
purposes.

If B<--warn> is given, the value associated with this option represents an
integer value designating a number of seconds.  If an extract or replicat group
is in an C<ABEND> state and its lag time is greater than or equal to this value,
and is not greater or equal to the time specified with B<--crit> parameter then
a B<WARNING> nagios alert will be triggered.  If this argument is not given the
warning lag time will default to C<60> seconds.

If B<--crit> is given it is compared against the lag period (in seconds) for
any extract or replicat in an C<ABEND> state.  If the lag period is greater
than or equal to this value then a B<CRITICAL> nagios alert is thrown.  If this
argument is not specified on the command line the critical lag time will
default to C<120> seconds.

=cut

##
## These are const values for nagios status lines
use constant OK             => [ 0, "OK" ];
use constant WARN           => [ 1, "WARNING" ];
use constant CRIT           => [ 2, "CRITICAL" ];
use constant UNKN           => [ 3, "UNKNOWN" ];

use constant DEFAULT_WARN   => 60;
use constant DEFAULT_CRIT   => 120;

use constant DEBUGGING      => 1;
use constant DEBUG_OUT_BASE => '/var/tmp/check_gglag';

use constant DEF_EXITVAL    => OK;
use constant DEF_EXITMSG    => "All EXTRACT and REPLICAT groups are functioning.";

##
## GoldenGate specific stuff
use constant BASEDIR        => '/apps/ggate/product/';

my ( $GG_SCI, $GG_BASEDIR, $opt_ignore, $opt_sim, $ack_win, @buckets_to_ignore, $warn, $crit );

sub time_to_seconds {
    my ($timestr) = @_;
    return 0 unless $timestr;

    ##
    ## The $timestr should be in the format HH:MM:SS, just deal with it in case
    ## it's just MM:SS or just SS.
    ##
    my @time_elements = split( ':', $timestr );
    return $timestr unless scalar(@time_elements) >= 2;
    my $seconds = pop(@time_elements);
    $seconds += pop(@time_elements) * 60;
    $seconds += pop(@time_elements) * 3600 if (@time_elements);

    return $seconds;
}

sub version_to_decimal {
    my ($dotstr) = @_;
    return 0 unless $dotstr;
    my @f   = grep defined, split( /\D/, basename $dotstr );
    my $exp = 0;
    my $sum = sum(
        map {
            my $grp = $_ * ( 10**$exp );
            $exp += 3;
            $grp
        } reverse @f
    );
    return $sum;
}

sub find_gg_prod_dir {
    my ($basedir) = @_;
    return unless $basedir && -d $basedir;
    my ($dir) = sort { version_to_decimal($b) <=> version_to_decimal($a) }
      grep -d && -x catdir( $_, "ggsci" ) && m{ / [\d.]+ $}x,
      glob catfile( $basedir, '*' );
    return $dir;
}

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub evaluate_request {
    my ($buckets)  = @_;
    my @exitents   = ();
    my $exitval    = DEF_EXITVAL;
    my $ok_exitmsg = DEF_EXITMSG;

    for my $bucket ( sort keys %{$buckets} ) {
        next if ( grep { $_ ne 'MANAGER' && $bucket eq $_ } @buckets_to_ignore );

        my ( $lagsec, $type, $state ) =
          @{ $buckets->{$bucket} }{qw( lagsec type state )};

        ##
        ## If the MANAGER process stops you're not going to have a good time.
        if ( $bucket eq 'MANAGER' && $state ne 'RUNNING' ) {
            $exitval = CRIT;
            my $currmsg = sprintf( "MANAGER group in state %s; ", $state );
            push @exitents, [ CRIT->[0], 999, $currmsg ];
        }
        ##
        ## Any other group type check to see if it's abended
        elsif ( $state eq 'ABEND' ) {
            $exitval = CRIT;
            my $currmsg = sprintf( "%s is in an ABEND state; ", $bucket );
            push @exitents, [ CRIT->[0], $lagsec, $currmsg ];
	}
	##
	## Check all other buckets' lag times
        else {
            if ( $lagsec !~ /\D/ && $lagsec >= $crit ) {
                $exitval = CRIT;
                my $currmsg = sprintf( "%s critical lag %s second%s; ",
                    $bucket, $lagsec, ( $lagsec == 1 ) ? "" : "s" );
                push @exitents, [ CRIT->[0], $lagsec, $currmsg ];
            }
            elsif ( $lagsec !~ /\D/ && $lagsec >= $warn ) {
                $exitval = WARN if ( $exitval->[0] <= WARN->[0] );
                my $currmsg = sprintf( "%s warning lag %s second%s; ",
                    $bucket, $lagsec, ( $lagsec == 1 ) ? "" : "s" );
                push @exitents, [ WARN->[0], $lagsec, $currmsg ];
            }
        }
    }

    return ( OK->[0], as_nagios_str( OK->[1], $ok_exitmsg ) )
      if ( $exitval->[0] == OK->[0] );

    ##
    ## Prioritize the message: State alerts first, critical lag sorted
    ## by lag time next, and lastly warning lag sorted by lag time.
    ##
    my $exitmsg = join(
        '' => map { $_->[2] }
            sort { $b->[0] <=> $a->[0] || $b->[1] <=> $a->[1] } @exitents
    );
    $exitmsg =~ s/;\s+$/./;

    return ( $exitval->[0], as_nagios_str( $exitval->[1], $exitmsg ) );
}

sub __init {
    if ($opt_sim && ! -f $opt_sim) {
	nagios_die("The simulation file '$opt_sim' could not be found.");
    }

    $GG_BASEDIR = find_gg_prod_dir(BASEDIR);
    nagios_die("Could not determine ggate product directory.")
      unless $GG_BASEDIR;

    $GG_SCI = catfile( $GG_BASEDIR, "ggsci" );
    nagios_die("Could not not locate the ggsci command.\n") unless -x $GG_SCI;

    if ($opt_ignore) {
        @buckets_to_ignore =
          map { uc } grep { $_ } split( /\s*,\s*/, $opt_ignore );
    }

    ##
    ## The warning and critical settings take default values if not given on
    ## the command line.
    $warn ||= DEFAULT_WARN;
    $crit ||= DEFAULT_CRIT;

    nagios_die(
        "Warning threshold [$warn] greater or equal to critical [$crit]")
      if ( $warn >= $crit );

    return;
}

sub write_debugging_output {
    my ($output) = @_;

    ##
    ## Don't debug log any simulation data...
    ##
    return if $opt_sim;

    my $now     = time();
    my @now     = localtime($now);
    my $outdir  = catdir( DEBUG_OUT_BASE, strftime( '%Y/%m/%d', @now ) );
    my $outfile = catfile( $outdir, strftime( 'check_gglag-%H.out', @now ) );

    mkpath [ $outdir ], 0, 0755;
    return unless ( $outdir && -d $outdir );

    my $fh = IO::File->new(">> $outfile") or return;
    $fh->print("Runtime date: ", scalar(localtime $now), "\n");
    $fh->print(@$output);
    $fh->print("\n", "=" x 78, "\n");
    $fh->close();
    return;
}

sub perform_service_check {
    my @output = ();

    if ($opt_sim) {
	local(*ARGV);
	@ARGV = ( $opt_sim );
	@output = <>;
    }
    else {
	open my $fh, sprintf( "echo info all | %s |", $GG_SCI );

	@output = <$fh>;
	close $fh;
    }

    write_debugging_output(\@output) if DEBUGGING;
    chomp(@output);

    my $seen_header = 0;
    my %extreps     = ();

    for my $line (@output) {
        $seen_header = 1 if $line =~ /^Program\s+Status\s+Group/;
        next unless $seen_header;

        if ( $line =~ /^MANAGER/) {
            my @data = split( ' ', $line );
            @{ $extreps{$data[0]} }{qw( type state lag time lagsec )} =
                ( @data[0,1], "00:00:00", "00:00:00", "0" );
        }
        elsif ( $line =~ /^(?:EXTRACT|REPLICAT)/ ) {
            my @data = split( ' ', $line );
            my $key = uc( splice @data, 2, 1 );
            @{ $extreps{$key} }{qw( type state lag time )} = @data;
            $extreps{$key}->{lagsec} =
              time_to_seconds( $extreps{$key}->{lag} );
        }
    }

    return \%extreps;
}

sub nagios_bail {
    my ( $exitval, $exitstr ) = @_;
    print STDOUT $exitstr, "\n";
    STDOUT->flush();
    exit($exitval);
}

sub nagios_die {
    my ($msg) = @_;
    1 while chomp($msg);
    nagios_bail( UNKN->[0], as_nagios_str( UNKN->[1], $msg, ) );
    ## NORETURN ##
}

MAIN: {
    my ( $exitval, $exitstr, $help );

    $|++;

    Getopt::Long::Configure( "bundling", "no_ignore_case" );

    GetOptions(
        "help|h"            => \$help,
        "warn|w=i"          => \$warn,
        "crit|c=i"          => \$crit,
        "ignore=s"          => \$opt_ignore,
	"simulate|s=s"	    => \$opt_sim,
        "A|autoackwindow=s" => \$ack_win,
    ) or ++$help;

    pod2usage( { -exitval => -1, -verbose => 1 } )
      if ($help);

    ##
    ## If an autoack window of time is given, then check that and respond accordingly
    if ( $ack_win && $ack_win =~ /(\d+):(\d+)-(\d+):(\d+)/ ) {
        if (localtime_inrange( $ack_win )) {
            $exitval = DEF_EXITVAL->[0];
            $exitstr = as_nagios_str( DEF_EXITVAL->[1], DEF_EXITMSG );
            nagios_bail( $exitval, $exitstr );
        }
    }

    ##
    ## Initialize basic variables
    __init();

    ##
    ## Check all of the EXTRACT and REPLICAT buckets
    my $buckets = perform_service_check();

    ##
    ## Evaluate the response from the service check here
    ##
    ( $exitval, $exitstr ) = evaluate_request($buckets);

    nagios_bail( $exitval, $exitstr );
}

sub localtime_inrange {
    my ($range_spec) = @_;
    my ($begin_time, $end_time, $start_hour, $start_min, $end_hour, $end_min);
    return unless ( defined $range_spec && $range_spec =~ /(\d+):(\d+)-(\d+):(\d+)/ );
    ( $start_hour, $start_min, $end_hour, $end_min ) = ( $1, $2, $3, $4 );

    my $now = time();
    my $day_adj    = ( $end_hour < $start_hour
        || ( $end_hour == $start_hour && $end_min < $start_min ) );
    $begin_time = timelocal(0, $start_min, $start_hour, ( localtime time )[3, 4, 5]);
    $end_time   = timelocal(0, $end_min, $end_hour, ( localtime time )[3, 4, 5]);

    ##
    ## You really have to check two epoch ranges:
    ## For Example, Given: 23:30-01:30
    ##  * You're in range if the current time is 23:35
    ##    So check "today's 23:30 to next-day's 01:30"
    ##  * You're in range if the current time is 00:15
    ##    So check "prior-day's 23:30 to today's 01:30"
    ##
    if ($day_adj) {
        my $tmp_beg_time = $begin_time - 86400;
        my $tmp_end_time = $end_time   + 86400;

        return (
               ( $now >= $tmp_beg_time && $now <= $end_time     )
            || ( $now >= $begin_time   && $now <= $tmp_end_time )
        );
    }

    return ( $now >= $begin_time && $now <= $end_time );
}

