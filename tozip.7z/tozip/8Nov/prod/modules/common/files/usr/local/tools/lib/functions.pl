use POSIX qw(sys_wait_h strftime setsid :signal_h);
use Fcntl ':flock';
use IO::Handle;
use FindBin;
use File::Basename;
use File::Spec::Functions;
use Symbol;
use lib "$ENV{'HOME'}/utils/lib/perl5/5.8.0/i386-linux-thread-multi/Time";

$|			= 1;
my $script	= File::Basename::basename($0);
my $SELF	= catfile $FindBind::Bin, $script;

sub globalConstants {
	use vars qw(%CONFIG);
}

$TERMINATED = 0;

# This will search for files of $file_suffix (i.e. *.jsp) recursively or in
# one dir and run $run_cmd on every matching file
sub runCmdOnSuffix {
	my $top_level_dir	= shift;
	my $file_suffix		= shift;
	my $recursion		= shift;
	my $run_cmd			= shift;
	my @matched_files	= ();

	if (not defined($recursion)) {
		opendir DIR, "$top_level_dir" or die "Could not read $top_level_dir!\n$!\n";
			@matched_files = grep { /.*\.$file_suffix$/ } readdir(DIR);
		closedir DIR;
	}
	else {
		my @matched_files = `find $top_level_dir/ -name \"*.$file_suffix\"`
	}
	foreach (@matched_files) {
		chomp($_);
		print "$run_cmd $_\n";
	}

	return @matched_files;
}

# This will take a list of hosts or host files (/usr/local/etc/hosts.blah) as 
# arguments, parse and handle them accordingly and return the list of real 
# hostnames
sub processHosts() {
	warn "$DEBUG processHosts(): Begin\n"				if ($DEBUG);	#DEBUG
	my $hosts_dir		= '/usr/local/etc';
	warn "$DEBUG hosts_dir=$hosts_dir\n"				if ($DEBUG);	#DEBUG
	local @return		= ();
	foreach (@_) {
		chomp($_);
		my $host		= "$_";
		warn "$DEBUG host=$host\n"						if ($DEBUG);	#DEBUG
		my $hosts_file		= "$hosts_dir/hosts.$host"		if ( -e "$hosts_dir/hosts.$host" );
		warn "$DEBUG hosts_file=$hosts_file\n"				if ($DEBUG);	#DEBUG
		if ($hosts_file) {
			open HOSTSFILE, "$hosts_file" or die "Could not open $hosts_file: $!\n";
				while (<HOSTSFILE>) {
					next if /^#|^\s+/;
					chomp($_);
					print "Host \"$_\" is... ";
					$host_alive		= &ping_host($_,'3');
					print "alive!\n"						if ($host_alive);
					print "dead!  Skipping \"$_\".\n"		if (! $host_alive);
					push(@return,$_)						if ($host_alive);
					print "$_ not responding.  Skipping.\n"	if (! $host_alive);
				}
				close HOSTSFILE;
		} else {
			print "Host \"$host\" is... ";
			$host_alive		= &ping_host($host,'3');
			print "alive!\n"								if ($host_alive);
			print "dead!  Skipping \"$host\".\n"			if (! $host_alive);
			push(@return,$_)								if ($host_alive);
			print "$host not responding.  Skipping.\n"		if (! $host_alive);
		}
	}

	warn "$DEBUG return=@return\n"						if ($DEBUG);	#DEBUG
	warn "$DEBUG processHosts(): End\n"					if ($DEBUG);	#DEBUG
	return @return;
}

sub random
{   my $num = pop @_;

    return int rand($num);
}

sub random_array()
{   my @array = $_1;

    my $size = scalar(@array);

    my $elem = random("$size");

    return $array["$elem"];
}

sub openFile() {
	local(
		$myFunc,
		$return,
		$action,
		$file,
		$openMode,
		$failString
	);
	$myFunc		= getFuncName();
	warn "$debugPrepend $myFunc: Begin\n"		if ($DEBUG);

	$file		= shift;
	warn "$debugPrepend file=$file\n"		if ($DEBUG);
	$action		= shift;
	warn "$debugPrepend action=$action\n"		if ($DEBUG);
	$failString	= "Could not open $file for action $action";

	for ($action) {
		$openMode	= '<'			if /^read$|^$/;
		$openMode	= '>>'			if /^append$/;
		$openMode	= '>'			if /^trunc[ate]$|^write$/;
		$openMode	= '+<'			if /^tmp$|^temp[orary]$|^readwrite$|^rw$/;
		$openMode	= '+>'			if /^rwtrunc$|^rw_trunc$|^rw_new$/;
		$openMode	= '+>>'			if /^rwappend$|^rw_append$/;
	}

	open "$return $mode $file" or die "$failString: $!\n";

	warn "return=$return\n"                           if ($DEBUG);
	warn "$debugPrepend $myFunc: End\n"		if ($DEBUG);
	return $fh;
}

sub close_file(*)
{	warn "close_file @_\n"                                      if ( $DEBUG );
    my $fh = shift @_;
#    $fh = qualify_to_ref($fh, caller());
	
	unlock_file($fh);
	close $fh or warn "Unable to close filehandle at $fh: $!\n";
	warn "return close_file $fh\n"                               if ( $DEBUG );
}

sub lock_file(*)
{	warn "lock_file @_\n"                                       if ( $DEBUG );
    my $fh = shift @_;
#    $fh = qualify_to_ref($fh, caller());
	my $type = shift @_;
    my $i=0;
	
	until ( flock ($fh, $type) ) 
    {   if ( $i++ > 30 )
        {   warn "Unable to flock $fh $type in $i tries: $!\n"; 
            $i=0;
        }
    }
	warn "return lock_file @_\n"                                if ( $DEBUG );
}

sub unlock_file(*)
{	my $fh = shift @_;
#    $fh = qualify_to_ref($fh, caller());
	my $type = LOCK_UN;

	flock ($fh, $type);
}

sub default_handler {
    my $signame = shift;
    warn "Got SIG$signame on $0 at PID $$: Cleaning up\n"           if ($DEBUG);
    $TERMINATED++;
}

sub ignore_handler {
    my $signame = shift;
    warn "Got SIG$signame on $0 at PID $$: ignoring\n";
    return;
}

sub child_handler {
    $waitedpid = wait;
    $SIG{CHLD} = \&child_handler;
}

sub sigHUP_handler {
	warn "Got SIGHUP on $script at PID $$: Restarting\n"			if ($DEBUG);
	exec($SELF, @_) or die "Couldn't restart: $!\n";
}

sub timestamp {
    my $now_string  = strftime "%b %e %H:%M:%S", localtime;

    return "$now_string";
}

sub toggle {
    my $current = shift @_;
    if ( $current ) {
        $current = 0;
    } else {
        $current = 1;
    }

    return $current;
}

sub postPartem {
    my $signame = shift;
    warn "Got SIG$signame on $0 at PID $$: killing all children\n"  if ($DEBUG);
    $MASSACRED++;
}


sub getFuncName {
	local(
		$myFunc,
		$return
	}
	$myFunc		= 'getFuncName';
	warn "$debugPrepend $myFunc: Begin\n";

	$return		= (caller(1))[3];

	warn "$debugPrepend return=$return\n"; 
	warn "$debugPrepend $myFunc: End\n"; 
	return $return;
}


sub getLastFuncName {
	local(
		$myFunc,
		$return
	}
	$myFunc		= 'getLastFuncName';
	warn "$debugPrepend $myFunc: Begin\n";

	$return		= (caller(2))[3]; 

	warn "$debugPrepend return=$return\n"; 
	warn "$debugPrepend $myFunc: End\n"; 
	return $return;
}

}

sub solicitUser {
        my $var = shift;
        my $new;
        print "Give me a value for $var: ";
        $new = <STDIN>;
        chomp $new;
        return $new;
}


# SMTP Notification
# 1st Argument = Recipient addresses, comma sepparated, no spaces
# 2nd Argument = From-address
# 3rd Argument = SMTP Relay Host address
# 4th Argument = Subject (must be encapsulated in quotes (""|'')
# Everything after that = Body (optional)
sub smtp_notify() {
	use Net::SMTP;
	my @to			= split(/\,/, shift);
	my $from		= shift;
	my $addhost		= shift;
	my @mailhosts	= split(/\,/, $addhost);
	my $subject		= shift;
	my $body		= "@_";
	my $mainto		= "$to[0]";
	shift(@to);
	my $cc_list		= join(',', @to);
	unshift(@to,$mainto);
	my $lhostname	= gethostbyhostname('fqdn');
	$DEBUG			= '';

	if ($from !~ /^.*@.*$/) { $from	.= "\@$lhostname"; }

	$body			= $subject if ($body =~ /^$/);

	print "to=$mainto\nfrom=$from\nsmtp=$addhost\nsubject=$subject\nbody=$body\n" if ($DEBUG);
	my $smtp = Net::SMTP->new(@mailhosts);
	$smtp->mail($from);
	foreach (@to) {
		chomp($_);
		$smtp->recipient($_,
			{ SkipBad => TRUE }
		);
	}
	$smtp->data();
	$smtp->datasend("To: $mainto\n");
	$smtp->datasend("Cc: $cc_list\n");
	$smtp->datasend("From: $from\n");
	$smtp->datasend("Subject: $subject\n");
	$smtp->datasend("\n");
	$smtp->datasend($body);
	$smtp->dataend();
	$smtp->quit;
	$return		= "$smtp";
	return "$return";
}

# Cool Rsync functionality
# Usage: rsync_perl("$sshopts","$addargs","$source","$dest")
# sshopts - example: "ssh -i ~/.ssh/id_dsa_cvskey -T -x"
# sshopts - example: "ssh"
# addargs - example: '-vrx --exclude="bin" --stats --relative'
# source - example: "$host:/app"
# source - example: '/app'
# dest - example: '/'
# dest - example: "$host:/"
# Throw --noexclude or -noexclude into addargs to have rsync not exclude
sub rsync_perl() {
	warn "$DEBUG rsync_perl(): Begin\n"					if ($DEBUG);	#DEBUG
	my $sshopts		= shift;
	warn "$DEBUG sshopts=$sshopts\n"					if ($DEBUG);	#DEBUG
	my $addargs		= shift;
	warn "$DEBUG addargs=$addargs\n"					if ($DEBUG);	#DEBUG
	my $source		= shift;
	warn "$DEBUG source=$source\n"						if ($DEBUG);	#DEBUG
	my $dest		= shift;
	warn "$DEBUG dest=$dest\n"							if ($DEBUG);	#DEBUG
	my $date		= get_date('stamp');
	warn "$DEBUG date=$date\n"							if ($DEBUG);	#DEBUG
	my $ssh			= '';
	local @return		= ();
	my @split_arg	= ();
	my $dst_host	= '';
	my $host_alive	= '';
	my $fh			= '';

	# let's make ourselves a custom ssh shell script temporarilly
	if ($sshopts !~ /^ssh$/) {
		while ( -f "/tmp/$$.$date.sh") {
			warn "$DEBUG Found: /tmp/$$.$date.sh\n"		if ($DEBUG);	#DEBUG
			$date++;
			warn "$DEBUG Date changed to: $date\n"		if ($DEBUG);	#DEBUG
		}

		$ssh = "/tmp/$$.$date.sh";
		warn "$DEBUG ssh=$ssh\n"						if ($DEBUG);	#DEBUG

		$fh			= &openFile("$ssh",'write');
			print $fh "#!/bin/sh\n";
			if ($sshopts =~ /^ssh\s/) {
				print $fh "$sshopts \$*\n";
			} else {
				print $fh "ssh $sshopts \$*\n";
			}
		&close_file("$fh");

		warn "$DEBUG chmod 0700, $ssh\n"				if ($DEBUG);	#DEBUG
		chmod 0700, $ssh;

	} else {
		# If just plain ol' "ssh" was specified then we needn't create a script
		$ssh			= "ssh";
		warn "$DEBUG ssh=$ssh\n"						if ($DEBUG);	#DEBUG
	}

	# now let's prepare rsync
	my @defaults	= (
		'--verbose',
		'--temp-dir=/tmp',
		'--checksum',
		'--perms',
		'--group',
		'--times',
		'--whole-file',
		'--exclude="*.sbk"',
		'--exclude="*_log"',
		'--exclude="*_log.*"',
		'--exclude="*.log"',
		'--exclude="*.log.*"',
		'--exclude="*.core"',
		"--rsh=\"$ssh\""
	);
	if ($DEBUG) {														#DEBUG
		foreach (@defaults) {											#DEBUG
			chomp($_);													#DEBUG
			warn "$DEBUG rsync option: $_\n";							#DEBUG
		}																#DEBUG
	}																	#DEBUG

	my @user_args	= ("$addargs");
	warn "$DEBUG user_args=@user_args\n"				if ($DEBUG);	#DEBUG
	my @rsync_args	= ();

	# Bring the user's args into a list that we can compare against our list
	ARG: foreach (@user_args) {
		chomp($_);
		if (-e "$_") { my $log_file = "$_"; next ARG; }
		if (/--no-ping/) { my $noping = '1'; next ARG; }
		next if /^--noexclude|^-noexclude/;
		push(@rsync_args,$_);
	}
	warn "$DEBUG 1: rsync_args=@rsync_args\n"			if ($DEBUG);	#DEBUG

	if ($DEBUG) {														#DEBUG
		warn "$DEBUG log_file=$log_file\n";								#DEBUG
		warn "$DEBUG noping=$noping\n";									#DEBUG
	}

	# Build the argument list by comparing the user's args against our args
	foreach (@defaults) {
		chomp($_);
		next if ($addargs =~ /--noexclude|-noexclude/ and $_ =~ /^--exclude/);
		push (@rsync_args,$_) if ($addargs !~ /$_/);
	}
	warn "$DEBUG 2: rsync_args=@rsync_args\n"			if ($DEBUG);	#DEBUG

	# Push the source and destination host/dir/file into the final arg list
	push(@rsync_args,$source);
	push(@rsync_args,$dest);
	warn "$DEBUG 3: rsync_args=@rsync_args\n"			if ($DEBUG);	#DEBUG

	# Get the source/dst hostname and ping it to see if it's alive
	@split_arg	= split(/:/, $source) if ($source =~ /:/);
	@split_arg	= split(/:/, $dest) if ($dest =~ /:/);
	$dst_host	= shift(@split_arg);
	$host_alive	= ping_host($dst_host,'3')				if (! $noping);

	@return			= "Ping of host '$dst_host' failed.  Skipping $dst_host." if (! $host_alive && ! $noping);
	if ($log_file) {
		warn "$DEBUG exec: rsync @rsync_args\n"			if ($DEBUG);	#DEBUG
		open LOG,"rsync @rsync_args |" if ($host_alive);
		my $fh = &openFile("$log_file",'write');
		while (<LOG>) {
			print $fh "$_";
		}
		&close_file("$fh");
		close LOG;
	} else {
		system "rsync @rsync_args" if ($host_alive);
	}

	if ( -f "$ssh") {
		system "rm -f $ssh";
	}

	warn "$DEBUG return=@return\n"						if ($DEBUG);	#DEBUG
	warn "$DEBUG rsync_perl(): End\n"					if ($DEBUG);	#DEBUG
	return @return;

}

# Handy little dir traversal subroutine
sub scale_dirs() {
	local $action		= shift;
	my $sample		= shift;
	my @diced_path	= split(/\//, $sample);
	local $return		= '';

	if ($action =~ /working/) {
		for (@diced_path) {
			pop;
			$return		= join('/', @diced_path);
		}
	}

	return "$return";
}

# Tar handling
sub tar_improved() {
	use Archive::Tar;
	local $action	= shift;

	if ($action =~ /^make/) {
		my @fileList	= split(/\,/, shift);
		my $archiveName	= shift;

		# Figure out what dir we're working with
		# Not actually using it right now, but could be handy later
		my $workingDir	= &scale_dirs('working',pop(@fileList));

		my $tar		= Archive::Tar->new();
		$tar->add_files(@fileList);
		$tar->write("$archiveName");
	}

	return "$tar";
}

# Cool little function to return a long date and time mix for timestamping
# [Deprecated] Use get_date() instead.
sub get_date_timestamp {
	local $return		= `date '+\%Y\%m\%d\%H\%M\%S'`;
	chomp($return);

	return "$return";
}

sub get_date() {
	my $type		= shift;
	local $return		= '';

	for ($type) {
		$return			= `date`	if /log|^$/;
		$return			= `date '+\%Y\%m\%d\%H\%M\%S'`	if /stamp/;
		$return			= `date '+\%G-\%m-\%d'`			if /short/;
		$return			= `date '+\%G'`					if /year/;
	}
	chomp($return);

	return "$return";
}

sub proxy_cmd() {
	use Getopt::Std;
	my $proxy_to_host = shift;
	my $proxy_to_command = shift;
	my %ssh_opts = ();
	my @sshargs = ();
	Getopts(\%ssh_opts, 'txi:');

	foreach (keys(%ssh_opts)) {
		push(@sshargs,'-t') if ($_ =~ /t/);
		push(@sshargs,'-x') if ($_ =~ /x/);
		push(@sshargs,"-i $ssh_opts{$_}") if ($_ =~ /i/);
	}

	my $arg_string = "@sshargs";
	my $proxy_cmd = "ssh $arg_string $proxy_to_host \"$proxy_to_command\"";
	system "$proxy_cmd";
}

# Simple subroutine for checking if an IP address exists in an apache conf
# file under $conf_dir.  Sanity-checks the input and obscures information
# not relative to a RewriteCond.
sub check_ip_in_apacheconf() {
	globalConstants();
	my $ip_address	= shift;
	my $conf_file	= shift;
	my $conf_dir	= '/opt/www/dmsconf';
	my $count		= NUMBER_ZERO;
	my @file		= ();
	my @result		= ();
	my @includes	= (
		'RewriteCond',
		'RewriteRule'
	);
	my $include_strings	= join('|', @includes);

	if ($ip_address !~ /^.*\..*\..*\..*$/) {

		$CONFIG{'lame'}		= "Not a valid IP address format: $ip_address";

	} else {

		open FILE, "$conf_dir/$conf_file" or die "$!\n";
			@file = <FILE>;
		close FILE;

		for ($ip_address) {
			tr/./\./;
			@result = grep { /$ip_address/ && -f "$conf_dir/$conf_file" } @file;
		}

		foreach (@result) {
			chomp($_);
			next if !/^$include_strings/;
			if ($count > NUMBER_ZERO) {
				$CONFIG{"$ip_address\_$count"}	= "$_ <- [duplicate]";
			} else {
				$CONFIG{"$ip_address\_$count"}	= "$_";
			}
			$count++;
		}

	}
	if (! %CONFIG) {
		$CONFIG{'noresult'}	= "Could not find a match";
	}
	return %CONFIG;
}

# Pings given host with given timeout, returns TRUE/1 on sucess and FALSE/0
# on failure.
sub ping_host {
	warn "$DEBUG ping_host(): Begin\n"					if ($DEBUG);	#DEBUG
	use IO::Socket::INET;
    my $dst_host	= shift;
	warn "$DEBUG dst_host=$dst_host\n"					if ($DEBUG);	#DEBUG
	my $timeout		= shift;

	if (not defined($timeout)) {
		$timeout	= '3';
	}
	warn "$DEBUG timeout=$timeout\n"					if ($DEBUG);	#DEBUG
   
    my $socket		= IO::Socket::INET->new(
						PeerAddr => $dst_host,
						PeerPort => '22',
						Proto    => 'tcp',
						Timeout  => $timeout,
						Type     => SOCK_STREAM
					);
	local $return		= $socket;

	warn "$DEBUG return=$return\n"						if ($DEBUG);	#DEBUG
	warn "$DEBUG ping_host(): End\n"					if ($DEBUG);	#DEBUG
    return $return;
}

# Subroutine for reaping hung child processes
sub reap_child() {
	my $child		= '';
	while (($child = waitpid(-1,WNOHANG)) > 0){
		$Kid_Status{$child} = $?;
	}
	$SIG{CHLD} = \&reap_child;

# Use this in your fork() routines:
#$SIG{CHLD} = \&reap_child;
}

# This is the fastest routine I could come up with to would strip off
# the first 'n' elements of an array when you do not know the total number of
# elements.  If you can think of a better way, please upgrade this subroutine.
# Remember, zero is an inclusive number.
sub strip_elem_from_top() {
	my @array		= split(/\s|\n/, shift);
	my $strip		= shift;
	local @return		= ();
	unshift(@return,pop(@array)) while $#array - $strip;

	return @return;
}

# Simple ".cvsstop" file support.
# SYNOPSIS:
# 	cvs_stop('check',"$ENV{'HOME'}/utils")		# Returns 1 if found
# 	cvs_stop('create','/usr/local/zones')		# Returns 0 if created
# 	cvs_stop('kill','/opt/www/dmsconf')			# Returns 0 if killed
sub cvs_stop() {
	local $action		= shift;
	my $sandbox			= shift;
	local $stop_file	= ".cvsstop";
	
	for ($action) {
		$return				= (-f "$sandbox/$stop_file") if /check/;
		$return				= system "touch $sandbox/$stop_file" if /create/;
		$return				= system "rm -f $sandbox/$stop_file" if /kill/;
	}

	return $return;
}

# Rather self-explanitory cvs wrapper
# SYNPOSIS:
# 	cvs_perl("checkout","<file1> <file2> <file...>")
# 	cvs_perl("checkout -r LATEST_REV","<file1> <file2> <file...>")
# 	cvs_perl("commit","<file1> <file2> <file...>","These files are updated")
# 	cvs_perl("commit -r STABLE_REV","<file1> <file2> <file...>","Stable files")
# 	cvs_perl("update","<file1> <file2> <file...>")
# 	cvs_perl("update -r RELEASE_REV","<file1> <file2> <file...>")
# 	cvs_perl("delete","<file1> <file2> <file...>")
# 	cvs_perl("add","<file1> <file2> <file...>")
sub cvs_perl() {
	local $action		= shift;
	local $fileList		= shift;
	local $cvsArgs		= "$action";
	my $msg	= "@_";
	local $cvsCmd		= '';

	for (`which cvs`) {
		chomp;
		$cvsCmd			= "$_" if -x;
		$cvsCmd			= "cvs" if not -x;
	}

	for ($action) {
		$cvsArgs	= "$action -C $fileList"	if /update/;
		$cvsArgs	= "$action -C $fileList"	if /update/;
		$cvsArgs	= "$action $fileList"		if /checkout|add|delete/;
		$cvsArgs	= "$action -m \"$msg\" $fileList"	if /commit/;
	}

	$return	= system "$cvsCmd $cvsArgs";
	return "$return";
}

sub gethostbyhostname() {
	my $type		= shift;
	local $return		= '';

	if ($type =~ /^fqdn$/)
	{ $return		= `hostname --fqdn`; }
	else
	{ $return		= `hostname`; }
	chomp($return);

	return "$return";
}

# Simple sub to strip matching criteria from a line or from lines of a file
# and return the result
sub strip_lines() {
	warn "$DEBUG strip_lines(): Begin\n"				if ($DEBUG);	#DEBUG
	my $item		= shift;
	warn "$DEBUG item=$item\n"							if ($DEBUG);	#DEBUG
	my $match		= shift;
	warn "$DEBUG match=$match\n"						if ($DEBUG);	#DEBUG
	my $fh			= '';
	my $line		= '';
	local @return		= ();

	return 1											if (! $item);
	return 1											if (! $match);

	if (-e "$item") {
		warn "$DEBUG  &openFile(\"$item\")\n"			if ($DEBUG);	#DEBUG
		$fh				= &openFile("$item");
		warn "$DEBUG fh=$fh\n"							if ($DEBUG);	#DEBUG
		while (<$fh>) {
			next if /$match/;
			chomp($_);
			$line			= "$_";
			push(@return,$line);
		}
		warn "$DEBUG Closing handle: $fh\n"				if ($DEBUG);	#DEBUG
		close_file("$fh");
	}

	warn "$DEBUG strip_lines(): End\n"					if ($DEBUG);	#DEBUG
	return @return;
}

# Counts the number of characters in $_[0]
sub count_string() {
	my $string		= shift;
	my $count		= '0';
	while ($string =~ /./g) {
		$count++;
	}
	local $return		= "$count";
	return $count;
}

sub host_lookup() {
	warn "$DEBUG host_lookup(): Begin\n"				if ($DEBUG);	#DEBUG
	my $host		= shift;
	warn "$DEBUG host=$host\n"							if ($DEBUG);	#DEBUG
	my $lookup_cmd	= 'dig';
	warn "$DEBUG lookup_cmd=$lookup_cmd\n"				if ($DEBUG);	#DEBUG
	my $lookup_args	= '+short';
	warn "$DEBUG lookup_args=$lookup_args\n"			if ($DEBUG);	#DEBUG
	my $pipe		= 'head -1';
	warn "$DEBUG pipe=$pipe\n"							if ($DEBUG);	#DEBUG
	local $return	= system "$lookup_cmd $lookup_args $host | $pipe";
	warn "$DEBUG exec: $lookup_cmd $lookup_args $host | $pipe\n"	if ($DEBUG);	#DEBUG
	warn "$DEBUG return=$return\n"						if ($DEBUG);	#DEBUG
	warn "$DEBUG host_lookup(): End\n"					if ($DEBUG);	#DEBUG
	return $return;
}

return 1;
