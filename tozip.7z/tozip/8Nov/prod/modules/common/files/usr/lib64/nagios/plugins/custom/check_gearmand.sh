#!/bin/bash
#
# Program       : TS-BUTLER plugin for Nagios
# Author        : Sean Heshmati 5/2005
# License       : GPL
# Description   : This plugin checks if TS-BUTLER GEARMAND is running.
#

. /usr/lib/nagios/plugins/utils.sh

PROGNAME=`/bin/basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1 $' | /bin/sed -e 's/[^0-9.]//g'`

print_usage() {
        echo "Usage:"
        echo " $0 "
        echo " $0 (-v | --version)"
        echo " $0 (-h | --help)"
}

print_help() {
    print_revision $PROGNAME $REVISION
    echo ""
    print_usage
    echo ""
    echo "This plugin checks if TS-BUTLER GEARMAND is running."
    echo ""
    support
}

exitstatus=$STATE_UNKNOWN

while test -n "$1"; do
    case "$1" in
        --help)
            print_help
            exit $STATE_OK
            ;;
        -h)
            print_help
            exit $STATE_OK
            ;;
        --version)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -V)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        *)
            echo "Unknown argument: $1"
            print_usage
            exit $STATE_UNKNOWN
            ;;
    esac
    shift
done

ts_butler_procs="gearmand"

for proc in `echo $ts_butler_procs`
do
    if [[ ! `ps ho pid -C $proc` ]]
    then
        not_running="$not_running $proc"
    fi
done

# Finally Inform Nagios of what we found...
if [ "$not_running" ]
then
        echo "CRITICAL -$not_running not running!"
        exitstatus=$STATE_CRITICAL
else
        echo "OK - TS-BUTLER GEARMAND processes are running"
        exitstatus=$STATE_OK
fi

exit $exitstatus

