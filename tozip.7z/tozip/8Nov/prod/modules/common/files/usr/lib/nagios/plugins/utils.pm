# Utility drawer for Nagios plugins.
# $Id: utils.pm,v 1.1 2018/10/30 10:12:00 mathew Exp $
#
# $Log: utils.pm,v $
# Revision 1.1  2018/10/30 10:12:00  mathew
# added the  PROD puppet modules to CVS repo
#
# Revision 1.2  2011/09/30 07:49:11  sunny
# updated as per new version of nagios plugins
#
# Revision 1.1.1.1  2005/10/11 20:05:30  bharris
# CFENGINE import
#
# Revision 1.1.1.1  2005/07/20 18:08:46  bharris
# The first import of the common linux data
#
# Revision 1.1  2005/04/06 23:56:04  root
# Initial revision
#
# Revision 1.6  2003/02/03 20:29:55  sghosh
# change ntpdc to ntpq (Jonathan Rozes,Thomas Schimpke, bug-656237 )
#
# Revision 1.5  2002/10/30 05:07:29  sghosh
# monitor mailq
#
# Revision 1.4  2002/05/27 02:01:09  sghosh
#  new var - smbclient
#
# Revision 1.3  2002/05/10 03:49:22  sghosh
# added programs to autoconf
#
# Revision 1.2  2002/05/08 05:10:35  sghosh
#  is_hostname added, update CODES to POSIX
#
# 
package utils;

require Exporter;
@ISA = qw(Exporter);
@EXPORT_OK = qw($TIMEOUT %ERRORS &print_revision &support &usage);

#use strict;
#use vars($TIMEOUT %ERRORS);
sub print_revision ($$);
sub usage;
sub support();
sub is_hostname;

## updated by autoconf
$PATH_TO_RPCINFO = "/usr/sbin/rpcinfo" ;
$PATH_TO_NTPDATE = "/usr/sbin/ntpdate" ;
$PATH_TO_NTPDC   = "/usr/sbin/ntpdc" ;
$PATH_TO_NTPQ    = "/usr/sbin/ntpq" ;
$PATH_TO_LMSTAT  = "" ;
$PATH_TO_SMBCLIENT = "/usr/bin/smbclient" ;
$PATH_TO_MAILQ   = "/usr/bin/mailq";

## common variables
$TIMEOUT = 15;
%ERRORS=('OK'=>0,'WARNING'=>1,'CRITICAL'=>2,'UNKNOWN'=>3,'DEPENDENT'=>4);

## utility subroutines
sub print_revision ($$) {
	my $commandName = shift;
	my $pluginRevision = shift;
	$pluginRevision =~ s/^\$Revision: //;
	$pluginRevision =~ s/ \$\s*$//;
	print "$commandName v$pluginRevision (nagios-plugins 1.4.15)\n";
	print "The nagios plugins come with ABSOLUTELY NO WARRANTY. You may redistribute\ncopies of the plugins under the terms of the GNU General Public License.\nFor more information about these matters, see the file named COPYING.\n";
}

sub support () {
	my $support='Send email to nagios-users@lists.sourceforge.net if you have questions\nregarding use of this software. To submit patches or suggest improvements,\nsend email to nagiosplug-devel@lists.sourceforge.net.\nPlease include version information with all correspondence (when possible,\nuse output from the --version option of the plugin itself).\n';
	$support =~ s/@/\@/g;
	$support =~ s/\\n/\n/g;
	print $support;
}

sub usage {
	my $format=shift;
	printf($format,@_);
	exit $ERRORS{'UNKNOWN'};
}

sub is_hostname {
	my $host1 = shift;
	if ($host1 && $host1 =~ m/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+|[a-zA-Z][-a-zA-Z0-9]+(\.[a-zA-Z][-a-zA-Z0-9]+)*)$/) {
		return 1;
	}else{
		return 0;
	}
}

1;
