#!/opt/blocperl/bin/perl
# 
#
# Program       : Symantec AV BLOB size check
# Author        : Sunny Jaisinghani	
# Description   : This plugin compares the size of the AV BLOB with the value of db_longreadlen and alerts accordingly.
#
#
# Check Explanation:
# This plugin fetches size of the largest AV ruleset BLOB from the AV_RULES table in the BLT schema
# and compares it with the limit set in the BLOC-CONFIG. The parameter which keeps a check on the AV 
# BLOB size is db_longreadlen. When the size of the AV blob increases beyond the threshold defined by 
# db_longreadlen, aztec_ruleset_daemon truncates it and leaves the processing unfinished. This fills 
# up the / file system on bt-ard servers causing other ruleset generation to stop.
#
#
# What to do:
# If Nagios alerts, we need to increase the value of the parameter db_longreadlen in CVS and restart ARD.
# The bloc-config file is located @ /space/orabloc/server/conf/ on bloc tools servers.
# CVS location is ~/cvs/cfm/tuc/cfm/var/cfengine/inputs/cfagent.conf. Edit the editfiles section in cfagent.conf
#
#

use strict;
use Getopt::Long;
use warnings;

BEGIN { require("/space/orabloc/server/conf/inc.pl") }

use File::Basename;
use BLOC::DB;
use BLOC::Config;
use BLOC::DB::Tools qw(:all);
use POSIX;
use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS);

my $exitstatus = $ERRORS{'UNKNOWN'};
my $warn = 97;
my $crit = 97;

##
#Get the value of the the largest AV BLOB from the AV_RULES table in BLT schema
##
my $db = BLOC::DB->new();
my $largest_blob = dbi_exec_for_scalar( $db, 'SELECT MAX(dbms_lob.getlength(data)) as datalen FROM blt.av_rules' );
$db->disconnect;
#print "\nValue of largest blob is : $largest_blob";

##
#Get the value of parameter db_longreadlen from BLOC CONFIG
##
my $config = BLOC::Config->new();
my $longreadlen = $config->get("db_longreadlen");
#print "\nValue of db_longreadlen is : $longreadlen ";


##
#Calculate the percentage to use for comparison
##
my $percentage = (($largest_blob/$longreadlen) * 100);
$percentage = floor($percentage);
#print "\nSize of largest blob is $percentage of db_longreadlen \n";


##sanity check
unless ( $warn <= $crit ) {
	print "\nError: Warning threshold cannot be more than Critical threshold";
	exit $exitstatus;
}

##
#compare the percentage value with the pre-defined Nagios thresholds
##

if ( $percentage >= $crit ) {
	$exitstatus = $ERRORS{'CRITICAL'};
}

elsif ($percentage >= $warn ) {
	$exitstatus = $ERRORS{'WARNING'}
	unless ( $exitstatus == $ERRORS{'CRITICAL'} );
}
else {
	$exitstatus = $ERRORS{'OK'}
	unless ( $exitstatus == $ERRORS{'WARNING'} or $exitstatus == $ERRORS{'CRITICAL'} );
}

##
#print the exit message
##

if ( $exitstatus == $ERRORS{'OK'} ) {
	print "OK: Size of AV BLOB is within limits \n";
}
elsif ( $exitstatus == $ERRORS{'WARNING'} ) {
	print "WARNING: Size of AV BLOB is $percentage% of db_longreadlen parameter. AV BLOB size = $largest_blob, db_longreadlen=$longreadlen\n";
} 
elsif ( $exitstatus == $ERRORS{'CRITICAL'} ) {
	print "CRITICAL: Size of AV BLOB is $percentage% of db_longreadlen parameter. AV BLOB size = $largest_blob, db_longreadlen=$longreadlen\n";
}
elsif ( $exitstatus == $ERRORS{'UNKNOWN'} ) {
	print "UNKNOWN: no data returned\n";
}


exit $exitstatus;

