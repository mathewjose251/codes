#!/bin/sh

##
## Event handler script for aztec-grabber
##
## Note: This script will only restart the grabbers if it is in a CRITICAL and HARD state.
##
## $Id: restart-grabber.sh,v 1.1 2018/10/30 10:12:04 mathew Exp $
##

BN=$(basename $0)

##
## Only run on aztec servers
##
if ! expr "$(uname -n)" : "aztec" >/dev/null
then
    echo "${BN}: This event handler only runs on aztec servers"
    exit 1
fi

HTTP_PID_FILE='/var/run/aztec/httpd.pid'
RESTART_CMD="/etc/init.d/aztec grabber-restart"

##
## Use the correct sudo(1) wrapper
##
if [ -e /usr/bin/sudo ]
then
        SUDO=/usr/bin/sudo
else
        SUDO=/usr/local/bin/sudo
fi

##
## If aztec's web servers are not running don't restart the grabbers
##
test ! -f $HTTP_PID_FILE && exit 0

##
## We're a go, launch the grabbers
##
MSG=`$SUDO $RESTART_CMD 2>&1`

echo "$MSG"
exit 0

