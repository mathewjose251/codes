# This file must be sourced, not executed.

# $Author: mathew $
# $Date: 2018/10/30 10:12:08 $
# $Header: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/local/tools/lib/defaults.sh,v 1.1 2018/10/30 10:12:08 mathew Exp $
# $Revision: 1.1 $

# Contains all of the default environment variables and functions that
# everything should use.

# Standard directories
TOOLS_DIR='/usr/local/tools';
binDir="$TOOLS_DIR/bin";
etcDir="$TOOLS_DIR/etc";
libDir="$TOOLS_DIR/lib";
shareDir="$TOOLS_DIR/share";
manDir="$shareDir/man";
PERL5LIB="$TOOLS_DIR/lib/perl5:$PERL5LIB";
MANPATH="$manDir:$MANPATH";
PATH="$binDir:/usr/local/bin:/usr/local/sbin:/usr/sbin:/sbin:$PATH";

# Standard binaries and files
cvsBin='cvs';
function setCvsCmd {
	cvsCmd="$cvsBin";
}
namedCmd='rndc';
lsofCmd='lsof';
netstatCmd='netstat';
nslookupCmd='nslookup';
digCmd='dig';
cvsStopFile='.cvsstop';
sshCmd='/usr/bin/ssh';

# Error levels (often used when calling lprint())
LVL_USERDEF=0;
LVL_DEBUG=1;
LVL_INFO=2;
LVL_WARN=3;
LVL_ERROR=4;
LVL_CRITICAL=5;

# Determine the OS type and set $OSTYPE
# Set the operating system types here
osTypes='solaris|sunos linux';
for os in $osTypes; do
	uname -s | grep -Eqi "$os" > /dev/null 2>&1;
	if [ $? -eq 0 ]; then OSTYPE="$os"; fi
done
if [ $DEBUG ]; then echo "$debug: OSTYPE=$OSTYPE"; fi

# Figure out which mail client to use
case $OSTYPE in
	linux)			mailCmd='mail'; cvsBin='/usr/bin/cvs';;
	sunos|solaris)	mailCmd='mailx'; cvsBin='/usr/local/bin/cvs';;
	*)		mailCmd='echo';;
esac

# Define the CVS binary
setCvsCmd;

if [ $DEBUG ]; then echo "$debug: mailCmd=$mailCmd"; fi

# If we're running in AUTO mode and not INTERACTIVE, setup mailing of
# output.
#if [ 0$INTERACTIVE -eq 0 ] && [ 0$AUTO -ne 0 ] && [ 0$LOGOUT -eq 0 ]; then
#	MAILOUT=1;
#fi

# Exports happen at the end of this file


function getDate {
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: Begin";
	returnCode=0;
	date=`date '+%G%m%d%H%M%S'`;
	if [ $? -ne 0 ]; then
		returnCode=$?;
	fi
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: exec: \`date '+%G%m%d%H%M%S'\`";
	dateLong=`date '+%B %d, %G'`;
	if [ $? -ne 0 ]; then
		returnCode=$?;
	fi
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: exec: \`date '+%B %d, %G'\`";
	dateShort=`date '+%G-%m-%d'`;
	if [ $? -ne 0 ]; then
		returnCode=$?;
	fi
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: exec: \`date '+%G-%m-%d'\`";
	dateLog=`date`;
	if [ $? -ne 0 ]; then
		returnCode=$?;
	fi
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: exec: \`date\`";
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: Return will be: $returnCode";
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: End";
	return $returnCode;
}

function getLevel {
	level=$1;
	returnCode=0;
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: Begin";
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: level=$level";
#	lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";

	case $level in
		0)	levelName='USER_DEFINED';;
		1)	levelName='DEBUG';;
		2)	levelName='INFO';;
		3)	levelName='WARNING';;
		4)	levelName='ERROR';;
		5)	levelName='CRITICAL';;
		*)	levelName='UNKNOWN'; let returnCode++;;
	esac

	return $returnCode;
}

function lprint {
	level=$1;
	string="$2";
	STATUS=0;
	returnCode=0;
	Subject=;
	if [ "$OSTYPE" = 'linux' ]; then
		echoArgs=' -e ';
	else
		echoArgs=' ';
	fi

	if [ "x$string" = "x" ]; then
		STATUS=1;
	fi

	Subject=`/bin/echo "$string" | head -1`;

	if [ 0$STATUS -eq 0 ] && [ 0$level -ge 0$logLevel ]; then

		# Print out to a log file
		if [ 0$LOGOUT -ne 0 ]; then
			getLevel $level;
			unset returnCode;
			getDate 'log';
			unset returnCode;
			/bin/echo$echoArgs"$dateLog [$levelName] `basename $0`: $string" >> $LOGFILE;
			returnCode=$?;
		fi

		# Print out to a mail client
		if [ 0$MAILOUT -ne 0 ] && [ 0$level -ne $LVL_DEBUG ]; then
			cmdString="/bin/echo$echoArgs\"$string\" | $mailCmd -s \"$Subject\" $MAILTO";
			/bin/echo$echoArgs"$string" | $mailCmd -s "$Subject" $MAILTO;
			STATUS=$?;
			if [ $returnCode -eq 0 ]; then
				returnCode=$STATUS;
			fi
		fi

		# Print to STDOUT
		if [ 0$AUTO -eq 0 ] || [ 0$INTERACTIVE -ne 0 ]; then
			/bin/echo$echoArgs"$string";
		fi
	fi

	return $returnCode;
}

function myDie {
	returnCode=$1;
	returnMsg="$2";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: Begin";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: returnMsg=$returnMsg";

	if [ "x$returnMsg" != "x" ]; then
		echo "$returnMsg" | grep -qE '\n$' > /dev/null 2>&1;
		if [ 0$? -ne 0 ]; then
			returnMsg="$returnMsg \n";
		fi
		lprint $returnCode "$returnMsg";
	fi

	lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: End";
	exit $returnCode;
}

# If you are manipulating specific files, dirs or projects, you must have
# certain variables populated before calling this.  See below within the
# code for explanations of the necessary variables.
function cvsBash {
	action=$1;
	shift 1;
	declare -a itemList=($*);
	actionRegex='^update -.*|^commit -.*|^import -.*';
	returnCode=0;
	lprint $LVL_DEBUG "$debug: $FUNCNAME: Begin";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: action=$action";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: itemList=${itemList[*]}";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: CVSROOT=$CVSROOT";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: CVS_RSH=$CVS_RSH";

	# Override the cvs binary
	setCvsCmd;

	if [ "x$cvsCmd" = "x" ]; then
		output="Could not find a suitable executable for 'cvs'.\n";
		returnCode=1;
		lprint $LVL_DEBUG "$debug: $FUNCNAME: output=$output";
		lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";
	fi

	if [ "x$cvsUser" != "x" ] && [ "$cvsUser" != "$USER" ]; then
		cvsCmd="sudo -u $cvsUser $cvsCmd";
	fi

	# Adjust arguments and output based on the action
	action=`echo $action | tr -d " "`;
	case $action in
		update)
			actionArgs="-CPd $actionArgs";;
		commit|import)
			actionArgs="-m '$msg' $actionArgs";
			if [ "x$msg" = "x" ]; then
				output="No message was given for '$action'.\n";
				let returnCode++;
				lprint $LVL_DEBUG "$debug: $FUNCNAME: output=$output";
				lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";
			fi
			if [ "x${itemList[0]}" = "x" ]; then
				output="Some arguments are missing for '$action'.\n";
				lprint $LVL_DEBUG "$debug: $FUNCNAME: output=$output";
			fi
			append="${itemList[*]}";;
		*)
			output="'$action' is an unsupported action.\n";
			let returnCode++;
			lprint $LVL_DEBUG "$debug: $FUNCNAME: output=$output";
			lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";
			return $returnCode;;
	esac

	# Setup the command to run, support dry run mode
	cmd="$DRYRUN $cvsCmd $cvsArgs $action $actionArgs $append";
	cmd=`echo "$cmd" | tr -s "  " " "`;
	lprint $LVL_DEBUG "$debug: $FUNCNAME: cmd=$cmd";

	# Run the command if there have been no problems up until this point
	if [ 0$returnCode -eq 0 ]; then
		unset RETURN;
		# Branched off "update" because its output was too long.
		# -- Beam
		if [ "$action" = "update" ]
		then
			# The below does what was originally intended, but is
			# too slow with long lists because it uses "for", which
			# is necessary because of the use for "lprint".  I just
			# commented the who thing out.  -- Beam
#			firstline="1"
#			nl="
#"
#			IFSsave="$IFS"
#			IFS="$nl"
#			for output in `IFS="$IFSsave"; $cmd 2>&1; export RETURN=$?; IFS=$nl; exit $RETURN`
#			do
#				IFS="$IFSsave"
#				if [ "$firstline" = "1" ]
#				then
#					lprint $LVL_DEBUG "$debug: $FUNCNAME: output=$output"
#					firstline="0"
#				else
#					lprint $LVL_DEBUG "$output"
#				fi
#				IFS="$nl"
#			done
#			IFS="$IFSsave"
#			returnCode=$RETURN
#			unset firstline IFSsave RETURN
			# This just runs "$cmd" and trashes the output.
			# -- Beam
			$cmd >/dev/null 2>&1
			returnCode=$?
		else
			# This doesn't work with "update" because the output is
			# too long, as stated above.  --Beam
			output=`$cmd 2>&1; export RETURN=$?; exit $RETURN`;
			returnCode=$RETURN;
			unset RETURN;
			lprint $LVL_DEBUG "$debug: $FUNCNAME: output=$output";
		fi
	else
		lprint $LVL_ERROR "ERROR: Failed to run: $cmd";
		lprint $LVL_ERROR "Output:";
		lprint $LVL_ERROR "$output";
	fi

	unset action;
	unset actionArgs;
	unset cmd;
	unset append;
	unset cvsUser;
	cvsUser='';

	lprint $LVL_DEBUG "$debug: $FUNCNAME: returnCode=$returnCode";
	lprint $LVL_DEBUG "$debug: $FUNCNAME: End";
	return $returnCode;
}
		
# Exports
export TOOLS_DIR binDir etcDir shareDir libDir manDir PERL5LIB MANPATH PATH;
export cvsCmd namedCmd lsofCmd netstatCmd nslookupCmd digCmd cvsStopFile sshCmd;
export OSTYPE;
export SOURCED_DEFAULTS=1;
return 0;
