# Note: This file was tabbed out in a view using four spaces for tabs

# This pack of code is dedicated to error handling and output levels (i.e.
# debug levels and log levels.)  $logLevel must be globally declared with
# an integer value no less than zero in order for these functions to work.
# You can define the value of $logLevel with any of the below "LVL_*"
# constants.  You should also have the $quiet and $verbose variables
# declared globally.  The values of $quiet and $verbose will be used by
# the code below to adjust the $logLevel appropriately.

# Required resources that must be load by parent script:
# libmain.pl
use FindBin qw($Bin);
use lib "$Bin/../lib";
require "libmain.pl";
require "TableOfConstants";

# Definition of the various output levels.  Must be a constant.
use constant LVL_USERDEF => 5;	# A custom, user-defined level
use constant LVL_DEBUG => 4;	# Debugging output, good for troubleshooting
use constant LVL_INFO => 3;	# General info output, good for testing code mods
use constant LVL_WARN => 2;	# Warnings where something is wrong but won't break
use constant LVL_ERROR => 1;	# Errors where script cannot continue
use constant LVL_CRIT => 0;	# Critical errors that complete break the script

# Read in additional error constants
require "TableOfConstants";

# If a debug level has been specified, then adjust the $logLevel to LVL_DEBUG.
if ($debugLevel and $debugLevel > 0) {
	$logLevel		= LVL_DEBUG			if ($logLevel);
}

# If $logLevel is not declared, this will define it with a default value of
# LVL_DEBUG.  If it is declared and has a non-integer value, it will die.
if (not defined $logLevel) {
	our $logLevel	= LVL_DEBUG();
} elsif (not int($logLevel)) {
	$!				= BAD_DATA_TYPE();
	&cleanExit($!,"\$logLevel has a non-integer value");
}

# If either $quiet or $verbose are not declared, declare them and give them
# a value of zero
if (not defined $verbose) {
	our $verbose	= 0;
} elsif (not defined $quiet) {
	our $quiet		= 0;
}

# When this is called by the parent script, it subtracts $quiet from $logLevel
# and adds $verbose to $logLevel if either variable is globally defined.
# Returns with a value equal to the final $logLevel integer.
sub setLogLevel() {
	my(
		$myFunc,
		$return
	);
	$myFunc			= debugInfo('subroutine');		# In libmain.pl
	warn "$debugPrepend $myFunc: Begin\n"	if ($DEBUG);

	# If $verbose has a value greater than zero, add it to $logLevel
	if ($verbose gt 0) {
		$logLevel		+= $verbose;
	# If $quiet has a value greater than zero, subtract it from $logLevel
	} elsif ($quiet gt 0 and $quiet <= $logLevel) {
		$logLevel		-= $quiet;
	}
	warn "$debugPrepend \$logLevel=$logLevel\n"	if ($DEBUG);

	$return			= $logLevel;
	warn "$debugPrepend \$return=$return\n"	if ($DEBUG);
	warn "$debugPrepend $myFunc: End\n"	if ($DEBUG);
	return $return;
}

# Takes one argument of an integer value equal to or greater than LVL_USERDEF
# and returns a string name for the output level that matches the integer or
# returns null if there is no match.
sub getLevelName($) {
	my(
		$myFunc,
		$return
	);
	$myFunc			= debugInfo('subroutine');		# In libmain.pl
	warn "$debugPrepend $myFunc: Begin\n"	if ($DEBUG);

	my $levelInt	= int(shift);
	for ($levelInt) {
		$return			= 'USERDEF'			if ($_ == LVL_USERDEF());
		$return			= 'DEBUG'			if ($_ == LVL_DEBUG());
		$return			= 'INFO'			if ($_ == LVL_INFO());
		$return			= 'WARNING'			if ($_ == LVL_WARN());
		$return			= 'ERROR'			if ($_ == LVL_ERROR());
		$return			= 'CRITICAL'		if ($_ == LVL_CRIT());
	}

	warn "$debugPrepend \$return=$return\n"	if ($DEBUG);
	warn "$debugPrepend $myFunc: End\n"	if ($DEBUG);
	return $return;
}


# This is the standard wrapper for print(), which factors in output levels.
# The first argument taken is the output level of the string to be printed.
# This must be an integer value of no less than zero.  If that number is
# equal to or greater than the integer value of the global $logLevel, then
# the second argument will be printed to stdout as a literal string.  A third
# argument may be given in the form of a FILEHANDLE.  Returns false if
# no print is performed or returns the output level at which the string was
# printed.
sub lprint {
	my(
		$myFunc,
		$return,
		$levelName
	);
	$myFunc			= debugInfo('subroutine');		# In libmain.pl
	warn "$debugPrepend $myFunc: Begin\n"	if ($DEBUG);

	my $outLevel	= shift;
	my $string		= shift;
	my $fileHandle	= shift;
	my $truncate	= shift;

	if ($logLevel lt $outLevel) {
		$return			= NUMBER_ZERO;
	} else {
		$levelName		= getLevelName($outLevel);	# In liberr.pl
	}

	# Select the $logHandle by default if it exists
	select $logHandle	if ($logHandle);

	while (not defined $return) { 
		select $fileHandle	if ($fileHandle);
		$string		= "[$levelName] $string"	if ($outLevel eq LVL_DEBUG());
		print "$string";
		$return			= $outLevel;
	}

	warn "$debugPrepend \$return=$return\n"	if ($DEBUG);
	warn "$debugPrepend $myFunc: End\n"		if ($DEBUG);
	select STDOUT;
	return $return;
}

return 1;
