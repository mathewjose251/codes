#!/opt/bizintel/perl/bin/perl -w
############################
#	http://bz.brightmail.com/show_bug.cgi?id=39172
############################
#	The following should cover the info needed to generate monitoring.  Looking at
#	the timestamps of the files, they are all created around the 54 or 55 minute
#	after the hour.  So checking on the hour for the previous hour should work ok. 
#	You could always check 10 min after the hour if you wanted to be super safe.
#	
#	Given a date and time of we run a cron monitoring job to check the previous
#	hour of:
#	
#	    2009/12/08 23:00
#	
#	We would then want to check if the previous hour file is there, ie for the
#	previous hour file date/time value:
#	
#	    2009/12/08 22:00
#	
#	There should be a file on the biz-ops01.tuc.brightmail.com box under the
#	directory in the path with that date such as:
#	
#	    -rw-r--r--    1 mailwall bmi      48159829 Dec  8 22:54
#	/var/lib/bizintel/data/cv_reports/cv_sent/2009/1208/cv_sent_msgs_mark_up-20091208.2200
#	
#	The filename for the target previous hour you are looking for can be thought of
#	using the format:
#	
#	    YYYY/MM/DD hh:00
#	
#	The minutes are always 00 on the files, so we can just use 00 for the minutes.
#	
#	So for any given hour, the syntax for the file from the previous hour date/time
#	would be:
#	
#	   
#	/var/lib/bizintel/data/cv_reports/cv_sent/YYYY/MMDD/cv_sent_msgs_mark_up-YYYYMMDD.hh00
#	
#	There are perl date/time subroutines which can give you the previous hour
#	format, so that should make it easy to get the expected file format.
#	
#	Is this enough info, or do you need a script from me to give you the filename
#	that should be there/do the check if it is there, etc?
#	
#	------- Comment #1 From Joe Krug 2009-12-16 09:12:59 PST [reply] -------
#	
#	Script output something like:
#	
#	If successful output something like:
#	    LAST-HOUR OK: <some text>
#	
#	and if it fails, then output something like:
#	    LAST-HOUR CRITICAL: <some text>
#	
#	and <some text> should be the filename in question.
#	
#	############################
############################
# v1.0 10/15/2009 joe tried to make this a script vs a crontab entry
############################

use strict;
use Data::Dumper;
use Date::Calc qw(:all);
use lib '/opt/bizintel/lib';
use Bizint::Utils::cv_Common;
use Bizint::Utils::Date;
use Bizint::Utils::Logs;
#use Bizint::Utils::Timer;

#set up the script debug level
my $DEBUG=0;
my $MSG2PRINT = '';

# set up the init hash
my %cvconfig=();
my $configfile="/opt/bizintel/etc/config_cv.pl";

my $cv_config=load_cv_config( { 'configfile' => "$configfile", 'DEBUG' => "$DEBUG" } );
my ($init_ref, $cc_ref)=init_setup( { 'programname' => "cv_monitor_spool.pl", 'configfile' => "$cv_config", 'DEBUG' => "$DEBUG" } );

# set some variables based on what came back
my $name         = $init_ref->{'name'};
my $RUNTIME      = $init_ref->{'RUNTIME'};
#set up debug based on the value from this script and the config file
$DEBUG           = $init_ref->{'DEBUG'};
my $hostname     = $init_ref->{'hostname'};
my $username     = $init_ref->{'username'};
my $user_homedir = $init_ref->{'user_homedir'};
my $LIBDEBUG=$DEBUG;
my $LIBNAME=$name;

%cvconfig=%{$cc_ref};

########################################################
# directories on current box
#	/home/cv_reports
#	[jkrug@biz-ops01 cv_reports]$ l | grep "^d" | awk '{print $9}' | grep "[a-z]" | xargs -i du -sk {}
#	4       8160_stats
#	1616    cv_issues_Oct2007
#	327232  cv_mail
#	4       cv_reports
#	8       cv_sbas_stats
#	19691316        cv_sent
#	692     cv_stored_reports
#	106376  cv_stored_stats
#	8888    cv_tt_stats
#	314784  cv_user_counts
#	3640    mailwall_stuff
##
# Move under a base path:   /var/lib/bizintel/data/cv_reports  
#	/var/lib/bizintel/data/cv_reports/
#	/var/lib/bizintel/data/cv_reports/8160_stats
#	/var/lib/bizintel/data/cv_reports/cv_issues_Oct2007
#	/var/lib/bizintel/data/cv_reports/cv_mail
#	/var/lib/bizintel/data/cv_reports/cv_reports
#	/var/lib/bizintel/data/cv_reports/cv_sbas_stats
#	/var/lib/bizintel/data/cv_reports/cv_sent
#	/var/lib/bizintel/data/cv_reports/cv_stored_reports
#	/var/lib/bizintel/data/cv_reports/cv_stored_stats
#	/var/lib/bizintel/data/cv_reports/cv_tt_stats
#	/var/lib/bizintel/data/cv_reports/cv_user_counts
#	/var/lib/bizintel/data/cv_reports/mailwall_stuff
#	
########################################################
#$cvconfig{'var'}{'data_basedir'}="/var/lib/bizintel/data/cv_reports";
#$cvconfig{'var'}{'cv_sent'}="$cvconfig{'var'}{'data_basedir'}/cv_sent";
my $sent_dir = $cvconfig{'var'}{'cv_sent'};

my ($newtime,@junkdate)=get_cur_time();
$MSG2PRINT = "# Starting $name run: $hostname.$newtime";
write_syslog( { 'name'=>"$name", 'loglevel'=>"INFO", 'message'=>"$MSG2PRINT" } );
#`touch /var/run/$name.start`;

my $time = time(); #to get current time
my ($yr,$mth,$dy,$hh,$mm,$ss)=epoch_to_mysql_date($time);       
my $time4run = "$mth/$dy/$yr $hh:$mm:$ss";
print "($yr,$mth,$dy,$hh,$mm,$ss)\n" if ($DEBUG);

#get last hour
$time = time() - 60*60; #to get last hour
($yr,$mth,$dy,$hh,$mm,$ss)=epoch_to_mysql_date($time);       
my $time4lasthourfile = "$mth/$dy/$yr $hh:00";
print "($yr,$mth,$dy,$hh,$mm,$ss)\n" if ($DEBUG);
# log the times
$MSG2PRINT = "# Time to do run: $time4run, check for spool from time = $time4lasthourfile ";
write_syslog( { 'name'=>"$name", 'loglevel'=>"INFO", 'message'=>"$MSG2PRINT" } );

#       
#       There should be a file on the biz-ops01.tuc.brightmail.com box under the
#       directory in the path with that date such as:
#       
#           -rw-r--r--    1 mailwall bmi      48159829 Dec  8 22:54
#       /var/lib/bizintel/data/cv_reports/cv_sent/2009/1208/cv_sent_msgs_mark_up-20091208.2200

my $targetfile = "$sent_dir/$yr/$mth$dy/cv_sent_msgs_mark_up-$yr$mth$dy.$hh" . "00";
$MSG2PRINT = "# targetfile = $targetfile";
write_syslog( { 'name'=>"$name", 'loglevel'=>"INFO", 'message'=>"$MSG2PRINT" } );

#       If successful output something like:
#           LAST-HOUR OK: <some text>
#       
#       and if it fails, then output something like:
#           LAST-HOUR CRITICAL: <some text>
if (-s $targetfile ) {
	$MSG2PRINT = "LAST-HOUR OK: $targetfile";
} else {
	$MSG2PRINT = "LAST-HOUR CRITICAL: $targetfile";
}
print "$MSG2PRINT\n";
write_syslog( { 'name'=>"$name", 'loglevel'=>"INFO", 'message'=>"$MSG2PRINT" } );

($newtime,@junkdate)=get_cur_time();
$MSG2PRINT = "# End $name run: $hostname.$newtime";
write_syslog( { 'name'=>"$name", 'loglevel'=>"INFO", 'message'=>"$MSG2PRINT" } );
#`touch /var/run/$name.end`;

#End main program

