#!/opt/blocperl/bin/perl

use strict;
use warnings;

BEGIN {
    require '/space/orabloc/server/conf/inc.pl';  
}

my $offset = $ARGV[0] || 60;

my ( $status, $smsg, $msg, @errors );
eval {
    use BLOC::Constants;
    use BLOC::Rule;
    use BLOC::RulePropLatency;
    use BLOC::RulePropLatency::Config;
    use BLOC::RulePropLatency::Finder;

    POLICY:
    for my $pol (
        sort { $a->id <=> $b->id } BLOC::RulePropLatency::Config->retrieve_multiple
    ) {
        my $time = time;

        my @rpl_recs =
            BLOC::RulePropLatency->retrieve_multiple(
                rule_type                => $pol->rule_type,
                ruleset                  => $pol->ruleset_path,
                rule_prop_time_is_null   => 1,
                rule_creation_time_lt    => $time - ( 2 * $pol->latency_threshold ),
            );

        push @rpl_recs,
            BLOC::RulePropLatency->retrieve_multiple(
                rule_type                => $pol->rule_type,
                ruleset                  => $pol->ruleset_path,
                rule_propagation_time_gt => $time - $offset,
                rule_creation_time_lt    => $time - $offset - $pol->latency_threshold,
            );

        for my $rec ( @rpl_recs ) {
            my ( $create_tm, $prop_tm )
                = ( $rec->rule_creation_time, $rec->rule_propagation_time );

            my $latency = $prop_tm ? $prop_tm - $create_tm
                        :            $time - $create_tm
                        ;

            push @errors, {
                path        => $pol->ruleset_path,
                r_type      => rule_type_as_string( $pol->rule_type ),
                rs_type     => $pol->ruleset_format,
                latency     => $latency,
                rule_id     => $rec->rule_id,
                dc          => $rec->data_center,
            };
        }
    }
};

if ( my $err = $@ ) {
    $status = 2;
    $smsg = 'CRITICAL';
    $msg = sprintf 'Critical error: %s', $err;
}
elsif ( @errors ) {
    $status = 2;
    $smsg = 'CRITICAL';
    $msg = sprintf 'High rule prop latency detected: %s',
        join q{, }, map {
            sprintf "%s_%s_%s_%s:%dsec (rid=%d)",
                $_->{dc}, $_->{rs_type}, $_->{r_type}, $_->{path},
                $_->{latency}, $_->{rule_id}
        } @errors;
}
else {
    $status = 0;
    $smsg = 'OK';
    $msg = 'No rulesets seeing abnormal rule propagation latency';
}

my $output = sprintf "%s: %s", $smsg, $msg;

#
# The following NAGIOS exit values pertain to their status
#
# 0 OK
# 1 WARNING
# 2 CRITICAL
# 3 UNKNOWN

print $output, "\n";
exit $status;

# factored this out because it just takes up too much space on a line
sub rule_type_as_string {
    return BLOC::Rule->type_as_string( shift );
}

