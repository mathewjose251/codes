#!/usr/bin/env perl

use strict;
use warnings;

use Frontier::Client;
use File::Basename qw(basename);
use Data::Dumper;
use Getopt::Long;
use Pod::Usage;
use URI;

use constant DEFAULT_PORT   => 5555;
use constant DEFAULT_REQ    => "jobs_running";

##
## These are const values for nagios status lines
use constant OK             => [0, "OK"];
use constant WARN           => [1, "WARNING"];
use constant CRIT           => [2, "CRITICAL"];
use constant UNKN           => [3, "UNKNOWN"];

my ($debug, $help, $server, $port, $request, $warn, $jobhost);

sub construct_url {
    my $uri = URI->new;
    $uri->scheme("http");
    $uri->port($port);
    $uri->host($server);
    $uri->path("/RPC2");
    return $uri->canonical->as_string;
}

##
## I'm not using BLOC::Logs::get_ident since the
## nagios setup might be on a host that doesn't have
## the BLOC libraries installed.
sub service_name {
    my $name =  shift || $0;
    $name    =  basename($name);
    $name    =~ s/\.[^.]*$//;
    return uc($name);
}

## -- MAIN -- ##
MAIN: {
    my ( $exitval, $exitstr, $srv, $req, %cargs );

    $|++;

    GetOptions(
        "debug|d"       =>  \$debug,
        "help|h"        =>  \$help,
        "port|p=i"      =>  \$port,
        "warn|w=i"      =>  \$warn,
        "jobhost|j=s"   =>  \$jobhost,
    ) or ++$help;

    pod2usage({ -exitval => -1, -verbose => 1 })
        if ( $help || @ARGV < 1);

    $port  ||= DEFAULT_PORT;
    $server  = shift;
    $request = shift || DEFAULT_REQ;
    $cargs{oper} = $request;

    ##
    ## Yes, this is an undocumented feature, no I don't want
    ## to say why... (because I don't want it to be used actually)
    $cargs{hostname} = $jobhost if $jobhost;

    eval {
        $srv = Frontier::Client->new(url => construct_url());
        die "Could not communicate with bloc_status daemon\n"
            unless $srv;
        $req = $srv->call("job_health", %cargs);
    };

    if ($@) {
        my $err = as_nagios_str(CRIT->[1], $@);
        print STDOUT $err, "\n";
        exit(CRIT->[0]);
    }

    if ($request eq DEFAULT_REQ) {
        ($exitval, $exitstr) = evaluate_request($req);
    }
    else {
        $exitval = UNKN->[0];
        $exitstr = as_nagios_str(UNKN->[1],
            "No plugin support exists to interpret '$request' results");
    }

    print STDOUT $exitstr, "\n";
    print "Request response:\n",
        Data::Dumper->Dump([$req], ['*req']), "\n" if $debug;
    exit($exitval);

}

sub as_nagios_str {
    my ($status, $msg, @args) = @_;
    my ($text) = scalar @args ? sprintf($msg, @args) : $msg;
    1 while chomp $text;
    return service_name()
        . ' ' . $status
        . ": " . $text;
}

sub evaluate_request {
    my ($req) = shift || die "evaluate_request needs a request object\n";
    my ($exitval, $exitstr) = ( OK->[0], as_nagios_str(OK->[1], "Ok") );

    if (not ($req and ref($req) eq 'ARRAY')) {
        $exitval = CRIT->[0];
        $exitstr = as_nagios_str(
            CRIT->[1],
            "Failure communicating with bloc_status daemon"
        );
    }
    else {
        my ($exit_type, %msgs) = (OK);
        my %fail_types = (
            is_notrunning   => "Not running",
            is_diedalot     => "Dying a lot",
            is_execfail     => "Exec fails",
        );
        my %excep_types = (
            is_standby      => "(standby)",
            is_suspend      => "(suspended)",
        );

        for my $rq (@$req) {
            ##
            ## Check for warning levels first, since we might
            ## have CRIT message afterwards
            if (defined $warn) {
                if (($warn == 0 and $rq->{past_deadline})
                || not($rq->{is_reporting})
                || ($warn > 0 and $rq->{since_reported} > $warn)) {
                    $exit_type = WARN if $exit_type->[0] < WARN->[0];
                    $msgs{$rq->{job_name}} = "Not reporting";
                }
            }
            ##
            ## Next check for CRIT level messages since they override warnings
            if (my $fail = ( grep $rq->{$_}, keys %fail_types )[0]) {
                $msgs{$rq->{job_name}} = $rq->{is_reporting}
                    ? $fail_types{$fail} : "Not reporting";
                if (my $excep = ( grep $rq->{$_}, keys %excep_types )[0]) {
                    $msgs{$rq->{job_name}} .= $excep_types{$excep};
                }
                ##
                ## Only set a CRITICAL level if no exceptions occured for job
                else {
                    $exit_type = CRIT;
                }
            }
            else {
                ##
                ## Default to an Ok status, if no other status given
                $msgs{$rq->{job_name}} = "Ok"
                    unless exists $msgs{$rq->{job_name}};
            }
        }

        $exitval = $exit_type->[0];
        $exitstr = as_nagios_str(
            $exit_type->[1],
            join(', ', map { $_ . ":" . $msgs{$_} } keys %msgs),
        );
    }

    return wantarray ? ( $exitval, $exitstr ) : $exitstr;
}

__END__

=pod

=head1 NAME

check_blocstatus - Invoke a jobs' status client request to bloc_status

=head1 SYNOPSIS

check_blocstatus [-hd] [--warn=secs] [--port=port] host [request]

=head1 OPTIONS

The C<-h> argument prints the POD help page; the C<-d> argument outputs
debugging content regarding the response from the F<bloc_status> server.

The C<--port> switch overrides the default port number which is B<5555>.
If the request parameter is omitted the default "jobs_running" is used.
The request B<all_jobs_running> is also valid.

The C<--warn> flag states how many seconds must have transpired since
the last reporting time in order for a WARNING level report to be
generated.  Note that a CRITICAL message status will override this.

If you assign the C<--warn> argument the value C<0>, check_blocstatus
will generate a warning if the I<BLOC idea> for expected deadline
transpired.  The method used for computing this is the job's last
report time, plus two times the seconds between expected job
reporting periods.

No warnings are generated for the last reporting time if the C<--warn>
switch is omitted.

=head1 DESCRIPTION

This is a nagios plugin that outputs the status of all jobs running
on the server specified by the host address.  The F<bloc_status> 
daemon must be running on the named host.

This is meant to be invoked and interpreted by nagios (although
it's fine to run from a command-line as well).

=head1 RCS

    $Id: check_blocstatus.pl,v 1.1 2018/10/30 10:12:01 mathew Exp $
    $Name:  $

=cut
