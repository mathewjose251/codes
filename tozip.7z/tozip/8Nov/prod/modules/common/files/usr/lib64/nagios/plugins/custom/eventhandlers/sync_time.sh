#!/bin/bash
# 
# $Id: sync_time.sh,v 1.1 2018/10/30 10:12:04 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/eventhandlers/sync_time.sh,v $
#
# Program       : sync-time.sh
# Author        : Sean Heshmati 6/2005
# Description   : This script is called by the eh-sync-time eventhandler
#

NTPDATE="/usr/sbin/ntpdate"
# this is old names of ns servers 
SERVERS="ns01 ns02 ns03"

# leave sfo backward compatibility
hostname | grep '\.[a-z]' > /dev/null
if [ $? -eq 0 ];then
  SERVERS="dns01 dns02 dns03"
fi

if [ -e /usr/bin/sudo ]
then
        SUDO=/usr/bin/sudo
else
        SUDO=/usr/local/bin/sudo
fi


MSG=`$SUDO $NTPDATE -b -u $SERVERS 2>&1`

echo "$MSG"
exit 0

