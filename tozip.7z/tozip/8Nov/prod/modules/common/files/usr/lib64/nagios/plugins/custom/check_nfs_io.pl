#!/usr/bin/perl -w

use strict;
use Getopt::Long;
use File::Basename;
use vars qw($PROGNAME $VERSION);
use lib "/usr/nagios/libexec";
use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS);

$PROGNAME = basename($0);
$VERSION = '$Revision: 1.1 $';
$ENV{LC_ALL} = 'POSIX';

use vars
 qw($opt_d $opt_f $ccrit $cwarn);
my ($now, $wstarttime, $wendtime, $wtime, $rstarttime, $rendtime, $rtime);;

Getopt::Long::Configure('bundling');
GetOptions(
   "d=s@"   => \$opt_d,
   "f=s@"   => \$opt_f,
   "c=s"    => \$ccrit,
   "w=s"    => \$cwarn,
);

$now = (time);

# set default values
$opt_d = "/var/lib/bizintel/nfs-check-io" if ( !$opt_d );
$opt_f = "testfile" if ( !$opt_f );
$ccrit = "30" if ( !$ccrit );
$cwarn = "15" if ( !$cwarn );

$opt_d = "$opt_d.$now";
$opt_f = "$opt_d/$opt_f.$now";

mkdir $opt_d;

# Write Starttime
$wstarttime = (time);
system( "dd if=/dev/zero of=$opt_f bs=16k count=16384 > /dev/null 2>&1");
# Write Endtime
$wendtime = (time);
$wtime = ($wendtime-$wstarttime);
# Read Starttime
$rstarttime = (time);
system( "dd if=$opt_f of=/dev/null bs=16k > /dev/null 2>&1");
# Read Endtime
$rendtime = (time);
$rtime = ($rendtime-$rstarttime);

if ( ($wtime >= $cwarn)||($rtime >= $cwarn) ) {
   if ( ($wtime >= $ccrit)||($rtime >= $ccrit) ) {
      print "NFS IO CRITICAL - Write Time = $wtime seconds, Read Time = $rtime seconds\n";
   }
   else {
      print "NFS IO WARNING - Write Time = $wtime seconds, Read Time = $rtime seconds\n";
   }
}
else {
   print "NFS IO OK - Write Time = $wtime seconds, Read Time = $rtime seconds\n";
}

#print "Removing $opt_d\n";
unlink $opt_f;
rmdir $opt_d;
