#!/usr/bin/perl

use strict;
use warnings;

use Getopt::Long;
use Pod::Usage;
use File::Basename;

use constant MILTER_BCC_SERVICE_SCRIPT => "/etc/rc.d/init.d/milter-bcc";

=pod

=head1 NAME

check_milter-bcc.pl - A nagios plugin to do just what it sounds like, check milter-bcc

=head1 SYNOPSIS

check_milter-bcc.pl

=head1 DESCRIPTION

No command line arguments exist at this time.

The script relies on the existance of the file F</etc/rc.d/init.d/milter-bcc>.

=cut

##
## These are const values for nagios status lines
use constant OK   => [ 0, "OK" ];
use constant WARN => [ 1, "WARNING" ];
use constant CRIT => [ 2, "CRITICAL" ];
use constant UNKN => [ 3, "UNKNOWN" ];

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub evaluate_request {
    my ( $status ) = @_;
    ##
    ## Setup the default exit values
    my ( $exitval, $exitstr ) = ( OK->[0], as_nagios_str( OK->[1], "Ok - milter-bcc running" ) );

    ##
    ## Look at the response from the health check, whatever it is
    ##
    unless ($status) {
        $exitval = CRIT->[0];
	$exitstr = as_nagios_str( CRIT->[1], "milter-bcc not running");
    }

    return ( $exitval, $exitstr );
}

MAIN: {
    my ( $exitval, $exitstr, $help );

    $|++;

    GetOptions(
        "help|h"        => \$help,
    ) or ++$help;

    pod2usage( { -exitval => -1, -verbose => 1 } )
      if ( $help );

    ##
    ## Perform basic sanity check
    ##
    if ( -x MILTER_BCC_SERVICE_SCRIPT ) {
        ##
        ## Perform service checks here
        ##
        my $status = check_milter_bcc();

        ##
        ## Evaluate the response from the service check here
        ##
        ( $exitval, $exitstr ) = evaluate_request( $status );
    }
    else {
	$exitval = WARN->[0];
        $exitstr = as_nagios_str( WARN->[1], "Could not find milter-bcc init.d script" );
    }
    print STDOUT $exitstr, "\n";
    exit($exitval);
}

sub check_milter_bcc {
    my $cmd = sprintf('%s status', MILTER_BCC_SERVICE_SCRIPT);
    my $out = qx($cmd 2>&1);

    chomp($out);
    my ( $pid ) = ( $out =~ /^milter-bcc:(\S+)$/ms );
    return ( $pid =~ /^\d+$/ );
}
