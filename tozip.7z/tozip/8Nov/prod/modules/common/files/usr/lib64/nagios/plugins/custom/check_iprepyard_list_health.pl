#!/usr/bin/perl -w
# $Id: check_iprepyard_list_health.pl,v 1.1 2018/10/30 10:12:01 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/check_iprepyard_list_health.pl,v $
#
# Program       : IPRepyard list health check
# Author        : Sean Heshmati 2/2009
# Description   : This plugin checks iprepyard list health and alerts on the
#                 the following conditions:
#
#                 * Latest SAN file is specified number of seconds newer
#                   than FS version of list (-d)
#                 * FS list is older than specified number of secconds (-m)
#                 * FS list is smaller than specified number of bytes (-s)
#                 * SAN list directory is empty
#                 * FS list is missing
#
use strict;
use File::Spec;
use File::stat;
use Getopt::Long;

use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS &print_revision &support);

my ( $opt_v, $opt_h, $opt_d, $opt_m, $opt_s, @mesg, $output );

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
my $REVISION   = $1;
my $PROGNAME   = "check_iprepyard_list_health";
my $exitstatus = $ERRORS{'UNKNOWN'};

my $dir_san = "/san/iprepyard/fs/lists/archive";
my $dir_fs  = "/var/iprepyard/fs";

# list types and corresponding location in $dir_fs
my %lists = (
    cas          => 'lists/cas',
    dakota       => 'dakota',
    opl          => 'lists/opl',
    pbl          => 'lists/pbl',
    safe         => 'lists/safe',
    sbl          => 'lists/sbl',
    smtp         => 'lists/smtp',
    top_senders  => 'top_senders',
    top_spammers => 'top_spammers',
    xbl          => 'lists/xbl',
    zodiac       => 'zodiac',
    zombie       => 'lists/zombie',
);

GetOptions(
    "v"               => \$opt_v,
    "version"         => \$opt_v,
    "h"               => \$opt_h,
    "help"            => \$opt_h,
    "d=i"             => \$opt_d,
    "age-diff-crit=i" => \$opt_d,
    "m=i"             => \$opt_m,
    "max-age-crit=i"  => \$opt_m,
    "s=i"             => \$opt_s,
    "min-list-size=i" => \$opt_s,
);

# process options
if ($opt_v) {
    print_revision( $PROGNAME, $REVISION );
    exit $ERRORS{'OK'};
}
elsif ($opt_h) {
    print_help();
    exit $ERRORS{'OK'};
}

unless ( $opt_d && $opt_m && defined($opt_s) ) {
    print_help();
    exit $ERRORS{'UNKNOWN'};
}

# process each list type
for my $list ( sort keys %lists ) {
    get_file_info($list);
}

# compose check output
if (@mesg) {
    for my $status ( keys %ERRORS ) {
        $output = "$status - " if $ERRORS{$status} == $exitstatus;
        last if $output;
    }
    $output .= join( ", ", @mesg );
}
else {
    $output     = "OK - All lists are in good health";
    $exitstatus = $ERRORS{'OK'};
}

# print final message and exit with proper status
print "$output\n";
exit $exitstatus;

##############################################################################

sub get_file_info {
    my $list = shift;
    my ( $newest, $newest_time );

    # for this list type, get a list of files in san directory
    my $files_san = File::Spec->catfile( $dir_san, $list, "$list.*" );

    # find the newest san file
    for my $file_san ( glob $files_san ) {
        my $stat_san = ( stat $file_san );
        if ( !$newest_time || $stat_san->mtime > $newest_time ) {
            $newest      = $file_san;
            $newest_time = $stat_san->mtime;
        }
    }

    # make sure the directory was not empty
    if ( $newest and $newest_time ) {

        my $file_fs = File::Spec->catfile( $dir_fs, $lists{$list} );

        if ( -f $file_fs ) {

            # get file timestamp in fs directory
            my $stat_fs = ( stat $file_fs );

            # get age diff between san and fs file
            my $time_diff = $newest_time - $stat_fs->mtime;

            # get fs file age
            my $age_fs = ( time - $stat_fs->mtime );

          # alert if time difference between san and fs file exceeds threshold
            if ( $time_diff >= $opt_d ) {
                push( @mesg,
                    "$file_fs is $time_diff seconds older than $newest" );
                $exitstatus = $ERRORS{'CRITICAL'};
            }

            # alert if fs file age exceeds threshold
            elsif ( $age_fs >= $opt_m ) {
                push( @mesg, "$file_fs is $age_fs seconds old" );
                $exitstatus = $ERRORS{'CRITICAL'};
            }

            # alert if fs file size is too small
            if ( $stat_fs->size <= $opt_s ) {
                push( @mesg, "$file_fs is smaller than $opt_s bytes" );
                $exitstatus = $ERRORS{'CRITICAL'};
            }
        }

        # fs file is missing
        else {
            push( @mesg, "$file_fs does not exist!" );
            $exitstatus = $ERRORS{'CRITICAL'};
        }
    }

    # if we get here the san directory did not contain any files or is missing
    else {
        push( @mesg,
            File::Spec->catfile( $dir_san, $list )
              . " is empty or missing!" );
        $exitstatus = $ERRORS{'CRITICAL'};
    }
}

sub print_help {
    print_revision( $PROGNAME, $REVISION );
    print "\nUsage:\n";
    print "  $PROGNAME <-d time_diff> <-m max_list_age> <-s min_list_size>\n";
    print "  $PROGNAME [-h | --help]\n";
    print "  $PROGNAME [-v | --version]\n";
    print "\nOptions:\n";
    print "  -d time_diff\n";
    print "     Maximum number of seconds a fs list can be behind the san\n";
    print "     version of the list.\n\n";
    print "  -m max_list_age\n";
    print "     Maximum age of fs list in seconds.\n\n";
    print "  -s min_list_size\n";
    print "     Minimum fs list size in bytes.\n";
    print "\n";
}

