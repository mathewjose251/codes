#!/usr/bin/perl

use strict;
use warnings;

use Getopt::Long;
use Pod::Usage;
use File::Basename qw(basename);
use IO::Handle;

=pod

=head1 NAME

check_svm.pl - Nagios check for SUN Volume Manager disks

=head1 SYNOPSIS

check_svm.pl [--help]

=head1 DESCRIPTION

This nagios check examines each disk partition by invoking the metastat(1M) command.  For each disk
that is a type "Mirror" it checks the sub-mirrors and their states.

This script does not require any command line arguments at this time.

=cut

##
## These are const values for nagios status lines
use constant OK   => [ 0, "OK" ];
use constant WARN => [ 1, "WARNING" ];
use constant CRIT => [ 2, "CRITICAL" ];
use constant UNKN => [ 3, "UNKNOWN" ];

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub nagios_bail {
    my ( $exitval, $exitstr ) = @_;
    print STDOUT $exitstr, "\n";
    STDOUT->flush();
    exit($exitval);
}

sub nagios_die {
    my ($msg) = @_;
    1 while chomp($msg);
    nagios_bail( UNKN->[0], as_nagios_str( UNKN->[1], $msg, ) );
    ## NORETURN ##
}

sub read_metadata {
    my ( $md_ref ) = @_;
    return unless ( $md_ref && ref( $md_ref ) eq 'HASH' );

    my $metastat = "/usr/sbin/metastat";
    nagios_die("Could not run the metastat [$metastat] command.")
        unless ( -x $metastat );

    my @metastat = qx( $metastat );
    chomp(@metastat);

    my $curr_disk = undef();
    my $submirror = undef();

    ENTRY: for my $line (@metastat) {
        ##
        ## Skip blank or commented lines
        ##
        next ENTRY if ( $line =~ /^\s*$|^\s*#/ );

        ##
        ## This parses out the disk and disk-type line
        ##
        if ( $line =~ /^(d\d+):\s+(\S+)/ ) {
            my $curr_type = uc($2);
            ##
            ## If we're parsing out a "SUBMIRROR" type our State attributes will
            ## already be included in the parent Mirror defnitiion -- there's
            ## no need to duplicate the effort by parsing both out.  So we will
            ## check for SUBMIRROR type, and if so effectively skip the rest
            ## of this stanza by unsetting the variable '$curr_disk' (which
            ## will short-circuit parsing the rest of this disk definition.)
            ##
            if ( $curr_type eq 'SUBMIRROR' ) {
                $curr_disk = undef();
                next ENTRY;
            }
            $curr_disk = $1;
            $md_ref->{$curr_disk}->{type} = $curr_type;
        }
        ##
        ## Skip any further parsing if we're not working on a disk partition
        ##
        next ENTRY unless ( $curr_disk );
        ##
        ## If a submirror, place it under the disk in our data structure..
        ##
        if ( $line =~ /^\s+Submirror\s+\d+:\s+(\S+)/ ) {
            $submirror = $1;
            $md_ref->{$curr_disk}->{subs}->{$submirror} = undef();
            next ENTRY;           
        }
        if ( $line =~ /^\s+State:\s+(\S+)/ ) {
            ##
            ## We've parsed out a "State" attribute, check whether it pertains to
            ## a submirror or some other device and place it in the data structure
            ## at the appropriate node..
            ##
            if ( $submirror ) {
                $md_ref->{$curr_disk}->{subs}->{$submirror} = uc($1);
                $submirror = undef();       
            }
            else {
                $md_ref->{$curr_disk}->{state} = uc($1);
            }
            next ENTRY;
        }
        ##
        ## Currently all other metastat attributes are ignored and fall through here
        ##
    }

    return;
}

sub check_state {
    my ($disk, $state, $c_msgs, $w_msgs) = @_;

    ##
    ## We can't simply return because that's implicitly an OK status
    ##
    nagios_die("check_state: called without a disk and state argument")
        unless ( $disk && $state );

    ##
    ## Okay check
    ##
    return if ( $state =~ /^(?:okay|dbase)$/i );

    ##
    ## Resync check is a WARNING
    ##
    if ( $state =~ /^resync/i ) {
        push @$w_msgs, sprintf( "Disk %s in RESYNC state", $disk );
        return;
    }

    ##
    ## Any other state is a CRITICAL
    ##
    push @$c_msgs, sprintf( "Disk %s in state [%s]", $disk, $state );
    return;
}

sub eval_disks {
    my ( $md_ref ) = @_;

    ##
    ## Setup the default exit values
    my ( $exitval, $exitstr ) = ( OK, as_nagios_str(
        OK->[1],
        sprintf( "All volumes [%s] report normal states", join(', ' => keys %$md_ref))
    ) );

    ##
    ## Populate a "warning" and "critical" messages array...
    ##
    my (@c_msgs, @w_msgs);
    for my $disk ( keys %{ $md_ref } ) {
        my ( $subs, $type ) = @{ $md_ref->{$disk}}{qw(subs type)};
        ##
        ## Check a disk type of 'MIRROR' and any submirrors
        ##
        if ( $type eq 'MIRROR' ) {
            my $n_subs = scalar(keys %$subs);
            if ($n_subs < 2) {
                ##
                ## I'm using "unshift" instead of "push" because I like the
                ## "missing submirrors" errors to appear at the beginning of the 
                ## critical message.
                ##
                unshift @c_msgs, sprintf(
                    'Disk %s missing submirrors %s',
                    $disk,
                    ( $n_subs < 1 )
                        ?   "[0 submirrors]"
                        :   sprintf( q{[current=%s]} => join(', ' => keys %$subs) )
                );
            }
            for my $sub (keys %$subs) {
                check_state($sub, $subs->{$sub}, \@c_msgs, \@w_msgs);
            }
        }
        else {
            ##
            ## Not a disk type of 'MIRROR', might be another type.  If it has a State attribute
            ## check it and alert on it.
            ##
            if ( exists $md_ref->{$disk}->{state} ) {
                check_state($disk, $md_ref->{$disk}->{state}, \@c_msgs, \@w_msgs);
            }
        }
    }
    ##
    ## Order is important, do warning check first... then overwrite if critical.
    ##
    my $msgstr = undef();
    if (@w_msgs) {
        $exitval = WARN;
        $msgstr  = join('; ' => @w_msgs);
    }
    if (@c_msgs) {
        $exitval = CRIT;
        $msgstr  = join('; ' => @c_msgs, @w_msgs);
    }

    ##
    ## Only set it if we constructed a new message, otherwise it
    ## takes the default we set at the beginning of the function.
    ##
    $exitstr = as_nagios_str( $exitval->[1], $msgstr )
        if $msgstr;

    return ( $exitval->[0], $exitstr );
}

MAIN: {
    my ( $exitval, $exitstr, $help, %metadata );

    $|++;

    GetOptions( "help|h" => \$help ) or ++$help;
    pod2usage( { -exitval => -1, -verbose => 1 } )
      if ( $help );

    ##
    ## Run metastat(1M) and parse its output..
    ##
    read_metadata(\%metadata);

    ##
    ## Evaluate the response from the service check here
    ##
    ( $exitval, $exitstr ) = eval_disks(\%metadata);

    print STDOUT $exitstr, "\n";
    exit($exitval);
}

