#!/bin/bash
# 
# $Id: start_sendmail.sh,v 1.1 2018/10/30 10:12:01 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/eventhandlers/start_sendmail.sh,v $
#
# Program       : start-sendmail.sh
# Description   : This script is called by the eh-start_sendmail eventhandler via NRPE
#

CMD="/usr/local/tools/bin/restart_sendmail"
TAIL="/usr/bin/tail"

if [ -e /usr/bin/sudo ]
then
	SUDO=/usr/bin/sudo
else
	SUDO=/usr/local/bin/sudo
fi


MSG=`$SUDO $CMD | $TAIL -1`

echo "$MSG"
exit 0
