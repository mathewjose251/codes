#!/usr/bin/perl

=pod

=head1 NAME

check_iprep_timeliness.pl - Check IPRepyard files built on the primary, master node.

=head1 SYNOPSIS

check_iprep_timeliness.pl [-hE<verbar>--help] [-aE<verbar>--age=seconds] [-dE<verbar>--dir=/path/to/lists] [filename[, ...]]

=head1 DESCRIPTION

This script ensures that files and lists that should be built on primary nodes are timely and not empty.

=head1 OPTIONS

The B<--age> parameter specifies the minimum age (in seconds) of the given lists before a critical
alert is thrown.

The B<--dir> parameter specifies an alternate path to check for lists -- this overrides the default
SAN path hardcoded into this script.

Any files specified on the command line override the internal list of lists checked by this script.

=cut

use strict;
use warnings;

use Getopt::Long;
use Pod::Usage;
use File::Spec::Functions;
use File::Basename qw(basename);
use Sys::Hostname;

use lib "/opt/iprepyard/lib";

##
## These are const values for nagios status lines
use constant OK   => [ 0, "OK" ];
use constant WARN => [ 1, "WARNING" ];
use constant CRIT => [ 2, "CRITICAL" ];
use constant UNKN => [ 3, "UNKNOWN" ];

##
## Default age is 45 minutes
use constant DEFAULT_AGE    => 2700;

##
## Default directory is on the SAN
use constant DEFAULT_DIR    => '/san/iprepyard/fs/lists/state/';

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub eval_lists {
    my ($max_seconds, @files) = @_;

    ##
    ## Setup the default exit values
    my ( $exitval, $exitstr ) = ( OK->[0], as_nagios_str( OK->[1], "All lists are currently up-to-date" ) );

    my @crits = ();

    FILE: for my $file (@files) {
        unless ( -f $file ) {
            push @crits, sprintf("File '%s' is missing!", $file);
            next FILE;
        }
        my ($size, $mtime) = ( stat $file )[7, 9];
        if ($size < 200) {
            push @crits, sprintf("File '%s' has not been built with valid data", $file);
            next FILE;
        }
        my $now = time();
        if ( ( $now - $mtime ) >= $max_seconds ) {
            push @crits, sprintf("File '%s' is too old [%s seconds]", $file, ( $now - $mtime ));
            next FILE;
        }
    }

    if (@crits) {
        $exitval = CRIT->[0];
        $exitstr = as_nagios_str(
            CRIT->[1],
            join('; ' => @crits),
        );       
    }

    return ( $exitval, $exitstr );
}

MAIN: {
    my ( $exitval, $exitstr, $help, $warn, $crit );

    ##
    ## Maximum files/lists age in seconds
    my $opt_age;

    ##
    ## Where to look for the lists
    my $opt_dir;

    ##
    ## The files to check
    my @opt_files = qw( aries_hitandrun.rbldns aries_sips.rbldns );

    $|++;

    GetOptions(
        "help|h"        => \$help,
        "age|a=i"       => \$opt_age,
        "dir|d=s"       => \$opt_dir,
    ) or ++$help;

    @opt_files = @ARGV
        if @ARGV;

    pod2usage( { -exitval => -1, -verbose => 1 } )
      if ( $help );

    ##
    ## Assign defaults if no arguments given
    $opt_dir ||= DEFAULT_DIR;
    $opt_age ||= DEFAULT_AGE;

    my ($i_am_primary, $i_am_master);
    eval {
        require IPRepyard::Config;
        require IPRepyard::Site;
        my $config    = IPRepyard::Config->new();
        $i_am_primary = IPRepyard::Site->i_am_the_primary_site($config);
        $i_am_master  = IPRepyard::Site->i_am_the_master($config);
    };

    my $is_a_ipryd   = ( (!( $@ && $@ =~ /Can't locate/ )) || hostname() =~ /^wl-ipryd/i );

    if ($i_am_primary && $i_am_master && $is_a_ipryd) {
        ##
        ## absolutify the paths...
        @opt_files = map { catfile($opt_dir, $_) } @opt_files;

        ##
        ## Evaluate the response from the service check here
        ##
        ( $exitval, $exitstr ) = eval_lists( $opt_age, @opt_files );
    }
    else {
        if ($is_a_ipryd) {
            $exitval = OK->[0];
            $exitstr = as_nagios_str( OK->[1], "I am not a master and primary, so no check is required" );
        }
        else {
            $exitval = UNKN->[0];
            $exitstr = as_nagios_str( UNKN->[1], "This check is meant to be run on an IPRepyard system" );
        }
    }

    print STDOUT $exitstr, "\n";
    exit($exitval);
}

