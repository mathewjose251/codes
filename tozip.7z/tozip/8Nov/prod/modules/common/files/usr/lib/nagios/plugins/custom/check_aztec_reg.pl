#!/usr/bin/perl -w
# $Id: check_aztec_reg.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $
#
# Does an HTTP GET request on /register?verify=1&license_key=a
# response from the server for /^ok$/.  If it matches, the
# return is 'OK'.  If not, the return is 'CRITICAL'.
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# you should have received a copy of the GNU General Public License
# along with this program (or with Nagios);  if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA

use strict;
use Getopt::Long;
use vars qw($PROGNAME);
use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS &print_revision &support);

sub print_help();
sub print_revision($$);

use vars qw($opt_H $opt_h $opt_V @files);
my ($PROGNAME,$textSep,$VERSION,$REVISION);

# Modules for this script
use LWP::UserAgent;
require HTTP::Request;

my ($request,$userAgent,$response,$uri,$exitStatus,$print);
my (@finalresult);

$exitStatus		= $ERRORS{'WARNING'};
$textSep		= ',';
$PROGNAME='check_aztec_reg.pl';

Getopt::Long::Configure('bundling');
GetOptions(
	"H:s"   => \$opt_H, "host:s"	=> \$opt_H,
	"V"   => \$opt_V, "version"	=> \$opt_V,
	"h"   => \$opt_h, "help"	=> \$opt_h);

if (!$opt_H)
{
	print_help();
	exit $ERRORS{'UNKNOWN'};
}

if ($opt_V) {
	print_revision($PROGNAME, '$Id: check_aztec_reg.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $');
	exit $ERRORS{'OK'};
}

if ($opt_h) {
	print_help();
	exit $ERRORS{'OK'};
}

# Grab the URI, exit if there is no URI
$uri		= "https://$opt_H/register?verify=1&license_key=a";

# Build the request
$request	= HTTP::Request->new(GET => $uri);

# Run the request through the user agent
$userAgent	= LWP::UserAgent->new;
$userAgent->agent('Nagios/1.0');

# Make the request and get the response
$response	= $userAgent->request($request);

# Parse the response and generate a report and exit status
$exitStatus	= $ERRORS{'CRITICAL'};
$exitStatus	= $ERRORS{'OK'}	if ($response->content =~ /^ok$/);

# Build the report string
foreach ( keys (%ERRORS) )
{
	chomp $_;
	$print		= "$_"	if ($ERRORS{$_} == $exitStatus);
}
$print		.= " - Aztec DB Verification.";
if ($exitStatus != $ERRORS{'OK'})
{	$print		.= "  Did not get expected result.";	}
else
{	$print		.= "  Got expected result.";			}

# Print the output and exit
print "$print\n";
exit $exitStatus;

# Fancy-shmancy subroutines for the whole family
sub print_usage () {
	print "Usage:\n";
	print "  $PROGNAME <-H | --host hostname>\n";
	print "  $PROGNAME [-h | --help]\n";
	print "  $PROGNAME [-V | --version]\n";
}

sub print_help () {
	print_revision($PROGNAME, '$Id: check_aztec_reg.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $');
	print "Copyright (c) 2003 Steven Grimm\n\n";
	print_usage();
	print "\n";
	print "  Does an HTTP GET request on /register?verify=1&license_key=a\n";
	print "  response from the server for /^ok\$/.  If it matches, the\n";
	print "  return is 'OK'.  If not, the return is 'CRITICAL'.\n";
	print "\n";
	support();
}
