#!/bin/bash
#
# $Id: check_mailwall.sh,v 1.1 2018/10/30 10:12:02 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/check_mailwall.sh,v $
#
# Program       : Mailwall plugin for Nagios
# Author        : Sean Heshmati 9/2005
# Description   : This plugin checks if mailwall processes are running.
#

. /usr/lib/nagios/plugins/utils.sh

PROGNAME=`/bin/basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1 $' | /bin/sed -e 's/[^0-9.]//g'`

print_usage() {
        echo "Usage:"
        echo " $0 "
        echo " $0 (-v | --version)"
        echo " $0 (-h | --help)"
}

print_help() {
    print_revision $PROGNAME $REVISION
    echo ""
    print_usage
    echo ""
    echo "This plugin checks if mailwall processes are running."
    echo ""
    support
}

exitstatus=$STATE_UNKNOWN

while test -n "$1"; do
    case "$1" in
        --help)
            print_help
            exit $STATE_OK
            ;;
        -h)
            print_help
            exit $STATE_OK
            ;;
        --version)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -V)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        *)
            echo "Unknown argument: $1"
            print_usage
            exit $STATE_UNKNOWN
            ;;
    esac
    shift
done

if [[ `uname -p` == "sparc" ]]
then
	procs="runner bmifilter bmserver"
	for proc in `echo $procs`
	do
		if [[ ! `ps -ef | grep $proc | grep -v grep` ]]
		then
			not_running="$not_running $proc"
		fi
	done
else
        procs="runner bmifilter conduit bmserver bmcleaner"
        HN=`uname -n`
        if echo "$HN" |grep -q "mx-av"
        then
	    procs="runner bmifilter jlu-controller bmserver bmcleaner"
        fi   
	for proc in `echo $procs`
	do
		if [[ ! `ps ho pid -C $proc` ]]
		then
			not_running="$not_running $proc"
		fi
	done
	
fi

# Finally Inform Nagios of what we found...
if [ "$not_running" ]
then
        echo "CRITICAL - $not_running not running!"
        exitstatus=$STATE_CRITICAL
else
        echo "OK - Mailwall processes are running"
        exitstatus=$STATE_OK
fi

exit $exitstatus

