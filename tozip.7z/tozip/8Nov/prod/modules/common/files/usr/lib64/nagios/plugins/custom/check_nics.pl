#!/usr/bin/perl
#
# Program       : Network Interface link speed and duplex check
# Author        : Brendan Harris 5/2005
# Description   : This plugin checks if the link speed and duplex of network
#					interfaces.
#
use strict;
use Getopt::Long;

use lib "/usr/lib/nagios/plugins";
use vars qw($PROGNAME $REVISION);
use utils qw (%ERRORS &print_revision &support);

my ($opt_s, $opt_d, $opt_V, $opt_h, $opt_i);
my ($exitstatus, $message, $sth);
my ($status,$myos,$sstatus,$dstatus,$ifacerpt,$prevstatus,$output,$iface,$key);
my (%speeds,%duplexmode,%osifs,%ifconfig,%option);
my (@interfaces,@finalresult);
use vars qw($realspeed $realduplex $nolink $DEBUG $sudo);
my $textsep	= ',';
my $speed	= 100;
my $loop	= 0;

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
$REVISION=$1;
$PROGNAME="check_av_status";
$exitstatus=$ERRORS{'UNKNOWN'};

Getopt::Long::Configure('bundling');
%option	= GetOptions(
    "V"   => \$opt_V, "version" => \$opt_V,
    "h"   => \$opt_h, "help"    => \$opt_h,
    "s=s"	=> \$opt_s, "speed=s"	=> \$opt_s,
    "d=s"	=> \$opt_d, "duplex=s"	=> \$opt_d,
    "i=s"	=> \$opt_i, "iface=s"	=> \$opt_i,
	"D"		=> sub { $DEBUG='[DEBUG]' },
	"debug"	=> sub { $DEBUG='[DEBUG]' });

$opt_d		= 'full'	if (! $opt_d);
@interfaces	= split(/,/,$opt_i)	if ($opt_i);

# If we're not root, we'll need to use sudo for a few things
$sudo		= 'sudo'	if ($ENV{'USER'} !~ /root/);

# Debug mode info
if ($DEBUG)
{
	warn "$DEBUG $0 Debug Mode Enabled\n";
	warn "$DEBUG Getopt::Long:\n";
	foreach (keys (%option) )
	{
		chomp;
		warn "$DEBUG -\toption $_ = $option{$_}\n";
	}
	warn "$DEBUG opt_d = $opt_d\n";
	warn "$DEBUG interfaces = @interfaces\n";
	warn "$DEBUG sudo = $sudo\n";
}

%speeds		= (
	"1000"		=> 1,
	"100"		=> 1,
	"10"		=> 1);

%duplexmode	= (
	"full"		=> 1,
	"half"		=> 1);

%osifs		= (
	"linux"		=> 'eth0 eth1 eth2 eth3',
	"solaris"	=> 'e1000g0 e1000g1 eri0 eri1 hme0 hme1 ce0 ce1');

%ifconfig	= (
	"linux"		=> '/sbin/ifconfig',
	"solaris"	=> '/usr/sbin/ifconfig');

if ($opt_s and ! $speeds{$opt_s})
{
	print "CRITICAL: \"$opt_s\" is not a supported link speed.\n";
	print_help();
	exit $ERRORS{'CRITICAL'};
}
if (! $duplexmode{$opt_d})
{
	print "CRITICAL: \"$opt_d\" is not a supported duplex mode.\n";
	print_help();
	exit $ERRORS{'CRITICAL'};
}

if ($opt_V)
{
    print_revision($PROGNAME, $REVISION);
    exit $ERRORS{'OK'};
}

if ($opt_h)
{
    print_help();
    exit $ERRORS{'OK'};
}


##################################################################
## Action

# Find out what OS we're on
$myos		= whichOS();
warn "$DEBUG operating system = $myos\n"	if ($DEBUG);

# Since solaris x86 is not currently support it, exit quietly if this
# is the case.  Remove the next 'if' block to support solaris x86.
if ($myos =~ /solaris/ and `uname -p` =~ /i386/)
{
	print "OK - Solaris x86 is not currently supported.  Exiting.\n";
	exit $ERRORS{'OK'};
}
# Make sure the OS is supported
if (! $ifconfig{$myos})
{
	print "OK - OS '$myos' is not supported by this script.  Exiting.\n";
	exit $ERRORS{'OK'};

# Make sure the ifconfig binary can be found and executed
} elsif (! -x "$ifconfig{$myos}")
{
	print "WARNING - Could not execute $ifconfig{$myos}.  Exiting.\n";
	exit $ERRORS{'WARNING'};
}

# Grab an interface and start the whole process
@interfaces	= split(/\s/, $osifs{$myos})	if (! @interfaces);
warn "$DEBUG interface list = @interfaces\n"	if ($DEBUG);
warn "$DEBUG Entering loop to process all interfaces\n"	if ($DEBUG);
foreach (@interfaces) {
	chomp;
	$iface		= "$_";
	$loop++	if ($DEBUG);
	warn "$DEBUG Beginning loop $loop\n"	if ($DEBUG);
	warn "$DEBUG previous status = $prevstatus\n"	if ($DEBUG);
	warn "$DEBUG new interface = $iface\n"	if ($DEBUG);
	undef $status;

	# Make sure the interface actually has an address
	$status		= checkIFStatus($iface,"$ifconfig{$myos}");
	if ($status gt 0)
	{
		warn "$DEBUG checkIFStatus came back $status for $iface\n"	if ($DEBUG);
		$exitstatus	= $ERRORS{'OK'}	if ($exitstatus != $ERRORS{'CRITICAL'});
		next;
	}

	# Undefine some of the globals/locals that we set before
	# which we use in this loop
	undef $realspeed;
	undef $realduplex;
	undef $ifacerpt;
	undef $status;

	if ($myos =~ /solaris/)
	{
		warn "$DEBUG calling readKstat for speed\n"	if ($DEBUG);
		$sstatus	= readKstat($iface,'speed');
		warn "$DEBUG return = $sstatus\n"	if ($DEBUG);
		warn "$DEBUG running readKstat for duplex\n"	if ($DEBUG);
		$dstatus	= readKstat($iface,'duplex');
		warn "$DEBUG return = $dstatus\n"	if ($DEBUG);
	} else
	{
		warn "$DEBUG calling checkLink for speed\n"	if ($DEBUG);
		$sstatus	= checkLink($myos,$iface,'speed');
		warn "$DEBUG return = $sstatus\n"	if ($DEBUG);
		warn "$DEBUG calling checkLink for duplex\n"	if ($DEBUG);
		$dstatus	= checkLink($myos,$iface,'duplex');
		warn "$DEBUG return = $dstatus\n"	if ($DEBUG);
	}
	$exitstatus	= $sstatus if ($exitstatus != $ERRORS{'CRITICAL'});
	$exitstatus	= $dstatus if ($exitstatus != $ERRORS{'CRITICAL'});

	# Skip this interface if it has no link and reset the exit status
	# to the exit status of the previous interface
	if ($nolink)
	{
		warn "$DEBUG $iface has no link\n"	if ($DEBUG);
		$exitstatus	= $ERRORS{'OK'}	if ($exitstatus != $ERRORS{'CRITICAL'});
		push(@finalresult,"$iface: No link$textsep");
		$prevstatus	= $exitstatus;
		undef $nolink;
		next;
	}
	# If $nosupport has a value, the driver is not supported
	if (! $realspeed or ! $realduplex)
	{
		warn "$DEBUG $iface driver has no support\n"	if ($DEBUG);
		$exitstatus	= $ERRORS{'OK'}	if ($exitstatus != $ERRORS{'CRITICAL'});
		push(@finalresult,"$iface: Driver not supported$textsep");
		$prevstatus	= $exitstatus;
		next;
	}

	# Make sure that what was matched is what we really want
	if ($opt_s and $realspeed)
	{
		$exitstatus	= $ERRORS{'CRITICAL'}	if ($realspeed != $opt_s);
	} else
	{
		$exitstatus	= $ERRORS{'CRITICAL'}	if ($realspeed lt $speed);
	}
	if ($opt_d and $realduplex)
	{
		$exitstatus	= $ERRORS{'CRITICAL'}	if ($realduplex !~ /$opt_d/);
	}

	if ($DEBUG)
	{
		warn "$DEBUG realspeed = $realspeed\n";
		warn "$DEBUG realduplex = $realduplex\n";
	}

	$prevstatus	= $exitstatus;
	warn "$DEBUG exit status = $exitstatus\n"	if ($DEBUG);

	$ifacerpt	.= "$iface: $realspeed\MBit $realduplex$textsep";
	push(@finalresult,"$ifacerpt")	if ($ifacerpt);
}

# Add the exit status name to the beginning of the array
for (keys (%ERRORS) ) {
	chomp;
	$key		= "$_";
	unshift(@finalresult,"$key - ")	if ($ERRORS{$key} == $exitstatus);
}

# Turn the array into a string
$output		= join(' ', @finalresult);
# Since the last part of the string will be a trailing comman, chop that off
# and append a period.
chop($output);
$output		.= '.';

print "$output\n";
exit $exitstatus;


##################################################################

sub readKstat() {
	warn "$DEBUG readKstat Begin\n"	if ($DEBUG);
	my $iface		= shift;
	my $type		= shift;
	my $kstat		= "$sudo /usr/bin/kstat";
	my $kstatArgs	= '-n';
	my ($tmatch,$return,$speed,$duplex,$line,$key);
	my (%typeTable,%dplxTable);
	my (@splitLine);
	my $loop	= 0;
	my $nosupport;

	%typeTable		= (
		'duplex'		=> 'duplex|link_mode',
		'speed'			=> 'speed');

	%dplxTable		= (
		'full'			=> 'full|fd|2',
		'half'			=> 'half|hd|1');

	$tmatch			= "$typeTable{$type}";

	if ($DEBUG)
	{
		warn "$DEBUG - interface = $iface\n";
		warn "$DEBUG - type = $type\n";
		warn "$DEBUG - Type of match criteria = $tmatch\n";
	}

	# Redirect STDERR to /dev/null if we're not in debug mode
	open STDERR, "/dev/null"	if (! $DEBUG);

	# Open a pipe to kstat and the interface driver
	open KSTAT, "$kstat $kstatArgs $iface |";

	# Try to match the conditions we were given
	warn "$DEBUG - Entering kstat loop\n"	if ($DEBUG);
	while (<KSTAT>)
	{
		warn "$DEBUG - Loop $loop\n"	if ($DEBUG);
		$loop++	if ($DEBUG);
		next if !/$tmatch/;
		chomp;
		$line		= "$_";
		warn "$DEBUG - matched: $line"	if ($DEBUG);

		# If it's a duplex match, populate $realduplex
		# with the proper duplex
		if ($type =~ /duplex/)
		{
			warn "$DEBUG - This is a duplex match\n"	if ($DEBUG);
			foreach (keys(%dplxTable))
			{
				chomp;
				$key		= "$_";
				warn "$DEBUG - duplex key = $key\n"	if ($DEBUG);
				$realduplex	= "$key"	if ($line =~ /$dplxTable{$key}/);
			}
		# Otherwise if it's a speed match, populate $realspeed
		} elsif ($type =~ /speed/)
		{
			warn "$DEBUG - This is a speed match\n"	if ($DEBUG);
			@splitLine	= split(/\s/, $line);
			$realspeed	= pop(@splitLine);
		}

		# If neither $realduplex or $realspeed are populated,
		# assume that the interface is not supported
		$nosupport++	if (! $realduplex and ! $realspeed);
		if ($DEBUG)
		{
			warn "$DEBUG - $iface not supported\n"	if ($nosupport);
		}

	}

	# Close the kstat pipe
	close KSTAT;

	# Stop redirecting stderr to /dev/null
	close STDERR	if <STDERR>;

	$return		= $ERRORS{'OK'}	if (! $return);

	warn "$DEBUG readKstat return = $return\n"	if ($DEBUG);
	return $return;
}

sub checkIFStatus() {
	warn "$DEBUG checkIFStatus Begin\n"	if ($DEBUG);
	my $iface       = shift;
	my $cmd			= shift;
	my $return      = 1;
	my $match       = '^\s+inet';

	if ($DEBUG)
	{
		warn "$DEBUG - interface = $iface\n";
		warn "$DEBUG - command = $cmd\n";
	}

	# Redirect STDERR to /dev/null if we're not in debug mode
	open STDERR,"/dev/null"	if (! $DEBUG);

	warn "$DEBUG - opening a pipe to $cmd $iface\n"	if ($DEBUG);
	open IF,"$cmd $iface |";
	while (<IF>) {
		next if !/$match/;
		warn "$DEBUG - matched: $_\n"	if ($DEBUG);
		$return--;
	}
	close IF;
	close STDERR	if <STDERR>;

	warn "$DEBUG checkIFStatus return = $return\n"	if ($DEBUG);
	return $return;
}

sub whichOS
{
	warn "$DEBUG whichOS Begin\n"	if ($DEBUG);
	use English qw($OSNAME);
	my $return;
	if ($OSNAME)
	{
		$return	= "$OSNAME";
	} else
	{
		$return	= `uname -d`;
	}
	chomp $return;
	if ($return)
	{
		$return		=~ tr/A-Z/a-z/;
		if ($return =~ /(linux)/) {
			$return		= "$1";
		}
	}

	warn "$DEBUG whichOS return = $return\n"	if ($DEBUG);
	return $return;
}

sub checkLink
{
	warn "$DEBUG checkLink Begin\n"	if ($DEBUG);
	my $os		= shift;
	my $iface	= shift;
	my $type	= shift;
	my($linmatch,$solmatch,$result,$duplexmatch,$key,$return);
	my(%oscmd,%match,%dmatch);
	my(@splitout);
	my $nosupport;

	if ($DEBUG)
	{
		warn "$DEBUG - operating system = $os\n";
		warn "$DEBUG - interface = $iface\n";
		warn "$DEBUG - check type = $type\n";
	}

	%dmatch		= (
		"half"		=> 'hd|half.duplex',
		"full"		=> 'fd|full.duplex');
	$duplexmatch	= "$dmatch{'full'}|$dmatch{'half'}";

	# Here's where the regex for matching the speed and the duplex are
	# constructed.
	if ($type =~ /duplex/)
	{
		$linmatch	= "^.*10{1,3}.*($duplexmatch)";
		$solmatch	= '';
	} else {
		$linmatch	= '^.*(10{1,3})';
		$solmatch	= '';
	}

	%match		= (
		"linux"		=> "$linmatch",
		"solaris"	=> "$solmatch");

	%oscmd		= (
		"solaris"	=> "$sudo /usr/sbin/ndd",
		"linux"		=> "$sudo /sbin/mii-tool $iface");

	# Redirect STDERR to /dev/null if we're not in debug mode
	open STDERR,"/dev/null"	if (! $DEBUG);

	# Open a pipe to a command to check the link status
	warn "$DEBUG - opening a pipe to $oscmd{$os}\n"	if ($DEBUG);
	open CHECK,"$oscmd{$os} |";
	while (<CHECK>)
	{
		tr/A-Z/a-z/;
		chomp;
		$result		= "$_";
		warn "$DEBUG - result = $result\n"	if ($DEBUG);
	}
	close CHECK;

	# Stop redirecting STDERR
	close STDERR	if <STDERR>;

	# If the interface has no link, skip it
	if ("$result" =~ /no link/)
	{
		$nolink		= 1;
		return $nolink;
	}

	if ($result =~ /$match{$os}/)
	{
		$result		= "$1";
		warn "$DEBUG - matched $result\n"	if ($DEBUG);
		$realspeed	= "$result"	if ($type =~ /speed/);
		$realduplex	= "$result"	if ($type =~ /duplex/);
		# If this is a check for duplex, make sure that we convert
		# the value of duplex to 'half' or 'full' so that it reads
		# better to the user.
		if ($realduplex)
		{
			foreach (keys (%dmatch) )
			{
				$key		= "$_";
				chomp;
				if ($realduplex =~ /$dmatch{$key}/)
				{
					$realduplex = "$key";
				}
			}
		}
		$return		= $ERRORS{'OK'};
	# If no match is found, assume that the driver is not
	# supported.
	} else
	{
		$nosupport++;
		warn "$DEBUG - $iface not supported\n"	if ($nosupport);
		$return		= $ERRORS{'OK'}	if (! $return);
	}

	warn "$DEBUG checkLink return = $return\n"	if ($DEBUG);
	return $return;
}

sub print_usage
{
    print "Usage:\n";
    print "  $PROGNAME [<-s speed >] [<-d duplex>] [<-i interface>]\n";
    print "  $PROGNAME [-h | --help]\n";
    print "  $PROGNAME [-V | --version]\n";
}

sub print_help
{
    print_revision($PROGNAME, $REVISION);
    print_usage();
    print "\n";
    print "  <speed>  10|100|1000\n";
    print "  <duplex>  half|full\n";
    print "  <interface>  'eth1,eth4'\n";
    print "\n";
    support();
}
