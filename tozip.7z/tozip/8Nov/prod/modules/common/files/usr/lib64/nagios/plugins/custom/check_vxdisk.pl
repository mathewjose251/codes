#!/usr/bin/perl
# $Id: check_vxdisk.pl,v 1.1 2018/10/30 10:12:02 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/check_vxdisk.pl,v $
#
# Program       : check_vxdisk
# Author        : Sean Heshmati 6/2005
# Description   : This plugin checks the status of disks, subdisks, plex, and volums under VxVM control
# Requirements	: No password sudo access to /usr/sbin/vxprint for the nagios user
#
########################################################################################
use strict;

use lib "/usr/lib/nagios/plugins";
use vars qw($PROGNAME $REVISION);
use Getopt::Long;
use vars
  qw (@opt_e @vxprint @bad @bad_dmp @vxdmp_out @larr $sudo $vxprint $vxdiskadm $vxdmp_out %types $ty $name $assoc $kstate $state $line $message $dmessage $dg $v $d $s $exitstatus $disk $dstate $dpaths $enbl $dsbl $encl);
use utils qw (%ERRORS &print_revision &support);
my $sudo       = "/usr/lib/nagios/plugins/custom/sudo_wrp";
my $vxprint    = "/usr/sbin/vxprint";
my $vxdmpadm   = "/usr/sbin/vxdmpadm";
my $exitstatus = $ERRORS{UNKNOWN};
my %types      = ( dm => 'Disk', v => 'Volume', pl => 'Plex', sd => 'SubDisk' );

GetOptions( "e=s@" => \@opt_e, "excludeRegex=s@" => \@opt_e );

if ( !-e $sudo || !-e $vxprint ) {
    print "UNKNOWN - $sudo or $vxprint not found!\n";
    exit $ERRORS{UNKNOWN};
}

@vxprint = `$sudo $vxprint -dvps`;

if ( !@vxprint ) {
    $message = "CRITICAL - No output from $vxprint\n";
    exit $ERRORS{UNKNOWN};
}

for $line (@vxprint) {
    chomp($line);
    next unless $line;
    $line =~ s/\s+/,/g;
    ( $ty, $name, $assoc, $kstate, undef, undef, $state, undef ) =
      split( /,/, "$line" );

    if ( $ty =~ /^Disk/ ) {
        ( undef, $dg ) = split( ":,", $line );
        next;
    }

    if ( $state =~ /(\-|STATE|ACTIVE|NOHOTUSE)/ ) {
        next;
    }
    else {
        push( @bad, "$ty:$dg:$name:$assoc:$state" );
    }
}

#
# vxdiskadm for checking paths
#
# build list of valid enclosures
#
@vxdmp_out = `$sudo $vxdmpadm listctlr all 2>/dev/null`;

if ( !@vxdmp_out ) {
    $message = "CRITICAL - No output from $vxdiskadm\n";
    exit $ERRORS{UNKNOWN};
}

#
my %enclosure = ();
my $enclosure;
foreach $line (@vxdmp_out) {
    next if ( $line =~ '^CTLR-NAME\s+' or $line =~ '^CTLR_NAME\s+' or $line =~ '^=+' );
    @larr = split( /\s+/, $line );
    if (@opt_e) {
        next if map { $larr[3] =~ /^$_$/ } @opt_e;
    }
    $enclosure{ $larr[3] } = 1;
}

# check paths for each enclosure
#
foreach $enclosure ( sort keys(%enclosure) ) {
    @vxdmp_out = `$sudo $vxdmpadm getdmpnode enclosure=$enclosure 2>/dev/null`;

    if ( !@vxdmp_out ) {
        $message = "CRITICAL - No output from $vxdiskadm\n";
        exit $ERRORS{UNKNOWN};
    }

    #
    foreach $line (@vxdmp_out) {
        next if ( $line =~ '^NAME\s+' or $line =~ '^=+' );
        @larr = split( /\s+/, $line );
        if ( $larr[1] =~ m/^DISABLED/ or $larr[3] lt '2' or $larr[5] gt '0' ) {

            #       print "disk $larr[0] is disabled\n";
            push( @bad_dmp,
                "$larr[0]:$larr[1]:$larr[3]:$larr[4]:$larr[5]:$larr[6]" );
        }
    }
}

if (@bad) {
    while (<@bad>) {
        ( $ty, $dg, $v, $d, $s ) = split( ":", $_ );
        $message .= "(Group: $dg $types{$ty}: $v Assoc: $d Status: $s) ";
    }
    $message    = "CRITICAL - $message\n";
    $exitstatus = $ERRORS{CRITICAL};
}
elsif (@bad_dmp) {
    while (<@bad_dmp>) {
        ( $disk, $dstate, $dpaths, $enbl, $dsbl, $encl ) = split( ":", $_ );
        $dmessage .=
"(Disk: $disk in Enclosure $encl has state=$dstate with $dpaths paths $enbl Enabled and $dsbl Disabled) ";
    }
    $dmessage   = "CRITICAL - $dmessage\n";
    $exitstatus = $ERRORS{CRITICAL};
}
else {
    $message    = "OK: All Veritas disks are okay\n";
    $exitstatus = $ERRORS{OK};
}

print $message, $dmessage;
exit $exitstatus;
