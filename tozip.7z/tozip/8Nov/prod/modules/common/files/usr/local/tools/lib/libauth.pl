#!/usr/bin/perl

warn "BEGIN: libauth.pl\n"								if ($DEBUG);	#DEBUG

sub authenticate_user() {
	warn "BEGIN: authenticate_user()\n"					if ($DEBUG);	#DEBUG
	$auth_file	= shift;

	$userid		= "$ENV{'REMOTE_USER'}";

	open FILE, "$auth_file" or die "Could not open $auth_file for reading: $!\n";
		while (<FILE>) {
			next if !/^"$userid"/;
			report_error("$userid","noaccess") if eof FILE;
			chomp($_);
			@entry		= "$_";
		}
	close FILE;

	warn "END: authenticate_user()\n"					if ($DEBUG);	#DEBUG
	return @entry;
}

warn "END: libauth.pl\n"								if ($DEBUG);	#DEBUG
return 1;
