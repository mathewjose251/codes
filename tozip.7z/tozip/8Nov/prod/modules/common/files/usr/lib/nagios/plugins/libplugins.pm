#!/usr/bin/perl -w
#
# (c) 2003		St�phane Urbanovski <stephane.urbanovski@ac-nancy-metz.fr>
#					DSI - Acad�mie de Nancy-Metz
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty
# of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# you should have received a copy of the GNU General Public License
# along with this program (or with Netsaint);  if not, write to the
# Free Software Foundation, Inc., 59 Temple Place - Suite 330,
# Boston, MA 02111-1307, USA
#
#
package libplugins;

use strict;
use Carp;

use Pod::Usage;	

require Exporter;
use vars qw(@ISA @EXPORT_OK %EXIT_CODES);
@ISA = qw(Exporter);
@EXPORT_OK = qw(%EXIT_CODES %ERR_LEVELS &showUsage);


# Predefined exit codes for Nagios/NetSaint
our %EXIT_CODES = (
	'UNKNOWN'	=> -1,
	'OK' 		=> 0,
	'WARNING'	=> 1,
	'CRITICAL'	=> 2,
);

our %ERR_LEVELS = (
	'EMERG'		=> 0,	# syst�me inutilisable
	'ALERT'		=> 1,	# action � effectuer imm�diatement
	'CRIT'		=> 2,	# conditions critiques
	'ERR'		=> 3,	# conditions d'erreurs
	'WARNING'	=> 4,	# message d'avertissement
	'NOTICE'	=> 5,	# normal mais significatif
	'INFO'		=> 6,	# informations
	'DEBUG'		=> 7,	# messages de d�bugging
	'TEST'		=> 8	# for testing only
);

sub showUsage
{
	my ($opt_m) = @_;
	if (1 )
	{
		if ( $> > 0)
		{
			# we are not root
			
		}
		else
		{
			my $manuser = 0;
			if ( $manuser = (getpwnam('man'))[2] )
			{
			}
			elsif ( $manuser = (getpwnam('nobody'))[2] )
			{
			}
			else
			{
				croak "Enable to drop privileges !";
			}

			print "Changing uid & euid to ".$manuser." ...\n" ;

			# let's become man user
			$<=$manuser;
			$>=$manuser;
	
		}

		pod2usage(
			-exitstatus	=> 0,
			-verbose	=> (defined($opt_m)?2:1)
		);

	}
}
1;
