#!/usr/bin/perl -w

# $Id: check_ldap.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $
#
# check LDAP connections
#
# Copyright (c) 2006 Holger Weiss <holger@CIS.FU-Berlin.DE>
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

use strict;
use Socket;
use Getopt::Long;
use Net::LDAP;
use lib "/server/nagios/libexec";
use utils qw(%ERRORS $TIMEOUT &print_revision &support);
use vars qw($PROGNAME $PORT $CRIT $WARN $opt_a $opt_b $opt_D $opt_f $opt_r
            $opt_s $opt_H $opt_P $opt_S $opt_V $opt_c $opt_h $opt_p $opt_t
            $opt_v $opt_w);

sub talk_ldap ($$$$$$$$$$);
sub die_crit ($);
sub die_warn ($);
sub die_unknown ($);
sub print_usage ();
sub print_help ();
my ($hostname, $ldap_port, $warning, $critical, $timeout, $start, $duration,
    $response);

$PROGNAME = "check-ldap";
$PORT = 389;
$WARN = $TIMEOUT;
$CRIT = $TIMEOUT;
$SIG{'ALRM'} = sub { die_unknown("Timeout"); };
$ENV{'PATH'}='';
$ENV{'ENV'}='';

Getopt::Long::Configure("bundling");
if (!GetOptions("V"   => \$opt_V, "version"    => \$opt_V,
                "h"   => \$opt_h, "help"       => \$opt_h,
                "S"   => \$opt_S, "ssl"        => \$opt_S,
                "v+"  => \$opt_v, "verbose+"   => \$opt_v,
                "a=s" => \$opt_a, "attr"       => \$opt_a,
                "b=s" => \$opt_b, "base"       => \$opt_b,
                "D=s" => \$opt_D, "bind"       => \$opt_D,
                "f=s" => \$opt_f, "filter"     => \$opt_f,
                "r=s" => \$opt_r, "result"     => \$opt_r,
                "s=s" => \$opt_s, "scope=s"    => \$opt_s,
                "H=s" => \$opt_H, "hostname=s" => \$opt_H,
                "c=i" => \$opt_c, "critical=i" => \$opt_c,
                "P=i" => \$opt_P, "port=i"     => \$opt_P,
                "p=s" => \$opt_p, "password=s" => \$opt_p,
                "t=i" => \$opt_t, "timeout=i"  => \$opt_t,
                "w=i" => \$opt_w, "warning=i"  => \$opt_w)) {
	print "LDAP UNKNOWN - Error processing command line options\n";
	print_usage();
	exit $ERRORS{'UNKNOWN'};
}
if ($opt_V) {
	print_revision($PROGNAME,'$Revision: 1.1 $ ');
	exit $ERRORS{'OK'};
}
if ($opt_h) {
	print_help();
	exit $ERRORS{'OK'};
}
unless ($opt_H) {
	print "LDAP UNKNOWN - No target host specified\n";
	print_usage();
	exit $ERRORS{'UNKNOWN'};
}
$hostname = ($opt_S && $opt_H !~ /^ldaps:\/\//) ? "ldaps://" . $opt_H : $opt_H;
$critical = $opt_c ? $opt_c : $CRIT;
$warning = $opt_w ? $opt_w : $critical;
if ($warning > $critical) {
	print "LDAP UNKNOWN - Warning larger than critical threshold\n";
	print_usage();
	exit $ERRORS{'UNKNOWN'};
}
$ldap_port = $opt_P ? $opt_P : getservbyname("ldap", "tcp");
$ldap_port = $PORT unless defined $ldap_port;
$timeout = $opt_t ? $opt_t : $TIMEOUT;
alarm($timeout);

$start = time;
$response = talk_ldap($hostname, $ldap_port, $opt_p, $timeout, $opt_D, $opt_b,
                      $opt_f, $opt_a, $opt_r, $opt_s);
$duration = time - $start;

die_crit("$duration sec. response time") if $duration >= $critical;
die_warn("$duration sec. response time") if $duration >= $warning;

print "LDAP OK - $response\n";
exit $ERRORS{'OK'};

sub talk_ldap ($$$$$$$$$$) {
	my ($host, $port, $pass, $to, $dn, $base, $filter, $attr, $result,
	    $scope) = @_;
	my ($ldap, $lmsg, $lquery);

	$ldap = Net::LDAP->new(
		$host,
		port => $port,
		timeout => $to);
	die_crit("connect error") unless $ldap;

	if ($dn) {
		$lmsg = ($pass) ? $ldap->bind(dn => $dn, password => $pass)
			        : $ldap->bind(dn => $dn);
	} else {	# anonymous bind
		$lmsg = $ldap->bind();
	}
	die_crit("bind error: " . $lmsg->error) if $lmsg->code();

	if ($base && $filter && $attr) {
		$scope = "sub" unless $scope;
		$lquery = $ldap->search(
			base   => $base,
			filter => $filter,
			attrs  => [$attr],
			scope  => $scope);
		die_crit("search error: " . $lquery->error) if $lquery->code();
	} elsif ($base || $filter || $attr) {
		die_unknown("-a, -b and -f must be used together"); # FIXME
	}

	$ldap->unbind();

	if (defined $lquery) {
		die_crit("count result error") unless $lquery->count() == 1;
		my $value = $lquery->entry(0)->get_value($attr);

		die_crit("wrong result entry: " . $value)
			if $result && $value ne $result;
		return "$host LDAP search result: $value";
	}
	return "$host seems to be fine";
}

sub die_unknown ($) {
	printf "LDAP UNKNOWN - %s\n", shift;
	exit $ERRORS{'UNKNOWN'};
}

sub die_warn ($) {
	printf "LDAP WARNING - %s\n", shift;
	exit $ERRORS{'WARNING'};
}

sub die_crit ($) {
	printf "LDAP CRITICAL - %s\n", shift;
	exit $ERRORS{'CRITICAL'};
}

sub print_usage () {
	print "Usage: $PROGNAME -H host [-P port] [-w warn] [-c crit] " .
	      "[-t timeout]\n                        "                  .
	      "[-p password] [-a attribute] [-b base] "                 .
	      "[-D bind DN]\n                        "                  .
	      "[-r result] [-s scope] [-S] [-v]\n";
}

sub print_help () {
	print_revision($PROGNAME, '$Revision: 1.1 $');
	print "Copyright (c) 2006 Holger Weiss\n\n";
	print "Check LDAP connections with the specified host.\n\n";
	print_usage();
	print <<EOF;

 -H, --hostname=ADDRESS
    Host name or IP Address
 -p, --port=INTEGER
    Port number (default: $PORT)
 -P, --pass=STRING
    LDAP password
 -a, --attr=ATTRIBUTE
    LDAP attribute
 -b, --base=BASE
    LDAP base
 -D, --bind=DN
    LDAP bind DN
 -f, --filter
    Filter
 -r, --result=RESULT
    Expected result
 -s, --scope='base'|'one'|'sub'
    LDAP scope
 -t, --timeout=INTEGER
    Seconds before connection times out (default: $TIMEOUT)
 -w, --warning=INTEGER
    Response time to result in warning status (seconds)
 -c, --critical=INTEGER
    Response time to result in critical status (seconds)
 -t, --timeout=INTEGER
    Seconds before connection times out (default: $TIMEOUT)
 -S, --ssl
    Use SSL on connect
 -v, --verbose
    Show details for command-line debugging (Nagios may truncate output)

EOF
	support();
}
