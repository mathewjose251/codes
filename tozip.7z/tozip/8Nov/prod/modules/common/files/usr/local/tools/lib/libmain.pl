# Note: This file was tabbed out in a view using four spaces for tabs

# Copyright 2003, 2004, 2005, Brendan P. Harris <bharris@stotch.com>
# Everything contained herein was written originally by Brendan P. Harris
# <bharris@stotch.com> unless stated otherwise.  This code is distributed
# under the GNU General Public License version 2 and is freely distributable as
# you wish as long as this license header, the "Official Penguin Disclaimer"
# and all of the comments (humorous or not) remain in-tact in its distribution.
# By redistributing this code you are agreeing to these terms and conditions
# and the terms and conditions of the GPL2.
#
# The License:
# http://www.gnu.org/licenses/gpl.txt
#
# For original and up-to-date releases of this file and others, go to:
# http://www.stotch.com/perl/releases/
#
# Info on the GPL2:
# http://www.gnu.org/licenses/licenses.html#GPL

#	GNU General Public License
#	This program is free software; you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation; either version 2 of the License, or
#	(at your option) any later version.
#
#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.
#
#	You should have received a copy of the GNU General Public License
#	along with this program; if not, write to the Free Software
#	Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

# Official Penguin Disclaimer
# Yes, penguins are my favorite animals.  No, the existence of Linux is not
# the source of this.  I have loved penguins since I was two-years-old.  Linux
# did not exist in 1980.  Linus Torvalds did, but I was two and as I result my
# ability to comingle and process such elaborate strains of thought and envy
# enough to symbolize Linus' project mascott with my future love for his
# future invention was far too minimal to be even a remote or distant
# probability.  I do not truly know why I love penguins so much.  Perhaps
# that is how love works.  But if you truly must have a reason for my extreme
# love of penguins, my answer is, "Penguins are always well-dressed, regardless
# of the occasion."
#
# If you want to know more about the Linux Mascott, Tux, go here:
# http://www.isc.tamu.edu/~lewing/linux/

# <sarcasm>Don't get confused.  There are no functions/subroutines in here.
# No.  Just comments.  Just comments.</sarcasm>

# Q. What the heck is this file?
# A. Your question echos the screams and cries of a nation of people.  Here
# is a quick summary of what this file is intended for:
#
# This file is intended to be the one and only required batch of functions for
# all UNIX-like systems administration scripts written in Perl.  The key is to
# use this as a "require" file in every script you write and enforce the
# standards of these functions.  This may not be the cleanest code or the most
# groovy Perl methods out there, but they are all written with good standards
# in mind.  If you stick to these subroutines and require all of your scripts
# to use them, you will save yourself a lot of headaches.  As a result, your
# code will be more portable, more easilly maintainable and easier to catch on
# to.  If you work in an enterprise, coprorate environment and have a team of
# systems administrators working with you or you intend to hire on new sysadmin
# personal, it will be easy for everyone to maintain or learn the scripting
# standards, which the use of these functions will cause you to follow.
#
# Another recommended library that comes batched with this library is
# liberr.pl.  Please take a moment to review the intro comments to that file
# as well and consider implementing its functions in all of your scripts.

# Some standard constansts
use constant TRUE		=> 1;
use constant FALSE		=> 0;
use constant MODE_LOG	=> '0644';
use constant MODE_LOCK	=> '0644';

# Some modules that we need
use Fcntl ':flock';		# import LOCK_* constants for lockFile()

# FindBin is handy for finding certain script resources
use FindBin qw($Bin);

# I like a lot of the functions in POSIX
use POSIX;

# Some libraries we might need can be found in here
use lib "$Bin/../lib";

# Import the common constants
require "TableOfConstants";

# Globals
use vars qw(
	$debugPrepend $debugLevel $DEBUG @openDirs);

# Setup default signal handlers
#$SIG{'QUIT'}		= &dumpStatus();

# Setup certain kinds of default debugging info
&configDebug('DEBUG');
sub configDebug() {
	$debugPrepend	= shift		if (! $debugPrepend);
}

# Mental Note--yet written in code at that.  Crazy!:
# One of these days I should either adopt someone else's debugging module and
# standard or I should make my own debugging module.  Yeah.  Maybe I'll call
# it "Debuggery" or something.  Yeah.  "Debuggery--saving the many abused child
# processes of the world."
# use Debuggery;
# $debuggeredChild = debugger($child);
# print "$debuggeredChild $stderrMsg\n";

# Returns a list of hosts that are listening on port 22.  You can pass it an
# unlimited number of host names and/or host categories.  Host categories
# must match the host list files.
sub getHostsFromList() {
	my @list		= @_;
	my $listDir		= "$etcDir";
	my $prefix		= 'hosts';
	my @fileList	= ();
	my @hostList	= ();
	my @return		= ();
	my $match		= '';
	my $found		= '';
	my $host		= '';
	my $fileHandle	= "$$"."FF".int(rand(27));

	# Get the list of host lists
	opendir $fileHandle,"$listDir" or cleanExit($!,"$!: $listDir");
	@fileList		= grep { /^$prefix/ && -f "$listDir/$_" } readdir $fileHandle;
	closedir $fileHandle;
	$fileHandle++;

	# Process the list of hostnames or host file names given by the caller
	foreach (@list) {
		chomp;
		$match			= "$_";
		undef $found;

		# First, check to see if it's a valid hostname
		if (! pingHost($match)) {

			# If not a valid host name, see if the name matches as a suffix
			# to one of the existing host lists
			foreach (@fileList) {
				next if !/^$prefix.$match/;
				chomp;
				open $fileHandle,"$listDir/$_" or cleanExit($!,"$!: $_");
				push(@hostList,<$fileHandle>);
#				foreach (@hostList) { chomp; print "$_\n"; }
				close $fileHandle;
				$found++;
				last;
			}

		# If it is a valid host name, pass it on to the pre-processed
		# list of hosts
		} else {
			push(@return,$match);
			$found++;
		}

		# If $found has no value, then the given name is neither a valid
		# host name or a valid suffix to a host list file, so notify
		# the user and move to the next name in the list
		warn "\"$prefix.$match\" list does not exist and host \"$match\" does not exist.\n"	if (! $found);
	}

	# This is where we process the host list that we have compiled and
	# make sure that each host is responding on port 22 before pushing
	# it to the list that will be returned to the caller
	foreach (@hostList) {
		next if /^#|^\s+|^;|^!|^\/\/|^\[|^\]/;
		chomp;
		$host		= "$_";
		if (! pingHost($host)) {
			warn "\"$host\" is not responding on port 22.  Skipping.\n";
		} else {
			push(@return,$host);
		}
	}

	return @return;

}

# getCopyright returns a copyright string if found, otherwise returns null.
# The copyright file is assumed to reside in $Bin/../lib/Copyright.
sub getCopyright() {
	my(
		$myFunc,
		$return,
		$copyrtFile
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n" if ($DEBUG);

#	use FindBin qw($Bin);
	# We get the copyright by doing a "require" on the file.  The file should
	# contain:
	# $copyMsg='copyright_message';
	$copyrtFile		= "$Bin/../lib/Copyright";
	$return			= require "$copyrtFile"	if (-f $copyrtFile);

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n" if ($DEBUG);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n" if ($DEBUG); 
	return $return;
}

# This will take an open file handle as its first argument, an action
# as its second argument and an optional iteration timeout third argument
# and perform that action (locking or unlocking) on the file.  The type of
# locking depends entirely upon the OS.  For Solaris 9, flock() is called and
# advisory lock is applied.
#
# Note: The all of the given arguments are passed transparently to flock().
# So check out "perldoc -f flock" for details.
# Optional third argument support removed due to its lack of necessity.
sub lockFile($$) {
	my(
		$myFunc,
		$return,
		$fileHandle,
		$action,
		$iteration,
		$iterationMax,
		$warnMsg
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n" if ($DEBUG);

	$fileHandle		= shift;
	$action			= shift;
#	$iterationMax	= shift;
#	$iteration		= 0;
#	$iterationMax	= 30			if (! $iterationMax);
	$warnMsg		= "Could not $action file with handle '$fileHandle' before maximum iteration threshold ($iterationMax) was reached.";

	# Debug info
	if ($DEBUG) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$fileHandle=$fileHandle\n";
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$action=$action\n";
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$iterationMax=$iterationMax\n";
	}

	# Perform the flock() action
	$return			= flock($fileHandle,$action);

	# Move to the bottom of the file in case anyone appended data during a wait
#	seek($fileHandle, 0, 2)			if ($action =~ /LOCK_EX|LOCK_SH/);
		
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n" if ($DEBUG);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n" if ($DEBUG); 
	return $return;
}

# Plain and simple, returns the basename of the parent script.  Supports an
# optional argument of 'nosuffix', which will return the script name without
# the '.pl' (or whatever is after the last '.' including the last '.')
#
# Note: I have taken the File::Basename package out of this sub and used my
# own debugInfo(), an additional array, a split and a pop because it is just
# a tad bit faster to load without File::Basename.
sub getScriptName {
	my(
		$myFunc,
		$return,
		$option,
#		@splitPath,
		@splitName
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n" if ($DEBUG);

	$option		= shift;
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$option=$option\n" if ($DEBUG);
#	use File::Basename;
	@splitPath	= split(/\//, debugInfo('filename'));
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \@splitPath=@splitPath\n" if ($DEBUG);
	$return		= pop(@splitPath);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n" if ($DEBUG);

#	$return		= basename($0);
	if ($option =~ /nosuffix/ and $return =~ /\./) {
		@splitName	= split(/\./, $return);
		pop @splitName;
		$return		= join('.', @splitName);
	}

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n" if ($DEBUG);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n" if ($DEBUG); 
	return $return;
}

# Usefull function for returning certain types of debugging information.  Use
# the below %typeTable as a reference of what types of information you can
# get.  All information returned is referenced from where it was called by
# default. i.e. sub TestSub { $me = debugInfo('subroutine'); print "$me"; }
# ...will print...
# <package>::TestSub
# Can take an optional second integer argument of 'layer', indicating stages of
# process to step back through.  0 would indicate the immediate caller, thus
# the above code, if given "'subroutine','0'" would instead print out...
# <package>::debugInfo
# With that in mind, if you want to get a return value from this outside of a
# subroutine, yet just inside of the main script, you'll need to give '0' as
# a layer argument.  Likewise, if you want a return value from within a sub
# that is itself within another sub, you'll need to give '2' as a layer arg.
# Use a blank space character or a null as the 'layer' to get the context of
# the most current subroutine.
#
# Default, if no arguments are given, is to return the name of the subroutine
# which called debugInfo().
#
# Note: debugInfo() has none of its own debug warnings or information because
# if it did then any script with a debugLevel set would be way too spammy.  So
# just trust me.  It works like a charm. ;-)
sub debugInfo {
	my(
		$return,
		$type,
		%typeTable,
		$layer,
		$modifier,
		$element
	);
	$type		= shift;
	$layer		= shift;
	$modifier	= shift;

	# Defaults
	$type		= 'subroutine'					if (! $type);
	$layer		= 1								if (! $layer);

	# Build the table of types and their values being the numbers that
	# correspond to the element number returned by caller();
	%typeTable	= (
		"package"		=> 0,		# The Package name
		"filename"		=> 1,		# The filename
		"line"			=> 2,		# The current line
		"subroutine"	=> 3,		# The subroutine
		"hasargs"		=> 4,		# The arguments
		"wantarray"		=> 5,		# ?
		"evaltext"		=> 6,		# ?
		"is_require"	=> 7,		# Whether a "require" is made for resource
		"hints"			=> 8,		# ?
		"bitmask"		=> 9		# ?
	);

	# Set the value of $element to the proper numeric for caller
	$element	= $typeTable{$type};

	# Conditionals based on certain scenarios
	# $layer	= 'blah' if (blah);

	# Now get the requested information
	$return		= (caller($layer))[$element];

	# If a modifier was given, make the proper adjustments to the return
	for ($modifier) {
		use File::Basename;
		$return		= File::Basename::basename($return)	if /base/;
	}

	return $return;
}

# Returns a string that whose value is the name of the last subroutine before
# this function was called.
sub getLastFuncName {
	my(
		$myFunc,
		$return
	);
	$myFunc		= 'getLastFuncName';
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n"	if ($DEBUG);

	$return		= (caller(2))[3]; 

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# A function that wraps the handling of localtime() into a more standardized
# method that is optimal for sysadmin scripts.
# Supports one argument, which is optional.  Supported arguments are:
# sec (returns seconds elapsed from the current hour)
# min (returns minutes elapsed from the current hour)
# hour (returns the current hour)
# mon (returns integer value of the current month)
# year (returns the current year in a four-digit numeric)
# wday (returns integer value of the current weekday)
# yday (returns the number of days elapsed from the year)
# isdst (returns the current zone and zone time type)
# <none> (returns all of the above as an array)
# ctime (returns `date` as a string)
sub getDateTime() {
	my(
		$myFunc,
		$return,
		@date,
		$type,
		$sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: Begin\n"	if ($DEBUG);

	$type		= shift;
	@date		= localtime(time)				if ($type !~ /ctime/);
	$return		= localtime()		if ($type =~ /ctime/ or ! $type);
	($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst)	= @date;
	# Convert the year to a four-digit integer
	$year		+= 1900;
	# Convert seconds, minutes, hours, month and days to two digit integers
	$sec		= sprintf("%02d", $sec)			if (int($sec) < 10);
	$min		= sprintf("%02d", $min)			if (int($min) < 10);
	$hour		= sprintf("%02d", $hour)		if (int($hour) < 10);
	$mon		= sprintf("%02d", $mon)			if (int($mon) < 10);
	$mday		= sprintf("%02d", $mday)		if (int($mday) < 10);
	$mon++;

	for ($type) {
		$return		= $sec						if /sec/;
		$return		= $min						if /min/;
		$return		= $hour						if /hour/;
		$return		= $mday						if /mday/;
		$return		= $mon						if /mon/;
		$return		= $year						if /year/;
		$return		= $wday						if /wday/;
		$return		= $yday						if /yday/;
		$return		= $isdst					if /isdst/;
		$return		= "$year$mon$mday"			if /dns/;
	}

	if (not defined $type) {
		splice(@date);
		@date		= ($sec,$min,$hour,$mday,$mon,$year,$wday,$yday,$isdst);
		warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": return=@date\n"	if ($DEBUG); 
		warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: End\n"	if ($DEBUG); 
		return @date;
	} else {
		warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": \$return=$return\n"	if ($DEBUG); 
		warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: End\n"	if ($DEBUG); 
		return $return;
	}

	return $return;
}

# A comment just for the heck of it.  Please ignore this line.  It's useless.

# A function that returns a string in the format of a time or date stamp.
# Usefull for log entries and file backups.
# First argument is an optional 'type' to be returned.  Supported types are:
# log (default, returns "D m d HH:MM:SS Z YYYY"; i.e. `date`)
# file (returns "YYYYmmddHHMMSS")
# short (returns "YYYY-mm-dd")
sub getTimeStamp {
	my(
		$myFunc,
		$return,
		@date,
		$type
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: Begin\n"		if ($DEBUG);

	$type		= shift;
	for ($type) {
		$return		= &getDateTime('ctime')		if /^log$|^$/;
		@date		= getDateTime()				if !/^log$|^$/;
		$return		= "$date[5]$date[4]$date[3]$date[2]$date[1]$date[0]"	if /^file$|^bak$|^backup$/;
		$return		= "$date[5]-$date[4]-$date[3]"	if /^short$/;
	}

	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": \$return=$return\n"		if ($DEBUG); 
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# Simple function to get the name of the my host that the scrip is executed
# on.  Returns the name of the host when no arguments are given.
# Currently supported argumens are:
# fqdn (returns FQDN; i.e. host.domain.tld)
sub getLocalHostName() {
	my(
		$myFunc,
		$return,
		$type,
		@hostname
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: Begin\n"		if ($DEBUG);

	$type		= shift;

	use Socket;
	use Sys::Hostname;
	@hostname	= split(/\./, hostname());
	if ($type =~ /^fqdn$/) {
		$return		= join('.', @hostname);
	} else {
		$return		= shift(@hostname);
	}

	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": \$return=$return\n"	if ($DEBUG);
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# Verifies the existence of, creates or destroys a "lock" file.  Usefull for
# keeping a program from performing an action more than once at a time.  It is
# recommended that when you call this function you do not specify a filename.
# This is because stopFile chooses a filename that has the $HOSTNAME in it.
# This is safer so that nobody accidentally syncs out a directory with a lock
# file in it to numerous hosts and halts all relative processes on those
# hosts.  Only specify a file name if you need to run multiple instances of
# the parent script, in which case you should manually include the hostname in
# that file name.
# First argument is the "action" to take.  Supported actions are:
# check (verifies if the file exists, returns 0 on existence)
# create (creates the lock file, returns 0 on success)
# kill (destroys an existing lock file, returns 0 on success)
sub stopFile() {
	my(
		$myFunc,
		$return,
		$fileName,
		$lockDir,
		$action,
		$lhostname,
		$file
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend
		" .debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n"		if ($DEBUG);

	$return		= 1;
	$action		= shift;
	$fileName	= shift;
	$lockDir	= "$ENV{'HOME'}";
	$lhostname	= getLocalHostName()			if (! $fileName);

	# $fileName is optional, so lets give it a name if this is not defined
	$fileName	= "$myScriptName.$lhostname.lock"	if (! $fileName);

	# Make sure the lockDir exists and is writeable, otherwise use /tmp
	$lockDir	= '/tmp'						if (! -w "$lockDir");
	# If for some reason /tmp is unusable, die
	if (! -w "$lockDir") {
		cleanExit($!,"$!: $lockDir");
	}

	# Now join the dir and file name together into one abs path
	$file		= "$lockDir/$fileName";

	for ($action) {
		$return		= 0						if (/^check$/ and -e "$file");
		$return		= unlink $file			if (/^kill$/);
		$return		= creat($file)			if (/^create$/);
	}

	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": \$return=$return\n"		if ($DEBUG); 
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# Are you bummed?  Add a silly comment here.  You'd be amazed at how uplifting
# a silly comment in serious code can be.  Seriously.  I was really bummed when
# I started typing the first few words of this comment and already I feel much
# better.  I don't even want to stop typing now.  Let me tell you a story
# about a French exchange student I met about five years ago... Ooh!  I've
# suddenly become inspired to write more code!  Okay, I'll get back to the
# story later, once I've gotten my fill of coding.

# A wrapper for open(), which applies a lock to the file using lockFile().
sub openFile {
	my(
		$myFunc,
		$return,
		$fileName,
		$mode,
		%modeTable,
		$debugLine,
		$badModeMsg,
		$missingArgMsg,
		$dieMsg
	);
	# The global list of open file handles
	use vars qw( @openHandles );

	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: Begin\n"	if ($DEBUG);

	%modeTable	= (
		"clobber"		=> '>',
		"write"			=> '>',
		"trunc"			=> '>',
		"append"		=> '>>',
		"read"			=> '<',
		"rw_append"		=> '+<',
		"readwrite"		=> '+<',
		"log"			=> '>>',
		"rw_clobber"	=> '+>',
		"rw_trunc"		=> '+>',
		"tmp"			=> '+>'
	);

	$fileName	= shift;			$debugLine	= debugInfo('line',' ');
	$missingArgMsg	= "Line $debugLine: $myFunc requires a filename argument.";
	$mode		= shift;			$debugLine	= debugInfo('line',' ');
	$badModeMsg	= "Line $debugLine: Mode $mode is not supported by $myFunc.";
	$mode		= 'read'			if (! $mode);

	# Debug info
	if ($DEBUG) {
		warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$fileName=$fileName\n";

		warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$mode=$mode\n";

		warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \%modeTable=$modeTable{$mode}\n";

		warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$modeTable{\$mode}=$modeTable{$mode}\n";
	}

	if ($modeTable{$mode} =~ /^$/) {
		warn "$badModeMsg\n";
		return 1;
	}

	if (! $fileName) {
		warn "$missingArgMsg\n";
		return 1;
	}

	# If everything up until this point is good, open the file.  $return's
	# value will be the filehandle.
	$return		= "$$".'FH'.getTimeStamp('file');
	$dieMsg		= "Could not open $fileName for '$mode'";
	open($return,"$modeTable{$mode}","$fileName") or cleanExit($!,"$!: $fileName");
	push (@openHandles,$return);
	if ($mode =~ /^log$/) {
		lockFile($return,LOCK_SH);
	} else {
		lockFile($return,LOCK_EX);
	}

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# Simple counterpart to openFile.  Self-explanitory.
sub closeFile($) {
	my(
		$myFunc,
		$return,
		$fileHandle,
		$index
	);
	# The global list of open file handles
	use vars qw( @openHandles );
	$index		= 0;

	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' '). ": $myFunc: Begin\n"	if ($DEBUG);

	$fileHandle	= shift;
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$fileHandle=$fileHandle\n"	if ($DEBUG);

	while (<$fileHandle> and $return lt 30)
	{
		$return		+= close $fileHandle;
	}
	for $index ( 0 .. $#openHandles )
	{
		if ($openHandles[$index] =~ /^$fileHandle$/)
		{
			delete $openHandles[$index];
		}
	}
	lockFile($fileHandle,LOCK_UN);

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n"	if ($DEBUG); 
	warn "$debugPrepend " .debugInfo('filename',' ','base')." ".debugInfo('line',' ').  ": $myFunc: End\n"	if ($DEBUG); 
	return $return;
}

# This is for root-spawned scripts.  It operates with a pid file in /var/run.
# /var/run is a hard-coded value and cannot be specified as an argument.
# Arguments in order of first to last are:
# action (create, check, kill)
# [filename]
# The 'create' action will create a pid file and return 0 on success.
# The 'check' action will check to see if there is a pid file and return the
# pid(s) on success in an array or return 1 on failure and zero on a succcess
# with no pids in the pid file.
# The 'kill' action will kill the process ID(s) in a current pid file and then
# remove the pid file and return zero on success.
# If no action is specified, 'create' will be the assumed action.
# If no 'filename' is given, the program name (short of the suffix) will be
# used with ".pid" appended at the end.
# Note: Uses $$ to get the pid.
# Note: On 'create', appends the pid if the pid file exists and the last
# pid in the current file is an active process.  To override this, use 'kill'
# first.
sub pidFile() {
	my(
		$myFunc,
		@return,
		$fileName,
		$action,
		@pids,
		$runDir,
		$dieMsg,
		$fileHandle,
		$status,
		$lastPid
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n"	if ($DEBUG);

	$action		= shift;
	$fileName	= shift;
	$runDir		= '/var/run/';
	$fileName	= "$runDir"
		.getScriptName('nosuffix').
		'.pid'	if (! $fileName);
	$dieMsg		= 'CRITICAL: Could not close filehandle';

	# If 'kill' was specified...
	if ($action =~ /^kill$/) {
		$fileHandle	= openFile($fileName,'read');
		# Read in all of the pids contained in the file, should be newline
		# sepparated.
		@pids		= split(/\n/, <$fileHandle>);
		$status		= closeFile($fileHandle);
		# If we were able to close the filehandle properly, proceed to killing
		# each pid that was found in the pid file.
		if ($status == 0) {
			foreach (@pids) {
				chomp $_;
				$status		= kill $_;
				# If we could not kill one or more pids, make sure this gets
				# back to the caller.
				$return[0]	+= $status;
			}
			# If we were able to kill all of the pids successfully, remove the
			# pid file.
			unlink($fileName)				if ($return[0] == 0);
		} else {
			# Die with a message if we could not close the file handle properly
			cleanExit($!,"$!: Could not close filehandle: $fileHandle");
		}
	}

	# If 'check' was specified...
	elsif ($action =~ /^check$/) {
		if (-e $fileName) {
			$fileHandle	= openFile($fileName,'read');
			# What we will return is the list of pids contained in the pid file
			@return		= split(/\n/, <$fileHandle>);
			$status		= closeFile($fileHandle);
			cleanExit($!,"$!: $fileName")
				if ($status != 0);
		} else {
			# If there was no pid file, bump the value of @return's first
			# element to the value of 1 so that the caller knows this.
			$return[0]++;
		}
	}

	# If no action was given, assume that we are to create a pid file
	else {
		# If the pid file does not already exist, just open the new file and
		# print the current pid to it.
		if (! -e $fileName) {
			$fileHandle	= openFile($fileName,'trunc');
			print $fileHandle, $$;
			$status		= closeFile($fileHandle);
			cleanExit($!,"$!: Could not close filehandle: $fileHandle")
				if ($status != 0);
		# If the pid file already exists, jump to the bottom of the file, get
		# the last pid and check to see if the last pid is an active process.
		} else {
			$fileHandle	= openFile($fileName,'rw_append');
			seek($fileHandle,0,2);
			while (<$fileHandle>) {
				$lastPid	= $_;
				last;
			}
			$status		= checkPid($lastPid);
			# If the last pid checked out to be an active process, since we
			# started out by openning the file in a read/write append mode, go
			# ahead and print the current pid to the file and it will be
			# appended to the end of the file.
			if ($status == 0) {
				print $fileHandle, $$;
			# If the last pid did not checkout to be an active process, we need
			# to close the file and re-open it in a truncation mode so that we
			# overwrite all other data in the pid file.
			} else {
				$status		= closeFile($fileHandle);
				cleanExit($!,"$!: Could not close filehandle: $filehandle")
					if ($status != 0);
				$fileHandle	= openFile($fileName,'trunc');
				print $fileHandle, $$;
			}
			# Once everthing is done, close out the file.  Die if we cannot
			# properly close the file handle.
			$status		= closeFile($fileHandle);
			cleanExit($!,"$!: Could not close filehandle: $fileHandle")
				if ($status != 0);
		}
	}

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \@return=@return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# Pass this a pid and it will return 0 if the process exists or greater than
# zero if not.  Pass it no arguments and it will use $$ PID.
sub checkPid() {
	my(
		$myFunc,
		$return,
		$pid,
		$procDir
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n"	if ($DEBUG);

	$pid		= $$			if (! $pid);
	$procDir	= '/proc';
	$return		= 1				if (! -e "$procDir/$pid"); 

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}

# My mom talks wa-ay too much.  Sometimes I wish I could her a SIGHUP.  Problem
# is, yammerd is a root-owned process and when it loops on a race condition--
# only her husband has root access and he and I are not the best of friends--
# I'm stuck with an infinite loop on yammerd with no option but to disconnect.
# And I sure as hell don't want root access to my mom.  So, I just disconnect
# and instead login to my sister, who is running on a newer harware platform
# with an up-to-date OS and software.  So, conversations with my sister are far
# more reliable.

sub displayHelp() {
	my $type		= shift;
	my $helpFile	= shift;
	my $helpStr	= shift;
	my(
		$myFunc,
		$return,
		$fileHandle
	);
	$myFunc		= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: Begin\n"	if ($DEBUG);

	$return		= 1;

	cleanExit($!,"$!: $helpFile") if (! -f $helpFile);
	cleanExit($return++) if (! $type or ! $helpFile);

	print ":$type: $helpStr\n\n";

	$fileHandle	= openFile($helpFile);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": fileHandle=$fileHandle\n"	if ($DEBUG);
	while (<$fileHandle>) {
		last if ($type =~ /help/);
		next if !/^=$type$/;
		last if /^=$type/;
	}
	while (<$fileHandle>) {
		last if (/^=/ and $type !~ /help/);
		print "$_"	if !/^=/;
	}
	closeFile($fileHandle);

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 
	cleanExit($return);
}

# Rather self-explanitory cvs wrapper
# SYNPOSIS:
# 	cvsPerl("checkout","<file1> <file2> <file...>")
# 	cvsPerl("checkout -r LATEST_REV","<file1> <file2> <file...>")
# 	cvsPerl("commit","<file1> <file2> <file...>","These files are updated")
# 	cvsPerl("commit -r STABLE_REV","<file1> <file2> <file...>","Stable files")
# 	cvsPerl("update","<file1> <file2> <file...>")
# 	cvsPerl("update -r RELEASE_REV","<file1> <file2> <file...>")
# 	cvsPerl("delete","<file1> <file2> <file...>")
# 	cvsPerl("add","<file1> <file2> <file...>")
sub cvsPerl() {
	my $action		= shift;
	my $fileList		= shift;
	my $cvsArgs		= "$action";
	my $msg	= join(' ',split(/\s/,@_));
	my $cvsCmd		= '/usr/local/tools/bin/sshcvs.sh';
	my $pingReturn	= '';
	my $cvsServer	= '';
#	my $cvsRoot		= '';
	use vars qw( @CVSerr @CVSout );

	$pingReturn		= '';

	if (-x "$cvsCmd") {
		$return			= open QUERY,"$cvsCmd -get server |";
		while (<QUERY>) {
			chomp $_;
			last if eof QUERY;
			$cvsServer		= "$_";
		}
		close QUERY;
		cleanExit($!,"$cvsCmd is out of date")	if ($return or ! $cvsServer);
		undef $return;
#		$return			= open QUERY,"$cvsCmd -get root |";
#		while (<QUERY>) {
#			chomp $_;
#			last if eof QUERY;
#			$cvsRoot		= "$_";
#		}
#		close QUERY;
#		cleanExit($!,"$cvsCmd is out of date. at line ".debugInfo('line',' '))	if ($return or ! $cvsRoot);
#		undef $return;
	} else {
		cleanExit($!,"$!: $cvsCmd");
	}

	# Check to see if the CVS server is responding
	$pingReturn		= pingHost($cvsServer);
	cleanExit($!,"CVS server \"$cvsServer\" is not responding")	if (! $cvsServer);

	# If the script is run in dry-run mode, make sure CVS knows this
	$cvsCmd			.= ' -n'	if ($dry_run);

	# If $quiet is declared, make sure that CVS is quiet
	for ($quiet gt 0) {
		$cvsCmd			.= ' -q'	if ($quiet lt 3);
		$cvsCmd			.= ' -Q'	if ($quiet >= 3);
	}

	for ($action) {
#		$cvsArgs	= "$action -C $fileList"	if /update/;
		$cvsArgs	= "$action -P -C $fileList"	if /update/;
		$cvsArgs	= "$action -P $fileList"	if /checkout/;
		$cvsArgs	= "$action $fileList"	if /add|delete/;
		$cvsArgs	= "$action -m \"$msg\" $fileList"	if /commit/;
	}

	open STDERR,"|";
	while (<STDERR>) {
		push (@CVSerr,$_);
	}
	$return	= open CVS,"$cvsCmd $cvsArgs |";
	while (<CVS>) {
		push (@CVSout,$_);
	}
	close CVS;
	close STDERR;

	return $return;
}

# Cool Rsync functionality
# Usage: rsyncPerl("$sshopts","$addargs","$source","$dest")
# sshopts - example: "ssh -i ~/.ssh/id_dsa_cvskey -T -x"
# sshopts - example: "ssh"
# addargs - example: '-vrx --exclude="bin" --stats --relative'
# source - example: "$host:/app"
# source - example: '/app'
# dest - example: '/'
# dest - example: "$host:/"
# Throw --noexclude or -noexclude into addargs to have rsync not exclude
sub rsyncPerl() {
	warn "$debugPrepend: rsyncPerl(): Begin\n"					if ($DEBUG);	
	my $sshopts		= shift;
	warn "$debugPrepend: sshopts=$sshopts\n"					if ($DEBUG);	
	my $addargs		= shift;
	warn "$debugPrepend: addargs=$addargs\n"					if ($DEBUG);	
	my $source		= shift;
	warn "$debugPrepend: source=$source\n"						if ($DEBUG);	
	my $dest		= shift;
	warn "$debugPrepend: dest=$dest\n"							if ($DEBUG);	
	my $date		= getTimeStamp('file');
	warn "$debugPrepend: date=$date\n"							if ($DEBUG);	
	my $ssh			= '';
	local @return		= ();
	my @split_arg	= ();
	my $dstHost	= '';
	my $host_alive	= '';
	my $fh			= '';

	# let's make ourselves a custom ssh shell script temporarilly
	if ($sshopts !~ /^ssh$/) {
		while ( -f "/tmp/$$.$date.sh") {
			warn "$debugPrepend: Found: /tmp/$$.$date.sh\n"		if ($DEBUG);	
			$date++;
			warn "$debugPrepend: Date changed to: $date\n"		if ($DEBUG);	
		}

		$ssh = "/tmp/$$.$date.sh";
		warn "$debugPrepend: ssh=$ssh\n"						if ($DEBUG);	

		$fh			= &openFile("$ssh",'write');
			print $fh "#!/bin/sh\n";
			if ($sshopts =~ /^ssh\s/) {
				print $fh "$sshopts \$*\n";
			} else {
				print $fh "ssh $sshopts \$*\n";
			}
		&close_file("$fh");

		warn "$debugPrepend: chmod 0700, $ssh\n"				if ($DEBUG);	
		chmod 0700, $ssh;

	} else {
		# If just plain ol' "ssh" was specified then we needn't create a script
		$ssh			= "ssh";
		warn "$debugPrepend: ssh=$ssh\n"						if ($DEBUG);	
	}

	# now let's prepare rsync
	my @defaults	= (
		'--verbose',
		'--temp-dir=/tmp',
		'--checksum',
		'--perms',
		'--group',
		'--times',
		'--whole-file',
		'--exclude="*.sbk"',
		'--exclude="*_log"',
		'--exclude="*_log.*"',
		'--exclude="*.log"',
		'--exclude="*.log.*"',
		'--exclude="*.core"',
		"--rsh=\"$ssh\""
	);

	# If the script is run in dry-run mode, make sure that rsync knows this
	push(@defaults,'--dry-run')									if ($dry_run);

	if ($DEBUG) {														
		foreach (@defaults) {											
			chomp($_);													
			warn "$debugPrepend: rsync option: $_\n";							
		}																
	}																	

	my @user_args	= ("$addargs");
	warn "$debugPrepend: user_args=@user_args\n"				if ($DEBUG);	
	my @rsync_args	= ();

	# Bring the user's args into a list that we can compare against our list
	ARG: foreach (@user_args) {
		chomp($_);
		if (-e "$_") { my $log_file = "$_"; next ARG; }
		if (/--no-ping/) { my $noping = '1'; next ARG; }
		next if /^--noexclude|^-noexclude/;
		push(@rsync_args,$_);
	}
	warn "$debugPrepend: 1: rsync_args=@rsync_args\n"			if ($DEBUG);	

	if ($DEBUG) {														
		warn "$debugPrepend: log_file=$log_file\n";								
		warn "$debugPrepend: noping=$noping\n";									
	}

	# Build the argument list by comparing the user's args against our args
	foreach (@defaults) {
		chomp($_);
		next if ($addargs =~ /--noexclude|-noexclude/ and $_ =~ /^--exclude/);
		push (@rsync_args,$_) if ($addargs !~ /$_/);
	}
	warn "$debugPrepend: 2: rsync_args=@rsync_args\n"			if ($DEBUG);	

	# Push the source and destination host/dir/file into the final arg list
	push(@rsync_args,$source);
	push(@rsync_args,$dest);
	warn "$debugPrepend: 3: rsync_args=@rsync_args\n"			if ($DEBUG);	

	# Get the source/dst hostname and ping it to see if it's alive
	@split_arg	= split(/:/, $source) if ($source =~ /:/);
	@split_arg	= split(/:/, $dest) if ($dest =~ /:/);
	$dstHost	= shift(@split_arg);
	$host_alive	= pingHost($dstHost,'3')				if (! $noping);

	@return			= "Ping of host '$dstHost' failed.  Skipping $dstHost." if (! $host_alive && ! $noping);
	if ($log_file) {
		warn "$debugPrepend: exec: rsync @rsync_args\n"			if ($DEBUG);	
		open LOG,"rsync @rsync_args |" if ($host_alive);
		my $fh = &openFile("$log_file",'write');
		while (<LOG>) {
			print $fh "$_";
		}
		&close_file("$fh");
		close LOG;
	} else {
		system "rsync @rsync_args" if ($host_alive);
	}

	if ( -f "$ssh") {
		system "rm -f $ssh";
	}

	warn "$debugPrepend: return=@return\n"						if ($DEBUG);	
	warn "$debugPrepend: rsyncPerl(): End\n"					if ($DEBUG);	
	return @return;

}

# Pings given host with given timeout, returns true on sucess and false
# on failure.
sub pingHost {
	warn "$debugPrepend: pingHost(): Begin\n"					if ($DEBUG);	
    my $dstHost	= shift;
	warn "$debugPrepend: dstHost=$dstHost\n"					if ($DEBUG);	
	my $timeout		= shift;

	$timeout	= 5	if (! $timeout);
	warn "$debugPrepend: timeout=$timeout\n"					if ($DEBUG);	
   
	use IO::Socket::INET;
    my $return		= IO::Socket::INET->new(
						PeerAddr => $dstHost,
						PeerPort => '22',
						Proto    => 'tcp',
						Timeout  => $timeout,
						Type     => SOCK_STREAM
					);

	warn "$debugPrepend: return=$return\n"						if ($DEBUG);	
	warn "$debugPrepend: pingHost(): End\n"					if ($DEBUG);	
    return $return;
}

# Now if I could just write something that would do the dishes.  Man, that
# would be great!
# use French::Maid;
# $count	= 0;
# $deadline	= 10	if (! int($deadline));
# while (@dirtyDishes) {
# 	if (/clean/) { push(@cabinet,$_); next; }
# 	flog(maid($0))	if ($count > $deadline);
# 	scrub($_);
# 	$count++;
# }

# Returns the name of the constant that matches the given integer.  This
# function works in a first-match-wins method, where if there happens to
# be more than one constant name for the same integer, the return will
# be the first matching name.  This is why you should keep humorous
# constants at the bottom of the constants file.
sub getConstNameByNum() {
	my $number		= shift;
	my $file		= shift;
	my @splitLine	= ();
	my $fileHandle	= '';
	my $return		= '';

	$file		= "$Bin/../lib/TableOfConstants"	if (! $file);
	$fileHandle	= openFile($file);
	while (<$fileHandle>) {
		next if /^\s|^\t|^#/;
		next if !/^.*\t$number;$/;
		chomp;
		@splitLine		= split (/\s/, $_);
		while ($splitLine[0] =~ /use|constant/) {
			shift (@splitLine);
		}
		$return		= shift (@splitLine);
		last;
	}
	closeFile($fileHandle);

	$return		= 'UNHANDLED EXCEPTION';
	return $return;
}

# Returns the output of `hostname` or `hostname --fqdn`
sub getHostByHostname() {
	my $type		= shift;
	my $return		= '';

	if ($type =~ /^fqdn$/)
	{ $return		= `hostname --fqdn`; }
	else
	{ $return		= `hostname`; }
	chomp($return);

	return $return;
}

sub cleanExit() {
	my $exit		= shift;
	my $string		= shift;
	my $return		= '';
	my $index		= 0;
	my $elem		= '';

	for ($string)
	{
		last if /^$/;
		$string			.= " at ";
		$string			.= debugInfo('filename','1','base');
		$string			.= " line ";
		$string			.= debugInfo('line','1');
		$string			.= "\n" if !/\n$/;
	}
	print { STDERR } "$string"	if ($string);

	use vars qw( @openHandles $stopFile $lockFile );

	for $index ( 0 .. $#openHandles )
	{
		$elem		= $openHandles[$index];
		$return		= '';
		warn "$debugPrepend Closing filehandle: $elem\n"	if ($DEBUG);
		$return		= closeFile($elem);
		warn "Could not close filehandle: $elem"	if ($return != 1);
		delete $openHandles[$index] if ($openHandles[$index] =~ /^$elem$/);
	}

	undef $return	if ($return == 1);

	if ($stopFile and -e $stopFile)
	{
		warn "$debugPrepend Removing file: $stopFile\n"	if ($DEBUG);
		$return		+= unlink $stopFile;
	}

	if ($lockFile and -e $lockFile)
	{
		warn "$debugPrepend Removing file: $lockFile\n"	if ($DEBUG);
		$return		+= unlink $lockFile;
	}

	foreach (@openDirs)
	{
		undef $return;
		chomp $_;
		$return		= closedir $_	if <$_>;
		$exit		= $return	if ($return);
		warn "$exit: Could not close directory handle: $_"	if ($exit);
	}

	exit $exit;
}

return 1;
