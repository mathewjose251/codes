package SiteBuild;
use strict;
use lib "/www/stotch/lib";
#require "libparse.pl";

use vars qw(
	$config_file
	@ISA
	@EXPORT_OK
	@EXPORT
	$VERSION
	$DEBUG
);

$DEBUG			= '[DEBUG]';
$config_file	= "/www/stotch/etc/stotch.conf";

require Exporter;
@ISA			= qw(Exporter);
$VERSION		= '0.01';
@EXPORT_OK		= qw(
	new
);

sub new {
	warn "$DEBUG _=@_\n"								if ($DEBUG);	#DEBUG
	my $pkg			= shift;
	$pkg			= ref($pkg) || $pkg;
	unless ($pkg) {
		$pkg			= "SiteBuild";
	}
	my %params		= ();
	$params{'type'}	= shift;
	my $object		= {};
	bless $object,$pkg;
	$object			= "$params{'type'}";

	return $object;
}

sub pageData {
	my $return		= '';
	my $ref			= shift;
}

sub getLinks {
	my $return		= '';
	my $ref			= shift;
	my $file		= "$ref";
	my %links		= ();
	my @content		= ();
	my @link		= ();

	open FILE, "$file" or die "Could not open $file: $!\n";
	@content		= <FILE>;
	close FILE;
	foreach (@content) {
		chomp;
		@link				= split(/\^/, $_);
		$links{$link[1]}	= "$link[0]";
	}

	return %links;
}
