#!/usr/bin/perl

warn "BEGIN: libglobal.pl\n"							if ($DEBUG);	#DEBUG

use lib			"/www/stotch/lib";
use CGI			qw/:standard :html4 :html3 :netscape :cgi/;
use CGI::Carp	qw(fatalsToBrowser);
use CGI::Pretty;
use POSIX;

require			"libparse.pl";
require			"libprint.pl";
require			"libauth.pl";

use vars qw(
	$www_base
	$www_home
	$www_data
	$www_etc
	$www_lib
	$www_bin
	$www_tpl
	$links_file
	$mastr_tpl
	$mastr_css
	$auth_file
	$headr_file
	$footr_file
);

package site;
sub new {
	my $ref			= {};
	bless $ref;
	return $ref;
}

sub config {
	my $ref			= shift;
	my %config		= parseConfig($
our $www_base		= "stotch";
our $www_home		= "/www/$www_base";
our $www_data		= "$www_home/data";
our $www_etc		= "$www_home/etc";
our $www_lib		= "$www_home/lib";
our $www_bin		= "$www_home/bin";
our $www_tpl		= "$www_home/tpl";
our $links_file		= "$www_data/links.data";
our $mastr_tpl		= "$www_tpl/master.tpl";
our $mastr_css		= "$www_etc/master.css";
our $auth_file		= "$www_data/private/auth.data";
our $headr_file		= "$www_data/header.data";
our $footr_file		= "$www_data/footer.data";

warn "END: libglobal.pl\n" if ($DEBUG);

return 1;
