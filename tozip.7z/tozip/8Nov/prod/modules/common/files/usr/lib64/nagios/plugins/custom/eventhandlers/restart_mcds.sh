#!/bin/bash
# 
# Program       : restart_mcds.sh
# Author        : Lane Davis 2/2017
# Description   : This script is called by the eh-restart_mcds eventhandler
#

CMD="/sbin/service aztec synchronizer-restart"
TAIL="/usr/bin/tail"

if [ -e /usr/bin/sudo ]
then
	SUDO=/usr/bin/sudo
else
	SUDO=/usr/local/bin/sudo
fi


MSG=`$SUDO $CMD | $TAIL -1`

echo "$MSG"
exit 0
