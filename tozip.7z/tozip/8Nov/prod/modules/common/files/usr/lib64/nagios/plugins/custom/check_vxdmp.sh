#!/bin/bash 

#
# the quintessential down-and-dirty nagios check for vxdmp dual path status
#

# I take two args , both mandatory.  
# 1. enclosure name, such as "tagmastore-usp0" or "Disk"
#  that completely depends on your target system and array, etc..
# 2. exclude string, 
#  The exclude string, such as 'sdb' is the arg for grep -v <arg> so you
#  may exclude a target which vxdmpadm will report on your enclosure, but
#  for which you either do not want to check, for example 'sdb' on linux.
#  because it will never have two paths on sdb but it is on the same enclosure
#  name, ( argument 1 ) so need to exclude it. 
#  If you have nothing to exclue, just use 'nothing' as this argument.


PATH=$PATH:/usr/bin:/usr/local/bin  # this is to find sudo 

VXDMPADM=/sbin/vxdmpadm

exit_err() {

  echo "CRITICAL: Unkown Error Occured $*"
  exit 255
}

trap exit_err 1 2 3 15

enclosure=$1
exclude=$2


if [ $# -ne 2 ];then
  echo
  echo "Usage: $0 <enclosure name> <exclude string>"
  echo
  echo " There can be no metachars like pipe signs in the exclude string."
  echo
  exit 2
fi

sudo $VXDMPADM listctlr all >/dev/null || exit_err "vxdmpadm command failed: $VXDMPADM"  

CMD="sudo $VXDMPADM getdmpnode enclosure=$enclosure"

$CMD >/dev/null || exit_err "vxdmpadm failed with `$CMD 2>&1`"

$CMD | sed '1,2d' | grep -v ^${exclude} | awk '$4!=2 || $5 !=2 || $6!=0 {badlun=$0;bad=1; }END{if(bad == 1 ) {print "CRITICAL: Not All Paths are 2 !! ",$0;exit 2;} else { print "OK: "NR," paths OK";}}'
