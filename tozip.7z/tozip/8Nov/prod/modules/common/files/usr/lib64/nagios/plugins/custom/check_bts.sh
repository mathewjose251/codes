#!/bin/bash
# check_bts.sh - By: Beam Davis (Beam_Davis@symantec.com)            (08/25/10)
# Nagios plugin.
#
# Usage: check_bts.sh <Host Name>[:<Port Number>] <Threshold>
#        check_bts.sh [-h, --help|-v, --version]
#
# This plugin checks STAT's returned from BTS, on port 9000 by default.  It
# always performs the following checks:
#
# Run time - last_workload_request_time <= <Threshold> then OK else CRITICAL
# Run time - last_workload_result_time  <= <Threshold> tnen OK else CRITICAL
#
# Exit Statuses:
#
#  0 = Normal
#  1 = Invalid or missing command line argument
# 10 = -h or -v argument specified on command line
#
# Major Revision History:
#
# 08/25/10 -	First production version.
#
# Includes.
#
. /usr/lib/nagios/plugins/utils.sh
#
# Subroutines.
#
execerrmsg() {
# Usage: execerrmsg <Message> [-F]
#
# -F =	Fatal error message
	echo -e "$strname: $(if [ "$2" = "-F" ];then echo "FATAL ";fi)ERROR: $1" 1>&2
}
execinvarg() {
# Usage: execinvarg
	execerrmsg "Invalid or missing command line argument." -F
	exit $STATE_UNKNOWN
}
execusage() {
# Usage: execusage
	cat <<EOM
Usage: $strname <Host Name>[:<Port Number>] <Threshold>
       $(echo "$strname" |/usr/bin/tr "[:print:]" " ") [-h, --help|-v, --version]

This plugin checks STAT's returned from BTS, on port 9000 by default.  It
always performs the following checks:

Run time - last_workload_request_time <= <Threshold> then OK else CRITICAL
Run time - last_workload_result_time  <= <Threshold> tnen OK else CRITICAL
EOM
}
execverinfo() {
# Usage: execverinfo
	echo "$strname - By: Beam Davis (Beam_Davis@symantec.com)$(echo -n "                          "|/bin/dd bs=1 count=$((26-${#strname})) 2>/dev/null)($strverdate)"
}
#
# Declairations.
#
typeset -i intexit
typeset -i inthits=-1
typeset -i intinvvalue
typeset -i intoldrtreq
typeset -i intoldrtres
typeset -i intport=-1
typeset -i intreqOK
typeset -i intresOK
typeset -i intthold=-1
typeset -i inttime
typeset -i inttimeout
#
# Constants.
#
typeset -i FALSE=0
typeset -i TRUE=1
typeset -i intruntime=`/bin/date +%s`
strIFSsave="$IFS"
strmatch1="last_workload_request_time"
strmatch2="last_workload_result_time"
strname="$(/bin/basename "$0")"
strNL="
"
strverdate="08/25/10"
#
# Initializations.
#
intinvvalue=FALSE
intoldrtreq=FALSE
intoldrtres=FALSE
intreqOK=FALSE
intresOK=FALSE
inttimeout=FALSE
unset strmsg
unset strmsgOK
#
# Main routine.
#
case "$*" in
	-h|--help)	execusage
			exit $STATE_OK;;
	-v|--version)	execverinfo
			exit $STATE_OK;;
esac
if [ -z "$2" ] || [ -n "$3" ]
then
	execinvarg
fi
let intthold="$2"
if [ $intthold -lt 0 ]
then
	execinvarg
fi
IFS=":"
set -- $1
if [ -n "$3" ]
then
	execinvarg
fi
strhost="$1"
if [ -z "$2" ]
then
	intport=9000
else
	let intport="$2"
	if [ $intport -lt 1 ]
	then
		execinvarg
	fi
fi
IFS="$strNL"
for strin in `/usr/lib/nagios/plugins/check_tcp -H $strhost -p $intport -s "STATS" -q "END" -w 30 -c 30`
do
	if [ $? != 0 ]
	then
		inttimeout=TRUE
		break
	fi
	IFS="$strIFSsave"
	set -- $strin
	IFS="$strNL"
	if [ "$1" = "TCP" ]
	then
		strmsgOK="$(echo "$strin" |/bin/cut -d[ -f1)"
		strmsgOK="$(echo "$strmsgOK" |/bin/cut -c1-$((${#strmsgOK}-1)))"
	elif [ "$1" = "STAT" ]
	then
		if [ "$2" = "$strmatch1" ] || [ "$2" = "$strmatch2" ]
		then
			intvalue=-1
			let intvalue="$(echo "$3" |/bin/cut -c1-$((${#3}-1)))"
			if [ $intvalue -lt 0 ]
			then
				intinvvalue=TRUE
				break
			fi
			if [ $intruntime -lt $intvalue ]
			then
				if [ "$2" = "$strmatch1" ]
				then
					intoldrtreq=TRUE
				else
					intoldrtres=TRUE
				fi
			else
				inttime=intruntime-intvalue
				if [ $inttime -le $intthold ]
				then
					if [ "$2" = "$strmatch1" ]
					then
						intreqOK=TRUE
					else
						intresOK=TRUE
					fi
				fi
			fi
		fi
	fi
done
if [ -z "$strmsgOK" ]
then
	echo "UNKNOWN - No response time returned from BTS"
	intexit=$STATE_UNKNOWN
elif [ $intinvvalue = $TRUE ]
then
	echo "UNKNOWN - Positive numerical value expected"
	intexit=$STATE_UNKNOWN
elif [ $intoldrtreq = $TRUE ] || [ $intoldrtres = $TRUE ]
then
	if [ $intoldrtreq = $TRUE ]
	then
		strmsg="$strmatch1"
	fi
	if [ $intoldrtres = $TRUE ]
	then
		if [ -z "$strmsg" ]
		then
			strmsg="$strmatch2"
		else
			strmsg="$strmsg and $strmatch2"
		fi
	fi
	echo "WARNING - Run time is less than $strmsg"
	intexit=$STATE_WARNING
elif [ $inttimeout = $TRUE ]
then
	echo "CRITICAL - Timeout connecting to host \"$strhost\" on port $intport!"
	intexit=$STATE_CRITICAL
elif [ $intreqOK = $FALSE ] || [ $intresOK = $FALSE ]
then
	if [ $intreqOK = $FALSE ]
	then
		strmsg="$strmatch1"
	fi
	if [ $intresOK = $FALSE ]
	then
		if [ -z "$strmsg" ]
		then
			strmsg="$strmatch2"
		else
			strmsg="$strmsg and $strmatch2"
		fi
	fi
	if [ $intreqOK = $FALSE ] && [ $intresOK = $FALSE ]
	then
		strmsg="$strmsg times"
	else
		strmsg="$strmsg time"
	fi
	echo "CRITICAL - BTS $strmsg NOT within threshold!"
	intexit=$STATE_CRITICAL
else
	echo "$strmsgOK"
	intexit=$STATE_OK
fi
exit $intexit


# # #  End of check_bts.sh  # # #

