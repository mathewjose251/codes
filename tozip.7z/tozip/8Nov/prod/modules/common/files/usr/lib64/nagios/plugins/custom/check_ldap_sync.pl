#!/usr/bin/perl

=head1 NAME

check_ldap_sync.pl - Nagios plugin that checks LDAP sync replication

=head1 SYNOPSIS

    check_ldap_sync.pl [-c critical] [-w warning] master:slave[:slave...]

=head1 DESCRIPTION

This script is a nagios plugin that checks the internal CSN (Change Sequence Number)
of an LDAP master and slave(s).  The script can be run with parameters that specify
how many seconds a slave must be out of synchronization with the master in order to
generate a critical (given with C<-c seconds>) nagios alert.  The default critical
threshold setting is 30 minutes.  A nagios warning, by default, is calculated to be
80 percent of the critical setting; this may be directly overriden with the C<-w>
command line switch.

At least one master and one slave must be specified on the command line.

=head1 CREDENTIALS

This script uses the DN C<uid=ldapproxy,ou=people,dc=brightmail,dc=com> for the primary
credentials when authenticating with the master and all slaves, respectively.  If different
credentials are required this necessitates code changes to this script.  Note that the
password is encoded not strictly as a security measure but just as a layer of obfuscation
to prevent it from being cleartext.  The password can be computed using:

    S<perl -we 'print(pack "u" => "password")'>

=begin RCS

    $Id: check_ldap_sync.pl,v 1.1 2018/10/30 10:12:01 mathew Exp $

=end RCS

=cut

use strict;
use warnings;

use Net::LDAP;
use File::Basename;
use Getopt::Long;

##
## Default username to bind to LDAP with
use constant DEFAULT_USERNAME	    => 'ldapproxy';

##
## Encoded to prevent "naked-password" syndrome
use constant DEFAULT_PASSWORD	    => '&<V5C<F5T';

##
## Default "critical" level, 30 minutes, warning is calculated at 80% of this
use constant DEFAULT_CRITICAL	    => 1800;
use constant DEFAULT_WARNING_PCT    => 80;

##
## These are const values for nagios status lines
use constant OK			    => [ 0, "OK"       ];
use constant WARN		    => [ 1, "WARNING"  ];
use constant CRIT		    => [ 2, "CRITICAL" ];
use constant UNKN		    => [ 3, "UNKNOWN"  ];

my ( $critical, $warning );

MAIN: {
    GetOptions("c=i", \$critical, "w=i", \$warning);
    $critical ||= DEFAULT_CRITICAL;
    $warning  ||= int( $critical * ( DEFAULT_WARNING_PCT / 100 ) );

    bail(UNKN, "Malformed command-line: Usage: %s [-c critical] [-w warning] master:slave[:slave...]\n", basename($0))
	unless @ARGV;

    bail(UNKN, "Warning threshold (%s) is greater than or equal to critical (%s)\n", $warning, $critical)
	if ($warning >= $critical);

    my ($master, @slaves) = parse_argv( shift(@ARGV) );

    push my @csn_list, get_csn($master);
    bail(CRIT, "Could not retrieve CSN from master (%s)\n", $master) unless defined($csn_list[ 0 ]);

    for my $slave (@slaves) {
	my $csn = get_csn( $slave );
	bail(CRIT, "Could not retrieve CSN from slave (%s)\n", $slave) unless $csn;
	push @csn_list, $csn;
    }

    bail( interpret_results( @csn_list ) );
}

sub interpret_results {
    my @csn_list    = @_;
    my $master      = shift(@csn_list);
    my $level       = OK;
    my $default_msg = "All LDAP servers are in sync";
    my @sync_msgs   = ();

    for my $slave (@csn_list) {
	my ( $slave_level, $skew ) = calc_drift_level($master, $slave);
	next if $slave_level->[0] == OK->[0];

	if ($slave_level->[0] == CRIT->[0]) {
	    $level = CRIT;
	    push @sync_msgs => [
		CRIT->[0],
		sprintf('SLAVE %s is critical (off by %s sec)', $slave->[0], $skew)
	    ];
	}
	elsif ($slave_level->[0] == WARN->[0]) {
	    ##
	    ## Only escalate to warning from OK
	    $level = WARN if $level->[0] < CRIT->[0];
	    push @sync_msgs => [
		WARN->[0],
		sprintf('SLAVE %s (off by %s sec)', $slave->[0], $skew)
	    ];
	}
    }
    ##
    ## Sort the sync messages by CRIT then WARN
    my $sync_msg = join( ', ', map( { $_->[ 1 ] } sort { $b->[ 0 ] <=> $a->[ 0 ] } @sync_msgs ) );
    return($level, $sync_msg || $default_msg);
}

sub calc_drift_level {
    my ($master, $slave) = @_;
    ##
    ## Abstract some of the logic behind determining critical/warning levels.  In the future
    ## we may decide to use the writes/timestamp to determine if the slave is up-to-date with
    ## the master server.
    ##
    my $skew = abs( $master->[ 1 ] - $slave->[ 1 ] );
    return ( CRIT, $skew ) if ($skew >= $critical);
    return ( WARN, $skew ) if ($skew >= $warning);
    return ( OK, $skew );
}

sub get_csn {
    my ($server) = @_;
    my $csn = fetch_csn_attribute($server);
    return unless $csn;
    my ($time, $writes) = split '#', $csn;
    $time   =~ tr/0-9.//cd;
    $writes =~ tr/0-9.//cd;
    return [ $server, $time, $writes ];
}

sub fetch_csn_attribute {
    my ($server) = @_;
    my $lh  = connect_to_ldap( $server, DEFAULT_USERNAME, $ENV{LDAP_PASSWD} || unpack('u*' => DEFAULT_PASSWORD) );
    return unless $lh;
    my $csn = get_contextcsn($lh, 'dc=brightmail,dc=com');
    $lh->unbind;
    $lh->disconnect;
    return $csn;
}

sub parse_argv {
    my ($hostlist) = @_;
    my ($master, @slaves) = split ':', $hostlist;
    return unless $master && @slaves > 0;
    return ( $master, @slaves );
}

sub connect_to_ldap {
    return unless @_ > 2;
    my ($host, $user, $pass) = @_;
    my $ldap = new Net::LDAP( $host );
    return unless $ldap;
    my $dn = sprintf( 'uid=%s,ou=people,dc=brightmail,dc=com', $user );
    $ldap->bind( $dn, password => $pass );
    return $ldap;
}

sub get_contextcsn {
    my ($c_ldap, $c_base) = @_;

    my $c_message = $c_ldap->search(
	base	=>  $c_base,
	scope	=>  'base',
	filter	=>  '(objectclass=*)',
	attrs	=>  [qw(contextCSN)]
    );
    $c_message->code && return $c_message->error;
    my $c_entry = $c_message->entry(0);
    return $c_entry->get_value('contextCSN');
}

sub service_name {
    my $name = shift || $0;
    $name    = File::Basename::basename($name);
    $name    =~ s/\.[^.]*$//;
    $name    =~ tr/ /_/s;
    return uc($name);
}

sub bail {
    my ( $level, @msg ) = @_;
    my $exit_message = as_nagios_str( $level, @msg );
    print STDOUT $exit_message, "\n";
    exit( $level->[ 0 ] );
}

sub as_nagios_str {
    my ( $level, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return sprintf( '%s %s: %s', service_name(), $level->[1], $text );
}

