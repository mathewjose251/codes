#!/bin/bash
#this cutom script is to check the ownership of the directory "/home/oracle/scripts " on bloc-db31.tuc
#if mentioned directory or files under this location ownership got changed to 'root'. this script will let us know to change back.
############ BEGIN ############
DIR=/home/oracle/scripts

lsown=`ls -lrt $DIR|awk ‘$3!=“oracle" || $4!=“dba" {print;}'|wc -l`

if [ "$lsown" -ge "1" ];
then
        echo -e "CRITICAL - Files and/or DIR Ownership got changed in $DIR.Validate and change the ownership ASAP"
        exit 1
else
        echo -e “OK – Ownership looks good."
        exit 0
fi
############ END ############
