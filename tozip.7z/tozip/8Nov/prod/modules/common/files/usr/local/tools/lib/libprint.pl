#!/usr/bin/perl

warn "BEGIN: libprint.pl\n"								if ($DEBUG);	#DEBUG

sub print_header()
	warn "BEGIN: print_header()\n"						if ($DEBUG);	#DEBUG
	use vars qw(
		$cgi
		%DATA
		$headr_file
	);

	if (@_) {
		$headr_file		= shift;
	}

	if ($DATA{'style'}) {
		$mastr_css	= "$DATA{'style'}";
	}

	parse_data("$headr_file") if (-f $headr_file);

	$cgi		-> start_html(
		-title		=> $DATA{'title'},
		-author		=> $DATA{'author'},
		-base		=> $DATA{'base'},
		-target		=> $DATA{'target'},
		-meta		=> {
			'keywords'		=> $DATA{'keywords'},
			'copyright'		=> $DATA{'copyright'},
			'description'	=> $DATA{'description'},
			'pragma'		=> $DATA{'pragma'},
		),
		-style		=> $mastr_css
	);

	warn "END: print_header()\n"						if ($DEBUG);	#DEBUG
	return $cgi;
}

sub print_footer() {
	warn "BEGIN: print_footer()\n" if ($DEBUG);
	use vars qw(
		$CGI
		%DATA
		$footr_file
	);

	if (@_) {
		$footr_file		= shift;
	}

	parse_data("$footer_file") if (-f $footr_file);

	$cgi		-> hr,
	$cgi		-> P(
	foreach ( keys(%DATA) ) {
		"$_"			=> $DATA{$_},
	}
	),
	$cgi		-> end_html;
	warn "END: print_footer()\n" if ($DEBUG);
	return $cgi;
)

sub report_error() {
	warn "BEGIN: report_error()\n" if ($DEBUG);
	$error_string	= shift;
	$error_type		= shift;

	warn "END: report_error()\n" if ($DEBUG);

	return $error_type;
	exit 1;
}

warn "END: libprint.pl\n" if ($DEBUG);
return 1;
