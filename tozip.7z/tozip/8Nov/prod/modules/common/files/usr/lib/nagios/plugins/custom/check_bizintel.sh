#!/bin/bash
#
# $Id: check_bizintel.sh,v 1.1 2018/10/30 10:12:00 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/check_bizintel.sh,v $
#
# Program	: Bizintel plugin for Nagios
# Author	: Geoffrey Gloistein 11/2006
# License	: GPL
# Description	: This plugin checks if the bizintel processes are running.
#

. /usr/lib/nagios/plugins/utils.sh

PROGNAME=`/bin/basename $0`
PROGPATH=`echo $0 | /bin/sed -e 's,[\\/][^\\/][^\\/]*$,,'`
REVISION=`echo '$Revision: 1.1 $' | /bin/sed -e 's/[^0-9.]//g'`
LOG_THOLD=60;

print_usage() {
        echo "Usage:"
        echo " $0 "
        echo " $0 (-V | --version)"
        echo " $0 (-h | --help)"
}

print_help() {
    print_revision $PROGNAME $REVISION
    echo ""
    print_usage
    echo ""
    echo "This plugin checks if bizintel is running."
    echo ""
    support
}

exitstatus=$STATE_UNKNOWN

while test -n "$1"; do
    case "$1" in
        --help)
            print_help
            exit $STATE_OK
            ;;
        -h)
            print_help
            exit $STATE_OK
            ;;
        --version)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        -V)
            print_revision $PROGNAME $VERSION
            exit $STATE_OK
            ;;
        *)
            echo "Unknown argument: $1"
            print_usage
            exit $STATE_UNKNOWN
            ;;
    esac
    shift
done

#bizintel_procs="mail_spool_processor.pl url_monk.pl despooler.pl"
bizintel_procs="mail_fetcher.pl url_extractor.pl scenario_runner.pl rule_uploader.pl"
#bizintel_logs="/var/log/bizintel/mail_spool_processor.log /var/log/bizintel/url_monk.log /var/log/bizintel/despooler.log"
bizintel_logs="/var/log/bizintel/biz_latency"

for proc in `echo $bizintel_procs`
do
    if [[ ! `ps ho pid -C $proc` ]]
    then
	not_running="$not_running $proc"
    fi
done

for log in `echo $bizintel_logs`
do
    if [[ `find $log -mmin +$LOG_THOLD` ]]
    then
	not_changed="$not_changed $log"
    fi
done

# Finally Inform Nagios of what we found...
if [ "$not_running" ]
then
	echo "CRITICAL -$not_running not running!"
	exitstatus=$STATE_CRITICAL
elif [ "$not_changed" ]
then
	echo "CRITICAL - $not_changed not been updated for over $LOG_THOLD minutes!"
	exitstatus=$STATE_CRITICAL
else
	echo "OK - bizintel processes are running and all log files have been updated in the last $LOG_THOLD minutes."
	exitstatus=$STATE_OK
fi

exit $exitstatus
