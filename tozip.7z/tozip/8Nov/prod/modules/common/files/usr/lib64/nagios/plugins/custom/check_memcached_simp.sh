#!/bin/bash
# check_memcached_simp.sh - By: Beam Davis (Beam_Davis@symantec.com) (07/20/10)
# Nagios plugin.
#
# Usage: check_memcached_simp.sh <Host Name>[:<Port Number>] <Threshold>
#        check_memcached_simp.sh [-h, --help|-v, --version]
#
# This plugin checks to see if the memcached is running and has a "get_hits" of
# at least <Threshold>.
#
# Exit Statuses:
#
#  0 = Normal
#  1 = Invalid or missing command line argument
# 10 = -h or -v argument specified on command line
#
# Major Revision History:
#
# 07/20/10 -	Forced OK if 0 hits are returned.
# 03/24/10 -	First production version.
#
# Includes.
#
. /usr/lib/nagios/plugins/utils.sh
#
# Subroutines.
#
execerrmsg() {
# Usage: execerrmsg <Message> [-F]
#
# -F =	Fatal error message
	echo -e "$strname: $(if [ "$2" = "-F" ];then echo "FATAL ";fi)ERROR: $1" 1>&2
}
execinvarg() {
# Usage: execinvarg
	execerrmsg "Invalid or missing command line argument." -F
	exit $STATE_UNKNOWN
}
execusage() {
# Usage: execusage
	cat <<EOM
Usage: $strname <Host Name>[:<Port Number>] <Threshold>
       $(echo "$strname" |tr [:print:] " ") [-h, --help|-v, --version]

This plugin checks to see if the memcached is running and has a "get_hits" of
at least <Threshold>.
EOM
}
execverinfo() {
# Usage: execverinfo
	echo "$strname - By: Beam Davis (Beam_Davis@symantec.com)$(echo -n "                          "|dd bs=1 count=$((26-${#strname})) 2>/dev/null)($strverdate)"
}
#
# Declairations.
#
typeset -i inthits=-1
typeset -i intOK
typeset -i intthold=-1
#
# Constants.
#
typeset -i FALSE=0
typeset -i TRUE=1
strname="$(/bin/basename "$0")"
strverdate="07/20/10"
#
# Initializations.
#
intOK=FALSE
#
# Main routine.
#
case "$*" in
	-h|--help)	execusage
			exit $STATE_OK;;
	-v|--version)	execverinfo
			exit $STATE_OK;;
esac
if [ -z "$2" ] || [ -n "$3" ]
then
	execinvarg
fi
let intthold="$2"
if [ $intthold -lt 0 ]
then
	execinvarg
fi
strgethits="`/usr/bin/memcached-tool $1 stats |awk '/^  *get_hits / {print $2}' |tr -d '\r'`"
if [ -n "$strgethits" ]
then
	let inthits=$strgethits
	if [ $inthits -ge $intthold ] || [ $inthits = 0 ]
	then
		intOK=TRUE
	fi
fi
if [ $intOK = $TRUE ]
then
	echo "OK - memcached is running"
	exit $STATE_OK
else
	echo "CRITICAL - memcached not running!"
	exit $STATE_CRITICAL
fi


# # #  End of check_memcached_simp.sh  # # #

