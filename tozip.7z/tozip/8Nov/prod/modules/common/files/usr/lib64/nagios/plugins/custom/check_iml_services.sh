#!/bin/bash
# check_iml_services.sh - By: Beam Davis (Beam_Davis@symantec.com)   (02/09/10)
# Nagios plugin.
#
# Usage: check_iml_services.sh [-h, --help|-v, --version]
#
# This plugin checks to see if IML services are running.  They are:
#
# RTTPS.MaintenanceService
# ThreatAnalyzerService
# YIMStatsProcessingSvc
#
# Exit Statuses:
#
#  0 = Normal
#  1 = Invalid or missing command line argument
#  3 = Interrupt
# 10 = -h or -v argument specified on command line
#
# Major Revision History:
#
# 02/09/10 -	First test version.
#
# Includes.
#
. /usr/lib/nagios/plugins/utils.sh
#
# Subroutines.
#
execerrmsg() {
# Usage: execerrmsg <Message> [-F]
#
# -F =	Fatal error message
	echo -e "$strname: $(if [ "$2" = "-F" ];then echo "FATAL ";fi)ERROR: $1" 1>&2
}
execinvarg() {
# Usage: execinvarg
	execerrmsg "Invalid or missing command line argument." -F
	exit $STATE_UNKNOWN
}
execusage() {
# Usage: execusage
	cat <<EOM
Usage: $strname [-h, --help|-v, --version]

This plugin checks to see if IML services are running.  They are:

RTTPS.MaintenanceService
ThreatAnalyzerService
YIMStatsProcessingSvc
EOM
}
execverinfo() {
# Usage: execverinfo
	echo "$strname - By: Beam Davis (Beam_Davis@symantec.com)$(echo -n "                          "|dd bs=1 count=$((26-${#strname})) 2>/dev/null)($strverdate)"
}
#
# Declairations.
#
#
# Constants.
#
typeset -i FALSE=0
typeset -i TRUE=1
strname="$(/bin/basename "$0")"
strverdate="02/09/10"
#
# Initializations.
#
unset strnr
#
# Main routine.
#
case "$*" in
	"")		:;;
	-h|--help)	execusage
			exit $STATE_OK;;
	-v|--version)	execverinfo
			exit $STATE_OK;;
	*)		execinvarg;;
esac
for strproc in RTTPS.MaintenanceService ThreatAnalyzerService YIMStatsProcessingSvc
do
	if [ "`/cygdrive/c/WINDOWS/system32/sc query $strproc |awk '/^  *STATE  *: / {print $3}'`" != "4" ]
	then
		strnr="$strnr $strproc"
	fi
done
if [ -z "$strnr" ]
then
	echo "OK - IML services are running"
	exit $STATE_OK
else
	echo "CRITICAL -$strnr not running!"
	exit $STATE_CRITICAL
fi


# # #  End of check_iml_services.sh  # # #

