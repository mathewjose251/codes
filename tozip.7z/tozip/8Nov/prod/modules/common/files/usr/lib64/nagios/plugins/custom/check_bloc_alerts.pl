#!/opt/blocperl/bin/perl  -I /space/orabloc/lib/perl5

use DBI;
use constant BLOC_CONF => "/space/orabloc/server/conf/bloc-config";

my $debug=0;
my ($FH,$t1,$t2,$i,$e,$s);
my $sleeptime=120;
my (@qry,@legend,@rv);
$ENV{'ORACLE_HOME'}='/u01/app/oracle/product/8.1.7';
$ENV{'LD_LIBRARY_PATH'}='/u01/app/oracle/product/8.1.7/lib';

$| = 1;

my ($arg ,$aref,$val,$t,%arg,$key);

# size in K
my $RCMDFILE='/var/tmp/bloc-alert.log';
my %args;
my %argkeys = ( 'd','debug','t', 'sleeptime', 's', 'size', 'c', 'critical', 'w', 'warn', 'sdir', 'sourcedir', 'tdir', 'targetdir');
my %settings;

if (@ARGV < 1 ) { 
  &usage_fn;
  exit;
}

$aref= get_args(@ARGV);

%settings=%{$aref};

my ($db_sid, $db_user, $db_pass);
($db_sid, $db_user, $db_pass) = get_conf_settings( BLOC_CONF );

@legend = ('Attacks','Age');

@qry = get_qry_arr();


$db_pass || die "could not find db passwd\n";


@rv = &runcmd(\%settings);

($e,$s) = &report(@rv);

print $s,"\n";
exit $e;

sub runcmd() {

  my (@arr,@rv,$a);
  my $debug=$settings{debug};
  CHECK_ALERT: {
    $i=0;
    $t0=time;
    if($debug) {
      print "settings{warn} = $settings{warn}, settings{critical} = $settings{critical}\n"; 
    }
    my $uspec = sprintf('%s@%s', $db_user, $db_sid);
    if (  my $dbh = DBI->connect('dbi:Oracle:', $uspec, $db_pass, { RaiseError => 0, AutoCommit => 0 }) ) {
      $t1=time;
      $debug && print time, "Connect SUCCESS took ",$t1-$t0," seconds\n";
      $i=0;
      foreach $qry (@qry) {
        my $sth = $dbh->prepare($qry);
        $sth->execute();
        @arr=$sth->fetchrow_array; #_array;
        $rv[$i] =  $arr[0];
        $debug && print "returned @arr, $rv[$i]\n"; 
        $sth->finish();
        $debug && print time, " Query SUCCESS took ",$t1-$t0," seconds\n";
        $i++;
      }    
      $dbh->disconnect;
    } else
    {
      $t1=time;
      print time, " FAILURE took ",$t1-$t0," seconds\n";
      $debug && print `traceroute bloc-db.brightmail.com`;
    } 
    # sleep $sleeptime;
  }
  return(@rv);
}

sub report() {
  my @rv = @_;
  my $retval =0;
  my $message;
  my $messageall;
  my ( @warr,@carr );

  for($i=0;$i<2;$i++) { #$legend) { 
        $messageall.= "$legend[$i]:".$rv[$i]." ";
  }

  my $tstr = &get_tstr;
  open($LOG,">>$RCMDFILE") || die "could not open $RCMDFILE for append\n";
  print $LOG $tstr," ",$messageall,"\n";
  close $LOG;

  @warr=split(/,/,$settings{warn});
  @carr=split(/,/,$settings{critical});
  $i=0;
  if ( $rv[0] < $carr[0] ) {
    $message="CRITICAL: $rv[0] $legend[0] is less than $carr[0] ";
    $retval=2;
  }
  if ( $rv[1] > $carr[1] )  {
    $message.="CRITICAL: $rv[1] $legend[1] is more than $carr[1] ";
    $retval=2;
  }
  if ( $retval ) {
    return($retval,$message." ".$messageall);
  }
  if ( $rv[0] < $warr[0] ) {
    $message="WARNING: $rv[0] $legend[0] is less than $warr[0] ";
    $retval=1;
  }
  if ( $rv[1] > $warr[1] ) {
    $message.="WARNING: $rv[1] $legend[1] is more than $warr[1] ";
    $retval=1;
  }
  if ( $retval ) {
    return($retval,$message." ".$messageall);
  }
  $message = "OK: ";
    return($retval,$message." ".$messageall);
}

sub usage_fn() {
  print "Usage: $0 <args>";
  print "\n\nExample\n\n";
  print "./check_bloc_alerts.pl -w 1050,720 -c 850,840 -d 1\n";
}
sub get_args {
  my @arr = @_;
  my @tarr = @_;
  my %args;

  foreach $arg ( @arr ) {
    if ($arg=~s/^-(\S+)/$1/) {
      $args{$arg} = $tarr[1];
      #print "args{$arg}=$args{$arg}\n";
    }
  shift @tarr;
  }

  foreach $key ( keys %args ) {
      #print "arg{$key}=$args{$key}\n";
      $settings{$argkeys{$key}} = $args{$key};
   }
  return(\%settings);
}

sub get_qry_arr {
  my @qry;
  $qry[0] = "SELECT COUNT(*) FROM alert_page
  WHERE  status=pkg_const.AlertStatusVisible
  AND    last_seen >=
pkg_tools.date_from_number(pkg_tools.number_from_date(pkg_tools.get_gmt_time())
- pkg_tools.get_bloc_config('alert_page_oldest_attack'))
  AND    (uncaught_message_count > 1
          OR fraud_review_verdict=pkg_const.DragnetReviewVerdictFraud
          OR (fraud_review_verdict IS NULL AND maybe_dragnet=1))";

  $qry[1] = "SELECT MIN(pkg_tools.number_from_date(pkg_tools.get_gmt_time()) - 
           pkg_tools.number_from_date(last_seen)) AS age
  FROM alert_page
 WHERE status=pkg_const.AlertStatusVisible
   AND last_seen >=
pkg_tools.date_from_number(pkg_tools.number_from_date(pkg_tools.get_gmt_time())
- pkg_tools.get_bloc_config('alert_page_oldest_attack'))
   AND (uncaught_message_count > 1
    OR fraud_review_verdict=pkg_const.DragnetReviewVerdictFraud
    OR (fraud_review_verdict IS NULL
        AND maybe_dragnet=1))";
  return(@qry);
}

sub get_tstr {

  my @a=localtime; return(sprintf("%d %02d %02d %02d %02d",$a[5]+1900,$a[4]+1,$a[3],$a[2],$a[1]));

}

sub get_conf_settings {
    my ($cfile) = @_;
    return unless ( $cfile && -f $cfile );

    my (%conf);
    {
        local *ARGV;
        @ARGV = ( $cfile );
        my @conf = <>;
        chomp(@conf);
        %conf = map { /(\S+)\s*=\s*(.*)/ } @conf;
    };

    my ($db_sid, $db_user, $db_pass) = @conf{qw( db_sid db_username db_password )};
    
    die(
        sprintf(
            "Couldn't parse the db_password from the BLOC configuration file '%s'\n",
            $cfile,
        )
    ) unless $db_pass;

    return ($db_sid || 'bloc', $db_user || 'blt', $db_pass);
}

