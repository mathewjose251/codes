#!/usr/bin/perl

use strict;
use warnings;

use File::Basename qw(basename);
use Getopt::Long;
use Pod::Usage;
use IO::Handle;

=pod

=head1 NAME

check_mpxio.pl - Nagios check for Solaris SENA Sun Fire MultiPlex I/O

=head1 SYNOPSIS

check_mpxio.pl [--help] [c]controller-id [s]partition

=head1 DESCRIPTION

This nagios check examines the Sun Fire storage for the specified controller and slice and
creates alerts if any of the disks report a state of anything except C<ONLINE> or C<STANDBY>.

=head1 OPTIONS

Examplex:

B<check_mpxio.pl> c17 s2

B<check_mpxio.pl> 16 2

=cut

##
## These are const values for nagios status lines
use constant OK          => [ 0, "OK" ];
use constant WARN        => [ 1, "WARNING" ];
use constant CRIT        => [ 2, "CRITICAL" ];
use constant UNKN        => [ 3, "UNKNOWN" ];

use constant PATH_LUXADM => "/usr/sbin/luxadm";

my ($luxadm);

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub evaluate_request {
    my ( $results ) = @_;

    my $exitval     = OK;
    my $exitmsg     = '';
    my @exitents    = ();
    my $ok_exitmsg  = "All storage is online or in standby.";

    ##
    ## Checkizzle shizzle
    for my $disk (sort keys %{ $results }) {
        for my $controller (sort keys %{ $results->{$disk} }) {
            my $state = $results->{$disk}->{$controller};
            if ( $state !~ /^(?:ONLINE|STANDBY)$/i ) {
                $exitval  = CRIT;
                $exitmsg .= sprintf("disk=%s controller=%s status=%s; ",
                    $disk, $controller, $state);
            }
        }
    }

    return ( OK->[0], as_nagios_str( OK->[1], $ok_exitmsg ) )
        if ( $exitval->[0] == OK->[0] );

    $exitmsg =~ s/;\s+$/./;

    return ( $exitval->[0], as_nagios_str( $exitval->[1], $exitmsg ) );
}

sub perform_service_check {
    my ($controller, $partition) = @_;
    my (%results) = ();

    $controller =~ s/^c//i if $controller;
    $partition  =~ s/^s//i if $partition;

    nagios_die("disk controller and slice are required parameters.")
        unless ( $controller && $partition );

    my $glob_path = sprintf('/dev/rdsk/c%s*s%s', $controller, $partition);
    my @devices   = grep { $_ && -e } glob $glob_path;

    nagios_die("No storage found on bus '$controller' partition '$partition'")
        unless (@devices);

    for my $raw_dev ( @devices ) {
        my $lux_cmd = sprintf('%s display %s', $luxadm, $raw_dev);
        my @output  = qx($lux_cmd);

        my ($disk, $device) = (undef(), undef());

        LINE: for my $line (@output) {
            chomp($line);
            ##
            ## Parse the output in the order the pertinent fields appear:
            ## Disk/Controller then the storage status
            ##
            if (my ($match) = $line =~ /\bDEVICE\s+PROPERTIES\s+for\s+disk:\s+(\S+)/) {
                $disk = $match;
            }
            next LINE unless $disk;
            if (my ($match) = $line =~ /\bController\s+(\S+)/) {
                $device = $match;
            }
            next LINE unless $device;
            if (my ($match) = $line =~ /\bState\s+(\S+)/) {
                $results{$disk}->{$device} = uc $match;
            }
        }
    }

    return \ %results;
}

sub nagios_bail {
    my ( $exitval, $exitstr ) = @_;
    print STDOUT $exitstr, "\n";
    STDOUT->flush();
    exit( $exitval );
}

sub nagios_die {
    my ($msg) = @_;
    1 while chomp($msg);
    nagios_bail(
        UNKN->[0],
        as_nagios_str(
            UNKN->[1],
            $msg,
        )
    );
    ## NORETURN ##
}

MAIN: {
    my ( $exitval, $exitstr, $controller, $partition, $help );

    $|++;

    Getopt::Long::Configure ("bundling", "no_ignore_case");

    GetOptions(
        "help|h"        => \$help,
    ) or ++$help;

    pod2usage( { -exitval => -1, -verbose => 1 } )
      if ( $help || scalar(@ARGV) != 2 );

    $luxadm = PATH_LUXADM;
    nagios_die("The Sun Fire administration utility 'luxadm' was not found")
        unless( $luxadm && -x $luxadm );

    ##
    ## Check all of the EXTRACT and REPLICAT buckets
    my $results = perform_service_check(@ARGV);

    ##
    ## Evaluate the response from the service check here
    ##
    ( $exitval, $exitstr ) = evaluate_request( $results );

    nagios_bail( $exitval, $exitstr );
}

