#!/opt/perl/bin/perl

use strict;
use warnings;

=pod

=head1 NAME

check_sequences.pl - Nagios check to monitor Oracle's non-cycling sequences

=head1 SYNOPSIS

B<check_sequences.pl> [--warn=INT] [--crit=INT]

=head1 DESCRIPTION

This check examines all of the sequences that do not "cycle" (e.g., that have CYCLE="N")
and based on a percentage of MAXVALUE (specified with the B<--warn> and/or B<--crit>
parameters) generates alerts warning of impending sequence overflow.

The B<--warn> and B<--crit> parameters are expressed as integers which represent the
percentage threshold of remaining MAXVALUE in the given sequence before an alert is
created.  Ideally the B<--warn> value should be a higher value than B<--crit>.

The default values are C<10> and C<5>, respectively.

=over Example

=item B<check_sequences.pl> --warn=20 --crit=15

CHECK_SEQUENCES CRITICAL: FEATURE_SEQUENCE: [last=8828193274/max=9999999999]

The B<FEATURE_SEQUENCE> sequence has a current value that exceeds 85% of the MAXVALUE
(encroaching the last remaining 15% of the max number space in the field).

=back

=head1 OPERATIONAL CONSIDERATIONS

This script must run on a BLOC Tools host so that BLOC libraries may be invoked.

=begin RCS

 $Id: check_sequences.pl,v 1.1 2018/10/30 10:12:02 mathew Exp $
 $Name:  $

=end RCS

=cut

##
## These are const values for nagios status lines
use constant OK         => [ 0, "OK" ];
use constant WARN       => [ 1, "WARNING" ];
use constant CRIT       => [ 2, "CRITICAL" ];
use constant UNKN       => [ 3, "UNKNOWN" ];

use constant DB_USER    => 'blt';

BEGIN { require ("/space/orabloc/server/conf/inc.pl") };

use BLOC::Config;
use BLOC::DB;

use Getopt::Long;
use Pod::Usage;
use Data::Dumper;
use File::Basename;
use Math::BigFloat;

my ( $warn, $crit, $opt_fake );

GetOptions(
    'w|warn=i'  => \$warn,
    'c|crit=i'  => \$crit,
    'fake=i'    => \$opt_fake,
);

##
## Assign default values to "warn" and "crit" if not given above
##
$crit ||= "5";
$warn ||= "10";

MAIN: {
    my $dbh = BLOC::DB->new();
    my ( $exitval, $exitstr );

    my $seqs   = fetch_sequences($dbh);
    ( $exitval, $exitstr ) = check_sequences($seqs);

    print STDOUT $exitstr, "\n";
    exit($exitval);
}

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub check_sequences {
    my ($seqs) = @_;
    my ( $exitval, $exitstr ) = ( OK->[0], as_nagios_str( OK->[1], "All sequences within acceptable limits." ) );

    my %warnings = ();
    my %critical = ();

    my $status;
    for my $key (keys %{$seqs}) {
        my $h = $seqs->{$key};
        my ($last,$max) = @{ $seqs->{$key} }{qw/LAST_NUMBER MAX_VALUE/};
        $status = check_status($key, $last, $max, $warn, $crit);
        if ($status && ref($status) eq 'HASH') {
            if ( $status->{type} ) {
                if ($status->{type} eq 'crit') {
                    $critical{$key} = $status;
                } elsif ($status->{type} eq 'warn') {
                    $warnings{$key} = $status;
                }
            }
        }
    }

    if ( scalar(keys %critical) ) {
        $exitval = CRIT->[0];
        $exitstr = as_nagios_str( CRIT->[1], join(
            '; ' => map {
                sprintf (
                    '%s: [last=%s/max=%s]'
                        => $_, $critical{$_}->{last}, $critical{$_}->{max}
                )
            } keys %critical
        ) );
    }
    elsif ( scalar(keys %warnings) ) {
        $exitval = WARN->[0];
        $exitstr = as_nagios_str( WARN->[1], join(
            '; ' => map {
                sprintf (
                    '%s: [last=%s/max=%s]'
                        => $_, $warnings{$_}->{last}, $warnings{$_}->{max}
                )
            } keys %warnings
        ) );
    }

    return ($exitval, $exitstr);
}

sub fetch_sequences {
    my ($dbh) = @_;

    $dbh->{FetchHashKeyName} = 'NAME_uc';

    my $sth = $dbh->prepare( qq{
        SELECT SEQUENCE_NAME, MAX_VALUE, LAST_NUMBER
        FROM   ALL_SEQUENCES
        WHERE  SEQUENCE_OWNER = ?
        AND    CYCLE_FLAG <> 'Y'
    } ) or die $dbh->errstr;

    my $db_user = uc(DB_USER);
    $sth->execute($db_user) or die $sth->errstr;

    my $seqs = $sth->fetchall_hashref('SEQUENCE_NAME');
    return $seqs;
}

sub check_status {
    my ($table, $last, $max, $warn, $crit) = @_;
    my $b_max  = Math::BigFloat->new($max);
    my $b_last = Math::BigFloat->new($last);
    my $b_warn = $b_max->copy();
    my $b_crit = $b_max->copy();

    $b_warn->bsub($b_warn->copy()->bmul($warn / 100.0));
    $b_crit->bsub($b_crit->copy()->bmul($crit / 100.0));

    if (defined $opt_fake && $opt_fake > 0) {
        my $rand = int rand(20);

        if ( $rand == 0) {
            $b_last = $b_crit->copy()->badd(1);
            --$opt_fake;
        }
        elsif ( $rand == 1) {
            $b_last = $b_warn->copy()->badd(1);
            --$opt_fake;
        }
    }

    my $is_crit = $b_last->bcmp($b_crit) > 0 ? 1 : 0;
    my $is_warn = $b_last->bcmp($b_warn) > 0 ? 1 : 0;

    return +{
        type   => "crit",
        max    => $max,
        table  => $table,
        last   => $b_last->as_int()->bstr(),
        thresh => $b_crit->bstr()
    }
        if $is_crit;

    return +{
        type   => "warn",
        max    => $max,
        table  => $table,
        last   => $b_last->as_int()->bstr(),
        thresh => $b_warn->bstr()
    }
        if $is_warn;
    
    return;
}

