#!/usr/bin/perl
# $Id: check_stat_count.pl,v 1.1 2018/10/30 10:12:02 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib64/nagios/plugins/custom/check_stat_count.pl,v $
#
# Program       : Passed stats count
# Author        : Sean Heshmati 3/2009
# Description   : This plugin checks the number of various stat files in a
#                 directory.
#
use strict;
use Getopt::Std;

use lib "/usr/lib/nagios/plugins";
use utils qw (%ERRORS &print_revision &support);

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
my $REVISION   = $1;
my $PROGNAME   = "check_stat_count";
my $exitstatus = $ERRORS{'UNKNOWN'};
my ( $mesg, %hash );

# stat types to be monitored
my %stat_types = (
    "Domain" => "^domain.*",
    "IP"     => "^ip.*",
    "Rule"   => "^rule.*",
);

my %opt;
getopts( "hd:w:c:r:", \%opt );

my $dir  = $opt{'d'};
my $warn = $opt{'w'};
my $crit = $opt{'c'};

# make sure we have all the required args
usage() if ( not( $warn && $crit && $dir ) or $opt{'h'} );

# sanity check thresholds
unless ( $warn <= $crit ) {
    print "Error: Warning level must not be higher than critical\n";
    exit $exitstatus;
}

# bail out if we cannot open the directory
unless ( opendir( DIR, $dir ) ) {
    print "CRITICAL: Cannot open $dir: $!\n";
    exit $ERRORS{'CRITICAL'};
}

# count the number of intresting stat types and store it in a hash
while ( my $file = readdir(DIR) ) {
    foreach my $type ( keys %stat_types ) {
        if ( $file =~ /$stat_types{$type}/ ) {
            $hash{$type}{count}++;
            $hash{total}++;
        }
    }
}

closedir(DIR);

# figure out return value and compose message
foreach my $type ( keys %stat_types ) {

    if ( $hash{$type}{count} >= $crit ) {
        $exitstatus = $ERRORS{'CRITICAL'};
    }
    elsif ( $hash{$type}{count} >= $warn ) {
        $exitstatus = $ERRORS{'WARNING'}
          unless ( $exitstatus == $ERRORS{'CRITICAL'} );
    }
    else {
        $exitstatus = $ERRORS{'OK'}
          unless ( $exitstatus == $ERRORS{'WARNING'}
            or $exitstatus == $ERRORS{'CRITICAL'} );
    }

    $mesg .= sprintf( "%d %s, ", $hash{$type}{count} || 0, $type );
}

$mesg .= sprintf( "%d Total. (threshold warning=%s,critical=%s)",
    $hash{total}, $warn, $crit );

if ( $exitstatus == $ERRORS{'OK'} ) {
    print "OK: Stat count - " . $mesg . "\n";
}
elsif ( $exitstatus == $ERRORS{'WARNING'} ) {
    print "WARNING: Stat count - " . $mesg . "\n";
}
elsif ( $exitstatus == $ERRORS{'CRITICAL'} ) {
    print "CRITICAL: Stat count - " . $mesg . "\n";
}
elsif ( $exitstatus == $ERRORS{'UNKNOWN'} ) {
    print "UNKNOWN: no data returned!\n";
}

exit $exitstatus;

sub usage {
    print_revision( $PROGNAME, $REVISION );
    print "\nUsage:\n";
    print "  $PROGNAME -d <directory> -w <warn_num> -c <crit_num>\n";
    print "\nOptions:\n";
    print "  -d directory\n";
    print "     Directory to check (ex: /space/orabloc/spool/passed_stats)\n";
    print "  -c critical_number\n";
    print "     Number of files to result in critical status\n";
    print "  -w warning_number\n";
    print "     Number of files to result in warning status\n";
    print "  -h\n";
    print "     Displays this help message\n";
    exit $exitstatus;
}
