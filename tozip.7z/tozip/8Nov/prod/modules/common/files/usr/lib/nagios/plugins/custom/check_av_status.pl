#!/usr/bin/perl
# $Id: check_av_status.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/common/files/usr/lib/nagios/plugins/custom/check_av_status.pl,v $
#
# Program       : Symantec Platinum Solaris AV ruleset verification check
# Author        : Sean Heshmati 5/2005
# Description   : This plugin checks if AV validation is working
#
#
# Check Explanation:
#  A failure is indicated by " SELECT status FROM AV_TEST_CHECK " returning one
#  or more rows.  The check script gives a warning if one result is returned,
#  and error if 2  or more are returned.  This means the av_daemon was unable
#  to successfully test the validity of an Solaris Platinum AV package. 
#  If you look on bt-web01, where av_daemon is currently running, you may 
#  see we have had issue connecting to live update periodically.  You can 
#  also see the failure and recovery here 
#  http://bt-web-int.brightmail.com/admin/AVPackage/edit_item.html?id=1.
#
# What to do:
#  Normally we investigate such issues and contact security response/NOC if 
#  the problem is downstream. More info is available @  
#  http://krishna.brightmail.com/share/FAQ/av_daemon_urls.txt.
#
#
#
#
#
#
#
#

use strict;
use Getopt::Long;
require DBI || die "CRITICAL - DBI module is not installed! aborting...\n";
require DBD::Oracle || die "CRITICAL - DBD::Oracle module is not installed! aborting...\n";

use lib "/usr/lib/nagios/plugins";
use vars qw($PROGNAME $REVISION);
use utils qw (%ERRORS &print_revision &support);

my ($opt_u, $opt_p, $opt_d, $opt_V, $opt_h);
my ($usr, $pw, $db, $exitstatus, $dbh, $message, $sth, $sql, $status);

'$Revision: 1.1 $' =~ /^.*(\d+.\d+) \$$/;
$REVISION=$1;
$PROGNAME="check_av_status";
$exitstatus=$ERRORS{'UNKNOWN'};
$ENV{ORACLE_HOME}="/u01/app/oracle/product/8.1.7";

Getopt::Long::Configure('bundling');
GetOptions(
    "V"   => \$opt_V, "version" => \$opt_V,
    "h"   => \$opt_h, "help"    => \$opt_h,
    "u=s" => \$opt_u, "user"    => \$opt_u,
    "p=s" => \$opt_p, "password" => \$opt_p,
    "d=s" => \$opt_d, "database" => \$opt_d);


if ($opt_V)
{
    print_revision($PROGNAME, $REVISION);
    exit $ERRORS{'OK'};
}

if ($opt_h)
{
    print_help();
    exit $ERRORS{'OK'};
}

if ($opt_p && $opt_u && $opt_d)
{

    if ($dbh = db_connect($opt_d,$opt_u,$opt_p))
    {
        $sql = "SELECT status FROM AV_TEST_CHECK";
        $sth = $dbh->prepare($sql);
        
        if (!$sth)
        {
            print "CRITICAL - Failed to prepare statement!\n";
            exit $ERRORS{'CRITICAL'};
        }
        else
        {
            $sth->execute;
            $status = $sth->fetchrow_array();
            $sth->finish;
        }

        if ($status == 0)
        {
            print "OK - AV test passed.\n";
            $exitstatus=$ERRORS{'OK'};
        }
        elsif ($status == 1)
        {
            print "WARNING - AV possibly failing!\n";
            $exitstatus=$ERRORS{'WARNING'};
        }
        elsif ($status >= 2)
        {
            print "CRITICAL - AV test failed!\n";
            $exitstatus=$ERRORS{'CRITICAL'};
        }
        else
        {
            print "CRITICAL - Table lookup failed!\n";
            $exitstatus=$ERRORS{'CRITICAL'};
        }
    
    }
    else
    {
        print  "CRITICAL - $message\n";
        exit $exitstatus;
    }
}
else
{
    print_usage();
    exit $ERRORS{'UNKNOWN'};
}

exit $exitstatus;


##################################################################

sub db_connect
{
    my $database = shift;
    my $username = shift;
    my $password = shift;

    my $data_source = "dbi:Oracle:$database";
    $dbh = DBI->connect($data_source,$username,$password,{PrintError=>0});

    # ORA-12224 - "The connection request could not be completed because the listener is not running."
    # ORA-01034 - "Oracle was not started up."
    # ORA-01090 - "Shutdown in progress - connection is not permitted""
    # ORA-12154 - "The service name specified is not defined correctly in the TNSNAMES.ORA file."
    # ORA-12505 - "TNS:listener could not resolve SID given in connect descriptor."
    # ORA-12545 - "TNS:name lookup failure."

    unless ($dbh) {
        if ( $DBI::errstr =~ /ORA-01017|ORA-1017|ORA-01004|ORA-01005/ )
        {
            $message .="Login error: ~$DBI::errstr~";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        elsif ( $DBI::errstr =~ /ORA-12224/ )
        {
            $message .= "You received an ORA-12224, which usually means the listener is down, or your connection definition in your tnsnames.ora file is incorrect. Check both of these things and try again.";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        elsif ( $DBI::errstr =~ /ORA-01034/ )
        {
            $message .= "You received an ORA-01034, which usually means the database is down. Check to be sure the database is up and try again.";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        elsif ( $DBI::errstr =~ /ORA-01090/ )
        {
            $message .= "You received an ORA-01090, which means the database is in the process of coming down.";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        elsif ( $DBI::errstr =~ /ORA-12154/ )
        {
            $message .= "You received an ORA-12154, which probably means you have a mistake in your TNSNAMES.ORA file for the database that you chose.";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        elsif ( $DBI::errstr =~ /ORA-12505/ ) 
        {
            $message .= "You received an ORA-12505, which probably means you have a mistake in your TNSNAMES.ORA file for the database that you chose, or the database you are trying to connect to is not defined to the listener that is running on that node.";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        elsif ( $DBI::errstr =~ /ORA-12545/ )
        {
            $message .= "You received an ORA-12545, which probably means you have a mistake in your TNSNAMES.ORA file for the database that you chose. (Possibly the node name).";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
        else
        {
            $message .="Unable to connect to Oracle ($DBI::errstr)\n";
            $exitstatus=$ERRORS{"CRITICAL"};
        }
    }

    return ($dbh);
}
    
sub print_usage
{
    print "Usage:\n";
    print "  $PROGNAME <-u username> <-p password> <-d database>\n";
    print "  $PROGNAME [-h | --help]\n";
    print "  $PROGNAME [-V | --version]\n";
}

sub print_help
{
    print_revision($PROGNAME, $REVISION);
    print_usage();
    print "\n";
    print "  <username>  Database username\n";
    print "  <password>  Database users password\n";
    print "  <database>  Database name\n";
    print "\n";
    support();
}
