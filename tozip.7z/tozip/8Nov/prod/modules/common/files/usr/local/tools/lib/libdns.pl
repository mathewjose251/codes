# Note: This file was tabbed out in a view using four spaces for tabs

# Functions needed by dns.pl and other scripts for modifying, updating,
# checking, restarting and auditing DNS hosts.  Some variables that you might
# want to globalize for these libraries are:
# $zoneFileSuffix
# $zoneDir
# $etcDir
# $namedConf
# @masters
# @slaves
# @resolvers

use FindBin qw($Bin);
use Fcntl ':flock';			# Import LOCK_* constants for flock()
use lib "$Bin../lib";
use vars qw($myFunc);

# Make sure that the main batch of functions are available
require "libmain.pl";

# Make sure we have output and error handling
require "liberr.pl";

# Import the common constants
require "TableOfConstants";

# Some DNS-specific constants
use constant DNS_SERIALUP	=> 1;

# This is the huge, all-mighty sub that does everything.
# Open a zone file with Tie::File, ties it to an array and locks the file.
# Has support for dry-run mode and will Tie to a dummy array and operate on a
# copy of the dummy array in dry-run mode.
# Depending on the parameters passed to it, it then uses various functions to
# get the information it needs and then adds, removes or replaces data in the
# file.
sub updateZoneFile() {
	my $fileName	= shift;
	my $rrType		= shift;
	my $action		= shift;

	$myFunc			= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc Begin\n"	if ($DEBUG);

	if ($DEBUG) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$fileName = $fileName\n"	if ($DEBUG);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$rrType = $rrType\n"	if ($DEBUG);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$action = $action\n"	if ($DEBUG);
	}

	# The locals
	my (
		$return, @splitLine, @splitRecord, $entryLine,
		%rrTable, $fileObj, $index, $after,
		$newRec, $oldRec, @splitName, @fakeZone,
		@splitRecord, $openErr, %actionList
	);

	# The globals
	use vars qw(
		@tiedZone @splicedZone
	);

	$openErr		= "Could not open $fileName";
	%actionList	= (
		'add'		=> 1,
		'delete'	=> 1,
		'replace'	=> 1,
		'check'		=> 1
	);

	# Make sure that we are getting all of the data that we need
	return FILE_NOT_FOUND()		if (! -f $fileName);
	return BAD_ARGUMENT()		if (! $actionList{$action});
	return MISSING_ARGUMENT()	if (! $rrType);
	return MISSING_ARGUMENT()	if (! @addr);

	# If everything has checked out to be okay up until this point, open,
	# lock and tie the zone file
	use Tie::File;
	# If it's a dry run, tie to another array so we don't make any permanent
	# changes.
	if ($dry_run) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": opening file: $fileName\n"	if ($DEBUG);
		$fileObj	= tie @fakeZone,'Tie::File',$fileName or die "$openErr: $!";
		@tiedZone	= @fakeZone;
	} else {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": opening file: $fileName\n"	if ($DEBUG);
		$fileObj	= tie @tiedZone,'Tie::File',$fileName or die "$openErr: $!";
	}
	$fileObj->flock(LOCK_EX);

	# Process each of the record inserts
	foreach (@addr) {
		$/		= "\n";
		undef $return;
		chomp;
		@splitRecord	= split(/\s/, $_);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			" \@splitRecord = @splitRecord\n"	if ($DEBUG);
		# Grab a list of supported record types and make sure a valid type was
		# given
		%rrTable		= getDNSFormat('rr',@splitRecord);
		$newRec			= "$rrTable{$rrType}";
		return BAD_ARGUMENT()			if (! $newRec);

		# Now, depending on the requested action, get the necessary data

		# Get the index number of the matching record entry (do this for the
		# 'add' action as well because we do not want duplicate entries
		$index			= getRecord('exact',@splitRecord);
		if ($action !~ /add/ and $tiedZone[$index] !~ /^$splitRecord[0]/) {
			$return			= RECORD_NOT_FOUND();
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				" \$return=$return\n"	if ($DEBUG);
		}

		# Delete the record if we found it and action is 'delete'
		if ($action =~ /delete/ and ! $dry_run and ! $return) {
			$return			= delete $tiedZone[$index];
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				" \$return=$return\n"	if ($DEBUG);
		}
		# If we are replacing an entry, replace it unless we're it's a
		# dry-run
		elsif ($action =~ /replace/ and ! $return) {
			$return				= "$newRec";
			$tiedZone[$entry]	= "$return";
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				" \$return=$return\n"	if ($DEBUG);
		}
		# If we are checking to see if a record exists, return the record
		elsif ($action =~ /check/ and ! $return) {
			$return = "$tiedZone[$index]";
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				" \$return=$return\n"	if ($DEBUG);
		}
		# If we are adding an entry, find the closest matching line and add
		# in the entry on a new line after the closest match
		else {
			@splitName		= split(/\D/, $splitRecord[0]);
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				" \@splitName = @splitName\n"	if ($DEBUG);
			if ($tiedZone[$index] =~ /^$splitRecord[0]/) {
				$return         = RECORD_EXISTS();
			} else {
				$index			= getRecord('closest',$splitRecord[0]);
			}
			if (! $return) {
				$after		= ($index - 1);
				$oldRec		= "$tiedZone[$after]";
				$msg		= "Adding...\n$newRec\n... After...\n$oldRec\n";
				lprint(LVL_WARN,$msg);
				@splicedZone	= splice(@tiedZone,$index);

				# Add the entry to the end of the spliced array
				unshift(@splicedZone,$newRec);

				# Merge the spliced array with the tied array
				push(@tiedZone,@splicedZone);
			}
			warn "$debugPrepend "
				.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
				" \$return=$return\n"	if ($DEBUG);
		}
	}

	# Unlock and untie the file
	$fileObj->flock(LOCK_UN);
	# If it's a dry run, untie the fakeZone, otherwise untie the normal one
	if ($dry_run) {
		untie @fakeZone;
	} else {
		untie @tiedZone;
	}

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return=$return\n"	if ($DEBUG); 
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc: End\n"		if ($DEBUG); 
	return $return;
}
	
# Depending on the format type that you pass to this function, returns a hash
# of the appropriate format layouts.  Currently supported format types are:
# rr (Resource Records)
# First argument should be the format type, remaining arguments are optional
# depending on the format.
# Example:
# open ZONE,'>>',"$zonefile" or die "$!\n";
# %rrFormats = &getDNSFormat('rr',"$mxname","$mxpriority","$mailhost");
# print ZONE "$rrFormats{'mx'}\n";
# close ZONE;
sub getDNSFormat {
	my $format	= shift;
	my @val		= @_;
	my %return	= ();

	$myFunc			= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc Begin\n"	if ($DEBUG);

	# Reformat the user-defined values in case the user added in things like
	# a period at the end.
	foreach (@val) {
		until (!/.*\.$/) { chop $_; }
	}

	# Build the list of supported types and their resulting symbol formats
	%return	= (
		'a'			=> "$val[0]\t\tIN\tA\t$val[1]",
		'cname'		=> "$val[0]\t\tIN\tCNAME\t$val[1].",
		'ptr'		=> "$val[0]\t\tIN\tPTR\t$val[1].",
		'ns'		=> "\t\tIN\tNS\t$val[0]",
		'mx'		=> "$val[0]\t\tIN\tMX\t$val[1] $val[2]"
	)	if ($format =~ /^rr$/);

	if ($DEBUG) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \%return {\n"	if ($DEBUG);
		foreach (keys (%return) ) {
			chomp;
			warn ": $_\t=> $return{$_}\n";
		}
		warn ": }\n";
	}
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc End\n"	if ($DEBUG);
	return %return;
}

# getRecord() expects @tiedZone to be globalized and newline sepparated.
# It locates the record that passed to it in the array and returns back the
# array element number that it was found on or null if no matching record was
# found.  Do not assume that 0 is a not-found or found result, however.
# Check yourself on the return value to make sure.
# The first argument is all that is required, but you can pass it as many
# match conditionals as arguments as you like.  The will be matched in the
# following fashion:
# ^$_[0].*$_[1].*...$
# This way you can get as specific as you like or as broad as you like with
# your matches and you can also pass in your own regular expression operators.
sub getRecord(*) {
	my $type		= shift;
	my @params		= @_;
	my $match		= '';
	my $loop		= 0;
	my $return		= 0;
	my $index		= 0;
	my $matched		= 1;
	
	return 0	if (! @params);
	if ($DEBUG) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$type = $type\n"	if ($DEBUG);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \@params = @params\n"	if ($DEBUG);
	}

	$myFunc			= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc Begin\n"	if ($DEBUG);

	if ($type =~ /exact/) {
		$match	= join('.*', @params);
		for $index ( 0 .. $#tiedZone) {
			if ($tiedZone[$index] =~ /^$match/) {
				$return			= "$index";
				last;
			}
		}
	} elsif ($type =~ /closest/) {
		while ($matched != 0) {
			if ($matched == 1 and $loop gt 0) {
				if ($match =~ /a|0/) {
					last;
				} else {
					$match--;
				}
			}
			$match			.= substr($params[0],0,$matched);
			for $index ( $return .. $#tiedZone ) {
				$return			= "$index";
				if ($matched gt 1 and $_ !~ /^$match/) {
					$index--;
					$return			= "$index";
					$matched		= 0;
					last;
				}
				$matched++ if /^$match/;
				last if /^$match/;
			}
			$loop++;
		}
	}

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return = $return\n"	if ($DEBUG);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc End\n"	if ($DEBUG);
	return $return;
}

# Will return each address that does not exist out of the list of addresses
# passed to it.  First argument is the zone file name, the rest can be as
# many addresses as you want.
sub lookupHostAddrFromARecordList(*) {
	my $fileName	= shift;
	my @match		= @_;
	my $fileHandle	= '';
	my $ipAddr		= '';
	my @splitAddr	= ();
	my @return		= '';

	$myFunc			= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc Begin\n"	if ($DEBUG);

	if ($DEBUG) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$fileName = $fileName\n"	if ($DEBUG);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \@match = @match\n"	if ($DEBUG);
	}

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": opening file: $fileName\n"	if ($DEBUG);
	$fileHandle		= openFile($fileName)	if (-r $fileName);
	ADDR: foreach (@match) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": current loop = $_\n"	if ($DEBUG);
		chomp;
		@splitAddr		= split(/\s/, $_);
		$ipAddr			= pop(@splitAddr);
		undef @splitAddr;
		@splitAddr		= split(/\./, $ipAddr);
		$ipAddr			= pop(@splitAddr);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$ipAddr = $ipAddr\n"	if ($DEBUG);
		while (<$fileHandle>) {
			next if !/^$ipAddr\s+.*/;
#			chomp;
#			push(@return,"$_");
			next ADDR if /^$ipAddr\s+.*/;
		}
		push(@return,$_);
	}
	closeFile($fileHandle);

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \@return = @return\n"	if ($DEBUG);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc End\n"	if ($DEBUG);
	return @return;
}

# Returns a zone file name if found.  Requires either a domain name or an
# IP address and expects $zoneFileSuffix to be instantiated and expects to
# already be running in the directory where the zone files can be found.
# Returns null if it cannot find a match.
sub getZoneFile() {
	my @host		= split(/\./, shift);
	my $rrType		= shift;
	my $return		= '';

	$myFunc			= debugInfo('subroutine');
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc Begin\n"	if ($DEBUG);

	if ($DEBUG) {
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \@host = @host\n"	if ($DEBUG);
		warn "$debugPrepend "
			.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
			": \$rrType = $rrType\n"	if ($DEBUG);
	}

	# Determine what kind of zone file we are looking for and design the
	# file name format based on the result
	if ($rrType =~ /ptr/) {
		pop(@host);
		$return		= join('.',@host,'in-addr.arpa',$zoneFileSuffix);
	} else {
		$return		= join('.',splice(@host,($#host - 1)));
	}

	# If the file does not exist, undef $return so that we do not misslead
	# the caller.
#	undef $return	if (! -f $return);

	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": \$return = $return\n"	if ($DEBUG);
	warn "$debugPrepend "
		.debugInfo('filename',' ','base')." ".debugInfo('line',' ').
		": $myFunc End\n"	if ($DEBUG);
	return $return;
}

# Finds a serial number in an array and returns it or returns null if none
# found or returns the array with an updated serial number if the first
# argument given to dnsSerial is equal to DNS_SERIALUP constant.
# Second and following args are the elements of the array.
# This function is much bigger than it should be.  It could be about ten
# lines, but it's not.  Why?  I dunno!
sub dnsSerial()
{
	if ($_[0] == DNS_SERIALUP)
	{
		$update		= TRUE;
		shift (@_);
		lprint(LVL_DEBUG(),"Updating serial\n");
	}
	else {
		lprint(LVL_DEBUG(),"Retrieving serial\n");
	}
	my @zone		= @_;
	my (
		@return, $date, @splitLine,
		$serDate, $serial, $index);

	return	if (! @zone);

	# Scan through the array looking for the serial number
	for (@zone)
	{
		next if !/^.*;.*Serial/;
		lprint(LVL_DEBUG(),"Found line with a serial number\n");
		lprint(LVL_DEBUG(),"Line = $_\n");
		chomp ($_);
		# We're splitting by anything that is not a word because sometimes
		# people will place a semicolon directly after the serial number
		# without any whitespace between it
		@splitLine		= split (/\W/, "$_");
		lprint(LVL_DEBUG(),"Serial line split: @splitLine\n");
		last;
	}

	return		if (! @splitLine);

	# The serial number should be the first element of the array
	while (@splitLine and $serial !~ /^\d{10}$/)
	{
		$serial		= shift @splitLine;
	}
	return	if ($serial !~ /^\d{10}$/);
	lprint(LVL_DEBUG(),"Serial = $serial\n");

	# Update the serial number if we are supposed to
	if ($update)
	{
		lprint(LVL_DEBUG,"Entering serial update portion\n");
		$date		= &getDateTime('dns');
		lprint(LVL_DEBUG,"Date = $date\n");

		# Compare the date to the Serial, assuming the last two characters of
		# the serial number are the incremented update intervals
		# (i.e. 2005080501, 2005080502, 2005080503, etc)
		$serDate	= substr($serial, 0, -2);
		lprint(LVL_DEBUG(),"Old serial date: $serDate\n");
		if ($serDate =~ /^$date$/)
		{
			lprint(LVL_DEBUG(),"Serial date and current date match\n");
			$newSerial	= $serial;
			$newSerial++;
		}
		else
		{
			lprint(LVL_DEBUG(),"Serial date and current date do not match\n");
			$newSerial	= "$date"."00";
		}

		lprint(LVL_DEBUG(),"New serial number: $newSerial\n");

		# Scan through the array looking for the serial number
		# I love repeating code for no good reason.
		lprint(LVL_DEBUG(),"Updating data with new serial\n");
		for $index ( 0 .. $#zone )
		{
			lprint(LVL_DEBUG(),"Line = $zone[$index]\n");
			next if ($zone[$index] !~ /^.*;.*Serial/);
			lprint(LVL_DEBUG(),"Found line with serial\n");
			lprint(LVL_DEBUG(),"$zone[$index]\n");
			# Update the serial number
			($zone[$index] = $zone[$index]) =~ s/$serial/$newSerial/;
			lprint(LVL_DEBUG(),"$zone[$index]\n");
			last;
		}
	}
	else
	{
		return $serial;
	}

	return @zone;
}

# Returns a list of lines that pertain to the header of the zone.  The header
# is determined from the first line of the file until the line matching
# '^;/HEADER';  Takes a file name as its one argument.
sub dnsGetZoneHeader()
{
	my $fileName	= shift;
	my $last		= ';/HEADER';
	return	if (! -f "$fileName");
	my ($fileHandle, @return);

	open ($fileHandle,"$fileName") or return;
	while (<$fileHandle>)
	{
		last if /^$last/;
		push (@return,$_);
	}

	# Added the header tag back in at the end after a blank line
	push (@return,"$last");

	return @return;
}

return 1;
