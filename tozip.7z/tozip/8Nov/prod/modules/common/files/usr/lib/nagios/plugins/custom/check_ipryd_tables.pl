#!/usr/bin/perl

#
# OH. YES. LITTLE BOBBY TABLES, WE CALL HIM. -- http://xkcd.com/327/
#

use strict;
use warnings;

=pod

=head1 NAME

check_ipryd_tables.pl - Nagios check to monitor IPRepyard's postgres table differences

=head1 SYNOPSIS

B<check_ipryd_tables.pl> <dc1[:dc2]> <crit-delta[%]> [warn-delta[%]]

=head1 DESCRIPTION

This nagios check is used in conjunction with the data population tool F<populate_ipryd_counts.pl>. In
order for this check to function the data population script must be run out of cron, ideally at around
3-4 minute after the hour on a ten minute interval.  See F<populate_ipryd_counts.pl> documentation for
more details.

=head2 DATACENTER SPECIFIERS

Use the three-letter datacenter specifiers (e.g., C<sac>) to govern what mode the nagios check will
operate in, which is one of two different ways:

=over

=item Check master node in one datacenter against a master node in another

If the check is invoked with the syntax:

B<check_ipryd_tables.pl> dc1:dc2 [...]

Then the master node in datacenter given by C<dc1> will be checked against the master node in
datacenter C<dc2>.

=item Check master node in a datacenter against the non-master nodes in the same datacenter

If the check is invoked with the syntax:

B<check_ipryd_tables.pl> dc1 [...]

Then the master node in datacenter given by C<dc1> will be checked against the non-master nodes
in the same datacenter.

=back

=head2 DELTA SPECIFIERS

The C<crit-delta> and optional C<warn-delta> specifiers can be expressed two different ways.

=over

=item Percentages of change

If a real number is followed with a percentage character then an alert will be triggered if the
percentage of change between the specified nodes is greater than or equal to the value given.

=item Number of rows

If an integer is supplied without a following percentage character then a straight comparison is
given in the difference in the number of rows and an alert is triggered accordingly.

=back

=head2 EXAMPLES

=over

=item B<check_ipryd_tables.pl> sac:tuc 1% .8%

Trigger a critical alert if the difference between the master nodes in C<sac> and C<tuc> are greater
than or equal to 1 percent.  Trigger a warning if the difference is greater than or equal to .8 percent.

=item B<check_ipryd_tables.pl> sac 500000 400000

Trigger a critical alert if the difference in the number of rows for the master IPRepyard server in the
C<sac> datacenter and the non-masters in the same datacenter is greater than or equal to 500,000 rows.
Trigger a warning if the difference is greater than or equal to 400,000 rows.

=item B<check_ipryd_tables.pl> tuc 2.5%

Trigger a critical alert if the difference in the number of rows for C<tuc> master and its non-masters
is greater or equal to a 2.5 percent change.  No warnings alerts are generated.

=back

=begin RCS

 $Id: check_ipryd_tables.pl,v 1.1 2018/10/30 10:12:00 mathew Exp $

=end RCS

=cut

use Getopt::Long;
use File::Find;
use List::Util qw(min max reduce);
use File::Spec::Functions;
use File::Basename qw(basename);
use Pod::Usage;

use constant NODE_DATADIR => '/var/tmp/wl-iprpyd-tbldata';

##
## These are const values for nagios status lines
use constant OK   => [ 0, "OK" ];
use constant WARN => [ 1, "WARNING" ];
use constant CRIT => [ 2, "CRITICAL" ];
use constant UNKN => [ 3, "UNKNOWN" ];

my ($dc1, $dc_conf1, $dc2, $dc_conf2);
my ($exitval, $exitmsg);

pod2usage( { -exitval => -1, -verbose => 2 } )
    unless (scalar(@ARGV) >= 2);

my ($dc_spec, $crit, $warn) = @ARGV;

if ( $dc_spec =~ /^(\S+?):(\S+)$/ ) {
    ($dc1, $dc2) = ( lc $1, lc $2 );
    $dc_conf1 = read_conf($dc1);
    $dc_conf2 = read_conf($dc2);
    ($exitval, $exitmsg) = master_master_check($dc_conf1, $dc_conf2, $crit, $warn);
}
else {
    $dc1 = lc $dc_spec;
    $dc_conf1 = read_conf($dc1);
    ($exitval, $exitmsg) = master_node_check($dc_conf1, $crit, $warn);
}

printf STDOUT "%s\n", $exitmsg;
exit($exitval);

sub master_master_check {
    my ($dcc1, $dcc2, $crit, $warn) = @_;
    my ($exitval, $exitmsg) = node_check($dcc1->{master}, $dcc2->{master}, $crit, $warn);
    return ($exitval, $exitmsg);
}

sub master_node_check {
    my ($dcc1, $crit, $warn) = @_;

    #
    # Just compare the master against the node with the largest delta
    #
    my $master  = delete $dcc1->{master};
    my $bignode = reduce {
        (
              abs( $master->{COUNT} - $dcc1->{$a}->{COUNT} )
            > abs( $master->{COUNT} - $dcc1->{$b}->{COUNT} )
        ) ? $a : $b
    } keys %{ $dcc1 };
    my ($exitval, $exitmsg) = node_check($master, $dcc1->{$bignode}, $crit, $warn);
    return ($exitval, $exitmsg);
}

sub node_check {
    my ($node1, $node2, $crit, $warn) = @_;

    my ($i1, $i2) = ( $node1->{INTERVAL}, $node2->{INTERVAL} );
    fatal("Interval check is skewed -- run populate-iprep-counts.pl again")
        unless ( defined $i1 && defined $i2 && $i1 == $i2 );

    my ($is_warn, $is_crit, @w_msgs, @c_msgs);
    if (defined $warn) {
        if ( $warn =~ /^([.\d]+)%$/ ) {
            my $thresh = $1;
            $is_warn = check_thresh_perc($node1, $node2, $thresh, \@w_msgs);
        }
        elsif ( $warn =~ /^(\d+)$/ ) {
            my $rows = $1;
            $is_warn = check_thresh_rows($node1, $node2, $rows, \@w_msgs);
        }
        else {
            fatal("Malformed warn parameter '%s'", $warn);
        }
    }
    if ( $crit =~ /^([.\d]+)%$/ ) {
        my $thresh = $1;
        $is_crit = check_thresh_perc($node1, $node2, $thresh, \@c_msgs);
    }
    elsif ( $crit =~ /^(\d+)$/ ) {
        my $rows = $1;
        $is_crit = check_thresh_rows($node1, $node2, $rows, \@c_msgs);
    } 
    else {
        fatal("Malformed crit parameter '%s'", $crit);
    }
    
    if ($is_crit) {
        my $c_msg = join('; ', @c_msgs);
        return ( CRIT->[0], as_nagios_str( CRIT->[1], $c_msg ) );
    }
    if (defined $warn && $is_warn) {
        my $w_msg = join('; ', @w_msgs);
        return ( WARN->[0], as_nagios_str( WARN->[1], $w_msg ) );
    }

    return ( OK->[0], as_nagios_str( OK->[1], "Nodes within acceptable threshold limits" ) );
}

sub check_thresh_perc {
    my ($node1, $node2, $thresh, $msgs) = @_;
    if ($node2->{COUNT} < $node1->{COUNT}) {
        my $tmp = $node1;
        $node1 = $node2;
        $node2 = $tmp;
    }
    my $n_c1  = $node1->{COUNT};
    my $n_c2  = $node2->{COUNT};
    my $diff  = ( $n_c2 - $n_c1 );
    my $pdiff = int( $n_c1 * ( $thresh / 100 ) );
    if ( $diff > $pdiff ) {
        ( my $actperc = sprintf '%6.2f%%', ( $diff * 100 ) / $n_c1 ) =~ s/^\s*|\s*$//g;
        push @{$msgs}, sprintf("%s:[%s] => %s:[%s] > %s%% change [%s]",
            @{$node1}{qw(NODE COUNT)}, @{$node2}{qw(NODE COUNT)}, $thresh, $actperc);
        return 1;
    }
    return;
}

sub check_thresh_rows {
    my ($node1, $node2, $rows, $msgs) = @_;
    if ($node2->{COUNT} < $node1->{COUNT}) {
        my $tmp = $node1;
        $node1 = $node2;
        $node2 = $tmp;
    }
    my $n_c1  = $node1->{COUNT};
    my $n_c2  = $node2->{COUNT};
    my $diff  = ( $n_c2 - $n_c1 );
    if ( $diff > $rows ) {
        push @{$msgs}, sprintf("%s:[%s] => %s:[%s] > %s rows change [%s]",
            @{$node1}{qw(NODE COUNT)}, @{$node2}{qw(NODE COUNT)}, $rows, $diff);
        return 1;
    }
    return;
}

sub read_conf {
    my ($dc)     = @_;
    my @paths    = ();
    my $spec_dir = catdir(NODE_DATADIR, $dc);
    my $emptymsg = sprintf(
        "No node files or master symlink for '%s' -- populate-iprep-counts.pl running?", $dc
    );
    fatal($emptymsg) unless( -d $spec_dir );
    my ($master, %conf);
    my $filter = sub {
        return if /^\.\.?$/;
        return unless -f;
        $master = readlink, return if ( -l && basename $_ eq 'master' );
        push @paths, $File::Find::name;
    };
    find( { no_chdir => 1, wanted => $filter }, $spec_dir );
    fatal($emptymsg) unless ( scalar(@paths) && $master );
    my @names = ();
    if (@names = grep { time() - $_->[1] > ( 15 * 60 ) } map { [ $_, (stat)[9] ] } @paths) {
        fatal("Node files are more than 15 mins old -- populate-iprep-counts.pl running?");
    }
    PATHS: for my $path (@paths) {
        my $file = basename($path);
        my $cf = read_conf_entry($path);
        warn("Malformed cf file '$cf', skipping...\n"), next PATHS unless $cf;
        my $entry = ( $file eq $master ) ? "master" : $file;
        $conf{$entry} = $cf;
    }
    return \%conf;
}

sub read_conf_entry {
    my ($path) = @_;
    return unless -f $path;
    local(*ARGV);
    @ARGV = ( $path );
    my @data = <>;
    chomp(@data);
    return { map { split /=/, $_, 2 } @data };
}

sub service_name {
    my $name = shift || $0;
    $name = basename($name);
    $name =~ s/\.[^.]*$//;
    return uc($name);
}

sub as_nagios_str {
    my ( $status, $msg, @args ) = @_;
    my ($text) = scalar @args ? sprintf( $msg, @args ) : $msg;
    1 while chomp $text;
    return service_name() . ' ' . $status . ": " . $text;
}

sub fatal {
    my $msg = as_nagios_str(CRIT->[1], @_);
    print STDOUT $msg, "\n";
    exit(CRIT->[0]);
}

