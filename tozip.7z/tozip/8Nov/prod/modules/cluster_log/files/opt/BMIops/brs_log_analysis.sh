#/bin/bash
#
# $Id: brs_log_analysis.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
#


# Remove old Log Files
rm -rf /app/log/tmp/brs-logs/*

# Create temp dir if it does not exist
if [ ! -d /app/log/tmp/brs-logs ]
then
        mkdir -p /app/log/tmp/brs-logs
fi

for host in `/usr/local/tools/bin/bmehost | grep ^www`
do
	scp -p ${host}:/app/log/httpd/brs.brightmail.com-access_log.1.gz /app/log/tmp/brs-logs/${host}-access.1.gz
done

# Webalize Log Files
/usr/bin/zmergelog /app/log/tmp/brs-logs/www*-access.1.gz | webalizer -c /var/www/html/usage/brs/webalizer.conf

# Migrate results to NMS
rsync -aze ssh /var/www/html/usage/brs/* nms02.usw2:/var/www/html/usage/brs/
rsync -aze ssh /var/www/html/usage/brs/* nms02.usw2:/var/www/html/usage/brs/
