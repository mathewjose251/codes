#/bin/bash
#
# $Id: bt-rpc_log_analysis.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
#

# How many times should we retry the host
num_try=6
sleep=60

# Remove old Log Files from Server
rm -rf /app/log/tmp/bt-rpc-logs/*

# Create temp dir if it does not exist
if [ ! -d /app/log/tmp/bt-rpc-logs ]
then
        mkdir -p /app/log/tmp/bt-rpc-logs
fi

for host in `/usr/local/tools/bin/bmehost | grep ^bt-rpc`
do
	try=1
	
	while [ $try -lt $num_try ]
	do
		scp -p ${host}:/opt/bloctools/server/logs/access.1.gz /app/log/tmp/bt-rpc-logs/${host}-access.1.gz
		if [ $? -ne 0 ]
		then
			echo "SCP failed on $host: Try=$try sleeping for $sleep..."
			sleep $sleep
			let try=try+1
		else
			break
		fi
	done
done

/usr/bin/zmergelog /app/log/tmp/bt-rpc-logs/bt-rpc*-access.1.gz | webalizer -c /var/www/html/usage/bt-rpc/webalizer.conf

# Migrate results to NMS
rsync -aze ssh /var/www/html/usage/bt-rpc/* nms02.usw2:/var/www/html/usage/bt-rpc/
rsync -aze ssh /var/www/html/usage/bt-rpc/* nms02.usw2:/var/www/html/usage/bt-rpc/

