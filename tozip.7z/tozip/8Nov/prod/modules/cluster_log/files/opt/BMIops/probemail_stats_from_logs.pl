#!/usr/bin/perl -w
# $Id: probemail_stats_from_logs.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $

use File::Basename;
use strict;
use Time::Local;
use Sys::Hostname;
use Getopt::Std;
use IO::File;

sub uniq {
    my %seen;
    return grep {!($seen{$_}++)} @_;
}

sub sum {
    my $rv = 0;
    foreach (@_) { $rv += $_ };
    return $rv;
}

sub usage
{
    print("usage: $0 [OPTIONS] logfile [recipient1]..[recipientN]\n");
    print("       if no recipients are specified, output will >STDOUT\n");
    print("OPTIONS:   -d   Data center. Used in email subject\n");
    print("OPTIONS:   -t   ignore timestamp restrictions\n");
    exit(0);
}

our ($opt_t,$opt_d);
getopts('td:');
my $dc = $opt_d || 'UNKNOWN';
my ( $logfile, @recipients ) = @ARGV;
&usage unless ($logfile);

# don't include any record older than 24 hours
my $current_time = time();
my (undef,undef,undef,$md,$mn,$yr) = localtime($current_time);
my $midnight = timelocal(1,0,0,$md,$mn,$yr); # actually midnight + 1 second
my $oldest_allowed_timestamp = $midnight - (60*60*24);
my $max_message_size = 0; # fill this in later

my ($deletions,$processed,$submissions,$attacks,$hdr_sizes,$body_sizes,$too_big) = &parse_logfile($logfile);

if ( @recipients ) {
    &send_message(\@recipients, $deletions, $processed,$submissions,$attacks,$hdr_sizes,$body_sizes,$too_big);
} elsif ( @$deletions or @$processed or @$submissions ) {
    print &report_header;
    print &report_data($deletions, $processed,$submissions,$attacks,$hdr_sizes,$body_sizes,$too_big);
} else {
    print("\nNo data found!\n");
    exit(0);
}

exit(0);

# parse through the specified logfiles return @lines
sub parse_logfile
{
    my ( $file ) = @_;

    return unless ( -f $file );

    my (@deletions,@processed,@submissions,%attacks,@hdr_sizes,@body_sizes,@too_big);

    my ($egrep,$zegrep);
    foreach (qw(/usr/local/bin/egrep /usr/bin/egrep /bin/egrep)) {
      if ( -x $_ ) {
	$egrep = $_;
        last;
      }
    }
    die "cannot find a egrep to use" unless $egrep;
    foreach (qw(/usr/local/bin/zegrep /usr/bin/zegrep /bin/zegrep)) {
      if ( -x $_ ) {
	$zegrep = $_;
        last;
      }
    }
    die "cannot find a zegrep to use" unless $zegrep;

    my @m = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
    my %months;
    @months{@m} = (0..11);
    my $year = (localtime($current_time))[5];

    my $filter = "'(collector|probe_spool_monitor)'";
    my $cmd = sprintf("%s %s %s",
		      ($file =~ /\.gz|\.Z/) ? $zegrep : $egrep,
		      $filter,
		      $file);
    my $fh = new IO::File "$cmd |";

    while(my $line = <$fh>){

	chomp($line);

	if ($line =~ /attack_id=(\d+) header=(\d+) bytes body=(\d+)/) {
	    $attacks{$1}++;
	    push @hdr_sizes, $2;
	    push @body_sizes, $3;
	    next;
	}

	if ($line =~ /file is too big \((\d+) bytes, max allowed (\d+)/) {
	    push @too_big, $1;
	    $max_message_size = $2;
	}

	my (undef,$deletions) = ($line =~ /\[(INFO|NOTICE|ERROR)\] deleted\s+(\d+) probe(mail)? message/);
	my ($processed) = ($line =~ /attempts=(\d+)/);
	my ($stored)    = ($line =~ /stored=(\d+)/);
	my ($perf)      = ($line =~ /total_time=(\S+)/);
        my ($submission_type, $valid) = ($line =~ /inserted submission id=(?:\S+) of type=(\S+).*message_id=(\S+)/);
	# make the valid message prettier
	if ($valid) {
	    if ($valid =~ /^\d+$/) {
		$valid = 'stored';
	    } elsif ($valid eq 'unknown_due_to_error') {
		$valid = 'invalid';
	    }
	}

        next unless $deletions or $processed or $submission_type;

	# parse away the host, process, pid, etc
	my ($mon, $mday, $time, $host, $process, $string) =
	    ($line =~ /^(\w+)\s+(\d+) ([\d\:]+) ([\S]+) ([^\[]+)\[\d+\]\: (.*)/);
	next unless $mon and $mday and $time and $host and $process and $string;

	next if $host =~ /junkyard/;

	my ($hour, $min, $sec) = split(/:/, $time);
	my $unixtime = timelocal($sec,$min,$hour,$mday,$months{$mon},$year);
	next if !$opt_t and $unixtime < $oldest_allowed_timestamp;

	# host cleanup
	$host =~ s/\.brightmail\.com//i;

	my $e = {
	    host => $host,
	    time => $unixtime,
            hour => sprintf("%02d:00", $hour),
	    messages => $deletions || $processed,
	};

	if ($deletions) {
	    $e->{type} = 'deletion';
	    push @deletions, $e;
	} elsif ($processed) {
	    $e->{type} = 'processed';
	    $e->{stored} = $stored;
	    $e->{perf}   = $perf;
	    push @processed, $e;
	} elsif ($submission_type) {
            $e->{type} = $submission_type;
	    $e->{valid} = $valid;
            push @submissions, $e;
        }
    }

    $fh->close;

    return (\@deletions, \@processed, \@submissions, \%attacks, \@hdr_sizes, \@body_sizes, \@too_big);
}

sub send_message
{
    my ($recipients,$deletions,$processed,$submissions,$attacks,$hdr_sizes,$body_sizes,$too_big) = @_;

    return unless (@$deletions or @$processed or @$submissions);

    my ( $wday, $mon, $mday, $year ) = (
            localtime(time-86400) =~ /(\w+) (\w+)\s+(\d+) [\d\:]+ (\d+)/ );
    my $date = sprintf("%s %s %d %d", $wday, $mon, $mday, $year );

    my $output = "To: ".join(',', @$recipients)."\n";
    $output .= "From: MSO <dl-it-sf-cfio\@symantec.com>\n";
    $output .= "Reply-To: dl-it-sf-cfio\@symantec.com\n";
    $output .= "Subject: Probemail processed by $dc BLOC hosts: $date\n";
    $output .= "\n";
    $output .= &report_header;
    if ( @$deletions or @$processed or @$submissions) {
	$output .= &report_data($deletions,$processed,$submissions,$attacks,$hdr_sizes,$body_sizes,$too_big);
    }

    open(SENDMAIL, "|/usr/lib/sendmail -t");
    print SENDMAIL $output;
    close(SENDMAIL);
    die "sendmail error: $?" if $?;

    open(STORAGE_FOR_IT, ">/var/tmp/daily_probemail_stats.txt");
    print STORAGE_FOR_IT $output;
    close(STORAGE_FOR_IT);
}

sub report_data
{
    my ($deletions,$processed,$submissions,$attacks,$hdr_sizes,$body_sizes,$too_big) = @_;

    my @hours = map { sprintf("%02d:00", $_) } (0..23);

    my (%hourly_totals, %hosts_deleted, %hosts_processed, %hosts_performance, %hosts_stored, $total_deleted, %hourly_host_totals, $total_processed, $total_stored, %junk_stats, %fp_stats, $total_seconds_processing, %hourly_junk, $total_junk, $total_fp);

    # get the host-specific numbers
    foreach ( @$deletions ) {
	$total_deleted += $_->{messages};
	$hosts_deleted{$_->{host}} += $_->{messages};
        $hourly_totals{$_->{hour}}->{deleted} += $_->{messages};
        $hourly_host_totals{$_->{host}}{$_->{hour}}->{deleted} += $_->{messages};
    }

    foreach ( @$processed ) {
	$total_processed += $_->{messages};
	$total_stored += $_->{stored};
	$hosts_processed{$_->{host}} += $_->{messages};
	$hosts_performance{$_->{host}} += $_->{perf};
	$total_seconds_processing += $_->{perf};
	$hosts_stored{$_->{host}} += $_->{stored};
        $hourly_totals{$_->{hour}}->{processed} += $_->{messages};
        $hourly_totals{$_->{hour}}->{stored} += $_->{stored};
        $hourly_host_totals{$_->{host}}{$_->{hour}}->{processed} += $_->{messages};
        $hourly_host_totals{$_->{host}}{$_->{hour}}->{stored} += $_->{stored};
    }

    foreach (@$submissions) {
        if ($_->{type} eq 'junk') {
            $junk_stats{$_->{valid}}++;
	    $total_junk++;
	    $hourly_junk{$_->{hour}}->{$_->{valid}}++;
        } elsif ($_->{type} eq 'fp') {
            $fp_stats{$_->{valid}}++;
	    $total_fp++;
        }
    }

    $total_deleted   ||= 1; # avoid divide-by-zero errors
    $total_processed ||= 1; # avoid divide-by-zero errors
    $total_stored    ||= 1; # avoid divide-by-zero errors
    my $total_accepted = $total_deleted + $total_processed + scalar(@$too_big);

    my @submission_states = uniq(keys %junk_stats, keys %fp_stats);

    my $string = "Messages:\n";

    $string .= sprintf("accepted by BLOC Tools:    %10d\n", $total_accepted);

    $string .= sprintf("deleted before processing: %10d (%s%% of accepted)\n",
		       $total_deleted == 1 ? 0 : $total_deleted,
		       sprintf("%.1f",100*($total_deleted/$total_accepted)),
		       );

    $string .= sprintf("processed by collector:    %10d (%s%% of accepted)\n",
		       $total_processed == 1 ? 0 : $total_processed,
		       sprintf("%.1f",100*($total_processed/$total_accepted)),
		       );

    $string .= sprintf("large messages deleted:    %10d (%s%% of accepted)\n",
		       scalar(@$too_big),
		       sprintf("%.1f", 100*(scalar(@$too_big)/$total_accepted))
		       );

    $string .= sprintf("stored in MESSAGES:        %10d (%s%% of accepted, %s%% of processed)\n",
		       $total_stored == 1 ? 0 : $total_stored,
		       sprintf("%.1f", 100*($total_stored/$total_accepted)),
		       sprintf("%.1f", 100*($total_stored/$total_processed)),
		       );

    my $num_attacks = scalar(keys %$attacks) || 1;
    $string .= sprintf("attacks stored:            %10d (avg %s msgs/attack)\n",
		       scalar(keys %$attacks),
		       sprintf("%.1f", $total_stored / $num_attacks),
		       );

    my $sma = scalar(grep {$_==1} values %$attacks) || 1;
    $string .= sprintf("attacks appearing once:    %10d (%s%% of attacks)\n",
		       $sma,
		       sprintf("%.1f", 100*$sma/$num_attacks),
		       );

    my $mma = scalar(grep {$_>1} values %$attacks) || 1;
    $string .= sprintf("attacks appearing > once:  %10d (%s%% of attacks)\n",
		       $mma,
		       sprintf("%.1f", 100*$mma/$num_attacks),
		       );

    $string .= sprintf("avg multi-msg attack size: %10s\n",
		       sprintf("%.1f", ($total_stored - $sma)/$mma),
		       );

    my $average_hdr_size;
    if(@$hdr_sizes) {
      $average_hdr_size = sum(@$hdr_sizes) / scalar(@$hdr_sizes);
    }
    $string .= sprintf("avg bytes per header:      %10d\n",
		       $average_hdr_size);

    my $average_body_size;
    if(@$body_sizes) {
      $average_body_size = sum(@$body_sizes) / scalar(@$body_sizes);
    }
    $string .= sprintf("avg bytes per body:        %10d\n",
		       $average_body_size);

    my $too_big_average_size;
    if(@$too_big) {
      $too_big_average_size = sum(@$too_big) / scalar(@$too_big);
    }

    $string .= sprintf("avg bytes large msgs:      %10d (large => %d bytes)\n",
		       $too_big_average_size,
		       $max_message_size);

    $string .= "\nSubmissions:\n";

    $string .= sprintf("valid junk stored:   %10d (%s%% of all junk, %s%% of stored messages)\n",
		       $junk_stats{stored},
		       sprintf("%.1f",100*($junk_stats{stored}/$total_junk)),
		       sprintf("%.1f",100*($junk_stats{stored}/$total_stored)),
		       );

    foreach my $state (@submission_states) {
	next unless $junk_stats{$state};
	next if $state eq 'stored';
	$string .= sprintf("%-18s   %10d (%s%% of all junk)\n",
			   sprintf("%s junk:", $state),
			   $junk_stats{$state},
			   sprintf("%.1f",100*($junk_stats{$state}/$total_junk)),
			   );
    }

    $string .= sprintf("valid fp stored:     %10d (%s%% of all fps, %s%% of stored messages)\n",
		       $fp_stats{stored},
		       sprintf("%.1f", 100*($fp_stats{stored}/$total_fp)),
		       sprintf("%.1f", 100*($fp_stats{stored}/$total_stored)),
		       );


    foreach my $state (@submission_states) {
	next unless $fp_stats{$state};
	next if $state eq 'stored';
	$string .= sprintf("%-18s   %10d (%s%% of all fps)\n",
			   sprintf("%s fp:", $state),
			   $fp_stats{$state},
			   sprintf("%.1f",100*($fp_stats{$state}/$total_fp)),
			   );
    }

    $string .= "\n";

    #
    # show these values as numbers
    #

    $string .= sprintf("%-48s %-16s\n",
		       'Host-specific number of messages',
		       'performance for');

    $string .= sprintf("%-12s %-8s %-8s %-8s %-8s %-16s\n",
		       'Host', 'Tot', 'Del', 'Proc', 'Stor',
		       "msgs processed");
    $string .= sprintf("%-12s %-8s %-8s %-8s %-8s %-16s\n",
		       "-" x 12, "-" x 8, "-" x 8, "-" x 8, "-" x 8, "-" x 16);

    foreach my $h ( sort { $a cmp $b } uniq(keys %hosts_processed, keys %hosts_processed) ) {

	my $msgs_per_sec = sprintf("%s msgs/sec",
				   sprintf("%.3f",
					   $hosts_processed{$h} /
					   $hosts_performance{$h}),
				   );

	$string .= sprintf("%-12s %-8s %-8s %-8s %-8s %-18s\n",
			   $h,
			   $hosts_deleted{$h} + $hosts_processed{$h},
			   $hosts_deleted{$h} || 0,
			   $hosts_processed{$h} || 0,
			   $hosts_stored{$h} || 0,
			   $msgs_per_sec,
			   );
    }

    $string .= sprintf("\nCombined hourly totals:\n\n%-6s %-7s %-7s %-7s %-7s %-7s %-7s %-7s\n\n", 'Hour', 'Total', 'Del', '%Del', 'Proc', '%Proc', 'Stor', '%Stor');
    foreach my $h ( @hours ) {
      my $p = $hourly_totals{$h}->{processed} || 0;
      my $d = $hourly_totals{$h}->{deleted} || 0;
      my $s = $hourly_totals{$h}->{stored} || 0;
      my $t = $p + $d;
      my $percent_d = sprintf("%-7s",
                        sprintf("%.1f%%", $t ? 100*$d/$t : 0));
      my $percent_p = sprintf("%-7s",
                        sprintf("%.1f%%", $t ? 100*$p/$t : 0));
      my $percent_s = sprintf("%-7s",
                        sprintf("%.1f%%", $t ? 100*$s/$t : 0));

      $string .= sprintf("%-6s %-7d %-7d %-7s %-7d %-7s %-7d %-7s\n", $h, $t, $d, $percent_d, $p, $percent_p, $s, $percent_s);
    }

    $string .= "\n---------------------------------------\n";

    foreach my $host (sort {$a cmp $b} uniq(keys %hosts_processed, keys %hosts_processed)) {
	$string .= sprintf("\nHourly totals for %s:\n\n%-6s %-7s %-7s %-7s %-7s %-7s %-7s %-7s\n", $host, 'Hour', 'Total', 'Del', '%Del', 'Proc', '%Proc', 'Stor', '%Stor');
	foreach my $hour (@hours) {
	    my $p = $hourly_host_totals{$host}{$hour}->{processed} || 0;
	    my $d = $hourly_host_totals{$host}{$hour}->{deleted} || 0;
	    my $s = $hourly_host_totals{$host}{$hour}->{stored} || 0;
	    my $t = $p + $d;
	    my $percent_d = sprintf("%-7s",
				    sprintf("%.1f%%", $t ? 100*$d/$t : 0));
	    my $percent_p = sprintf("%-7s",
				    sprintf("%.1f%%", $t ? 100*$p/$t : 0));
	    my $percent_s = sprintf("%-7s",
				    sprintf("%.1f%%", $t ? 100*$s/$t : 0));

	    $string .= sprintf("%-6s %-7d %-7d %-7s %-7d %-7s %-7d %-7s\n", $hour, $t, $d, $percent_d, $p, $percent_p, $s, $percent_s);
	}
    }

    #
    # show these values as percentages of total mailflow
    #

    $string .= "\nOther breakdowns:\n";

    $string .= sprintf("\nHourly Junk:\n\n%-6s %-7s %-15s %-15s %-15s\n",
		       'Hour', 'Total', 'Stored', 'Ungrouped', 'Invalid');
    foreach my $h ( @hours ) {
	my $s = $hourly_junk{$h}->{stored} || 0;
	my $u = $hourly_junk{$h}->{ungrouped} || 0;
	my $i = $hourly_junk{$h}->{invalid} || 0;
	my $t = $s + $u + $i;
	my $percent_s = sprintf("%-7s",
				sprintf("%.1f%%", $t ? 100*$s/$t : 0));
	my $percent_u = sprintf("%-7s",
				sprintf("%.1f%%", $t ? 100*$u/$t : 0));
	my $percent_i = sprintf("%-7s",
				sprintf("%.1f%%", $t ? 100*$i/$t : 0));
	$string .= sprintf("%-6s %-7d %-7d %-7s %-7d %-7s %-7d %-7s\n",
			   $h, $t,
			   $s, $percent_s,
			   $u, $percent_u,
			   $i, $percent_i,
			   );

    }

    $string .= "\n\% of total mailflow received by all hosts\n";

    $string .= sprintf("%-12s %-8s %-8s %-8s %-8s\n",
		       'Host', '%Tot', '%Del', '%Proc', '%Stor');

    $string .= sprintf("%-12s %-8s %-8s %-8s %-8s\n",
		       "-" x 12, "-" x 8, "-" x 8, "-" x 8, "-" x 8);

    foreach my $h ( sort { $a cmp $b } uniq(keys %hosts_processed, keys %hosts_processed) ) {

        my $percent_deleted_total = sprintf("%-8s",
                        sprintf("%.3f%%", 100*($hosts_deleted{$h} / $total_deleted)));

        my $percent_processed_total = sprintf("%-8s",
                        sprintf("%.3f%%", 100*($hosts_processed{$h} / $total_processed)));

        my $percent_stored_total = sprintf("%-8s",
                        sprintf("%.3f%%", 100*($hosts_stored{$h} / $total_processed)));

        my $percent_total = sprintf("%-8s",
                        sprintf("%.3f%%", 100*(($hosts_processed{$h} + $hosts_deleted{$h}) / ($total_processed + $total_deleted))));

	$string .= sprintf("%-12s %-8s %-8s %-8s %-8s\n",
			   $h,
			   $percent_total,
			   $percent_deleted_total,
			   $percent_processed_total,
			   $percent_stored_total,
			   );
    }

    #
    # show these values as percentages of host-specific mailflow
    #

    $string .= "\n\% of mailflow received by each host\n";

    $string .= sprintf("%-12s %-8s %-8s %-8s %-8s %-8s\n",
		       'Host', '%Tot', '%Del', '%Proc', '%Stor');

    $string .= sprintf("%-12s %-8s %-8s %-8s %-8s %-8s\n",
		       "-" x 12, "-" x 8, "-" x 8, "-" x 8, "-" x 8);

    foreach my $h ( sort { $a cmp $b } uniq(keys %hosts_processed, keys %hosts_processed) ) {

        my $percent_deleted = sprintf("%-8s",
                        sprintf("%.3f%%", 100*($hosts_deleted{$h} / ($hosts_deleted{$h} + $hosts_processed{$h}))));

        my $percent_processed = sprintf("%-8s", sprintf("%.3f%%", 100*($hosts_processed{$h} / ($hosts_deleted{$h} + $hosts_processed{$h}))));

        my $percent_stored = sprintf("%-8s", sprintf("%.3f%%", 100*($hosts_stored{$h} / ($hosts_deleted{$h} + $hosts_processed{$h}))));

        my $percent_total = sprintf("%-8s",
                        sprintf("%.3f%%", 100*(($hosts_processed{$h} + $hosts_deleted{$h}) / ($total_processed + $total_deleted))));

	$string .= sprintf("%-12s %-8s %-8s %-8s %-8s\n",
			   $h,
			   '100.000%',
			   $percent_deleted,
			   $percent_processed,
			   $percent_stored,
			   );
    }

    $string .= <<EOF;

Legend

For host-specific #s:

Tot      - total number of messages received by this host
Del      - number of messages deleted by probe_spool_monitor on this host
Proc     - number of messages processed by collectors on this host
Stor     - number of messages stored by collectors on this host

%Tot     - percent of messages received by this host
%Del     - percent of messages deleted by this host (Del/Tot)
%Proc    - percent of messages processed by this host (Proc/Tot)
%Stor    - percent of messages stored this hour (Stor/Total)

For combined hourly #s, same as host-specific #s but broken down
on an hourly basis.

For per-host hourly #s, same as combined hourly #s but broken down by
host.

NOTE: these numbers are gleaned from the logfile.  The values are not
necessarily accurate because log entries may have been lost.  Hence,
these results are not perfect (but are all similarly imperfect:).

EOF

    $string .= '$Id: probemail_stats_from_logs.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $' . "\n";
    $string .= '$Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_log/files/opt/BMIops/probemail_stats_from_logs.pl,v $' . "\n";

    return $string;
}

sub report_header
{
    my $time = scalar(localtime($current_time));
    my $host = Sys::Hostname::hostname();
    my $scalar_oldest_time = scalar(localtime($oldest_allowed_timestamp));

    my $string;
    if ($opt_t) {
    $string = "Generated at $time US/Pacific\n\tfrom $host:$logfile\n";
    } else {
    $string = "Generated at $time US/Pacific\n\tfrom $host:$logfile\nAny items prior to $scalar_oldest_time US/Pacific were ignored\n";
    }

    $string .= "Please see the bottom of the report for a brief legend.\n\n";

    return $string;
}
