#!/usr/bin/perl -w

=pod

    SYMANTEC PROPRIETARY/CONFIDENTIAL--INTERNAL USE ONLY
    Copyright (c) 2008 Symantec Corporation.  All rights reserved.

    $Id: big_stats_from_logs.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $
    $Name:  $

=head1 NAME

big_stats_from_logs.pl - report on probe message too large to process

=head1 SYNOPSIS

big_stats_from_logs.pl -r email recipients -l log file -c colo [-h]

big_stats_from_logs.pl -r r1@symc.com -r r2@symc.com -l /var/log/bloclatency.1.gz -c SFO

=head1 OPTIONS

=over 4

=item C<-r RECIPIENT>

Email recipient(s) of this report.

=item C<-l LOGFILE>

Location of bloclatency log file.

=item C<-c COLO>

The colo that this report was generated for. This value is used in the email subject.

=item C<-h>

Print this screen

=back 

=head1 DESCRIPTION

B<msg_too_big_stats_from_logs.pl> parses the bloclatency log and reports the number of messages that were dropped due to their size. This report should be run on the central logging server in each colo, sometime after the nightly log rotate process has taken place.

=head2 SAMPLE CRON

    0 4 * * * /opt/BMIOps/big_stats_from_logs.pl -r peeps@brightmail.com -l /var/log/bloclatency.1.gz -c SFO

=head1 SAMPLE REPORT

    Subject: Submission Size Report for SFO: Sun Dec 7 2008

    Generated at Mon Dec  8 18:24:20 2008 US/Pacific
    	from log01.sfo:/var/log/bloclatency.1.gz
    Any items prior to Sun Dec  7 00:00:01 2008 US/Pacific were ignored

    Total large Junk  submissions:             6834
    Total large FP    submissions:              494
    Total large Fraud submissions:                0
    ------------------------------------------------
    Total large submissions:                   7328

    Average large Junk  message size:        957055 bytes
    Average large FP    message size:       1099388 bytes
    Average large Fraud message size:             0 bytes

    Maximum Junk  message size:              130000 bytes
    Maximum FP    message size:              204800 bytes

    Message size break down:

    Type         0-1M     1M-5M    5M-10M   >10M    
    ------------ -------- -------- -------- --------
    Junk             5489      802      518       25
    FP                384       81       29        0
    Fraud               0        0        0        0

    Hourly totals:

    Hour         Junk     FP       Fraud    Total   
    ------------ -------- -------- -------- --------
    00:00             317       18        0      335
    01:00             260       10        0      270
    02:00             208       33        0      241
    03:00             615       23        0      638
    04:00             302       17        0      319
    05:00             223       27        0      250
    06:00             275       19        0      294
    07:00             260       30        0      290
    08:00             463       24        0      487
    09:00             452       18        0      470
    10:00             443       23        0      466
    11:00             262       18        0      280
    12:00             297        8        0      305
    13:00             238       48        0      286
    14:00              97        0        0       97
    15:00             203       62        0      265
    16:00             247       11        0      258
    17:00             239       35        0      274
    18:00             363       19        0      382
    19:00             298        8        0      306
    20:00             202        8        0      210
    21:00             167        8        0      175
    22:00             153       11        0      164
    23:00             250       16        0      266

=cut

use Getopt::Long;
use IO::File;
use Pod::Usage qw/pod2usage/;
use POSIX qw(strftime);
use Sys::Hostname;
use Time::Local;
use strict;

my ( %bash, $opt_help, $opt_log, @opt_rcpt, $opt_colo );
my %types        = ( junk => 'Junk', fp => 'FP', fraud => 'Fraud', probe => 'Probe' );
my $grep         = '/usr/bin/zgrep';
my $grep_pattern = '-e ".* collector.*file is too big.*"';
my %buckets      = (
    0        => "0-1M",
    1000000  => "1M-2M",
    2000000  => "2M-3M",
    3000000  => "3M-5M",
    5000000  => "5M-10M",
    10000000 => ">10M",
);

my $current_time = time();
my ( undef, undef, undef, $md, $mn, $yr ) = localtime($current_time);
my $midnight = timelocal( 1, 0, 0, $md, $mn, $yr );
my $oldest_allowed_timestamp = $midnight - ( 60 * 60 * 24 );

GetOptions(
    "h"    => \$opt_help,
    "l=s"  => \$opt_log,
    "r=s@" => \@opt_rcpt,
    "c=s"  => \$opt_colo,
) or pod2usage( -verbose => 2 );

if ( $opt_help or !@opt_rcpt or !$opt_log or !$opt_colo ) {
    pod2usage( -verbose => 2 );
}

send_message( \@opt_rcpt, gen_report() ) if parse_log($opt_log);

############
# Subs     #
############
sub parse_log {
    my $file = shift;
    my ( $msg_size, $max_size, $type, %months );

    # make sure we can open the logfile and exectue grep
    die "Cannot open log file $file: $!\n" unless ( -r $file );
    die "Cannot execute $grep: $!\n"       unless ( -x $grep );

    # setup date stuff for unix time conversion later
    my @m = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
    @months{@m} = ( 0 .. 11 );
    my $year = ( localtime($current_time) )[5];

    # exectue grep
    my $cmd = sprintf( "%s %s %s", $grep, $grep_pattern, $file );
    my $fh = new IO::File "$cmd |";

    while ( my $line = <$fh> ) {
        chomp($line);

        # parse away the host, process, pid, etc
        my ( $mon, $mday, $time, $host, $process, $string ) = ( $line =~
              /^(\w+)\s+(\d+) ([\d\:]+) ([\S]+) ([^\[]+)\[\d+\]\: (.*)/ );

        # go to next line if we don't have everything we need
        next
          unless $mon
              and $mday
              and $time
              and $host
              and $process
              and $string;

        # ignore anything that is to old
        my ( $hour, $min, $sec ) = split( /:/, $time );
        my $unixtime =
          timelocal( $sec, $min, $hour, $mday, $months{$mon}, $year );
        next if $unixtime < $oldest_allowed_timestamp;

        # parse the too big message
        ( $msg_size, $max_size, $type ) =
          ( $string =~
              /\((\d+) bytes, max allowed (\d+) bytes, submission type (\w+)/
          );

        # store the values in a bash
        $bash{total_msg}++;
        $bash{$type}{max_size} = $max_size;
        $bash{$type}{total_msg}++;
        $bash{$type}{total_size} += $msg_size;
        $bash{$type}{$hour}{total_size} += $msg_size;
        $bash{$type}{$hour}{total_msg}++;

        #Bucketize message size
        $bash{$type}{buckets}{ bucketize( $type, $msg_size ) }++;
    }

    $fh->close;

    return %bash;
}

sub gen_report {
    my ( $hourly,   $sum_totals, $sum_avg_size, $sum_max_size, $sum_buckets );
    my ( $avg_size, $message,    @types,        @hourly,       @bvals );

    # create summary report
    foreach my $type ( sort keys %types ) {

        # total submissions
        $sum_totals .= sprintf( "Total large %-5s submissions:       %10d\n",
            $types{$type}, $bash{$type}{total_msg} || 0 );

        # avoid Illegal division by zero errors
        if ( !$bash{$type}{total_msg} ) {
            $avg_size = 0;
        }
        else {
            $avg_size = $bash{$type}{total_size} / $bash{$type}{total_msg};
        }

        # average total message size
        $sum_avg_size .=
          sprintf( "Average large %-5s message size:    %10d bytes\n",
            $types{$type}, $avg_size );

        # average total message size
        $sum_max_size .=
          sprintf( "Maximum %-5s message size:          %10d bytes\n",
            $types{$type}, $bash{$type}{max_size} )
          if $bash{$type}{max_size};

        # store the different types for the hourly section
        push( @types, $types{$type} );

    }

    # add total submissions
    $sum_totals .= sprintf( "%48s\n", "-" x 48 );
    $sum_totals .= sprintf( "Total large submissions:             %10d\n",
        $bash{total_msg} || 0 );

    # create hourly break down
    $hourly .= "Hourly totals:\n\n";
    $hourly .=
      sprintf( "%-12s %-8s %-8s %-8s %-8s\n", 'Hour', @types, 'Total' );
    $hourly .= sprintf( "%-12s %-8s %-8s %-8s %-8s\n",
        "-" x 12, "-" x 8, "-" x 8, "-" x 8, "-" x 8 );

    my @hours = map { sprintf( "%02d", $_ ) } ( 0 .. 23 );

    #grab the hourly message data
    foreach my $hour (@hours) {
        my $total = 0;
        my @hourly;

        # add hour
        push( @hourly, "$hour:00" );

        # add hourly data and total for each submission type
        foreach my $type ( sort keys %types ) {
            push( @hourly, $bash{$type}{$hour}{total_msg} || 0 );
            $total += $bash{$type}{$hour}{total_msg} || 0;
        }

        push( @hourly, $total );

        $hourly .= sprintf( "%-12s %8d %8d %8d %8d\n", @hourly );
    }

    # grab message size data
    foreach my $type ( sort keys %types ) {
        my @buckets;

        # add submissions type
        push( @buckets, $types{$type} );

        # add message size data for each submission type
        foreach my $bucket ( sort { $a <=> $b } keys %buckets ) {

            # get bucket desctiption so we can use if for the report header
            push( @bvals, $buckets{$bucket} )
              unless grep { $_ eq $buckets{$bucket} } @bvals;
            push( @buckets, $bash{$type}{buckets}{$bucket} || 0 );
        }

        $sum_buckets .= sprintf( "%-12s %8d %8d %8d %8d %8d %8d\n", @buckets );
    }

    # create message size break down
    my $bucket_head .= "Message size break down:\n\n";
    $bucket_head .= sprintf( "%-12s %-8s %-8s %-8s %-8s %-8s %-8s\n", 'Type', @bvals );
    $bucket_head .= sprintf( "%-12s %-8s %-8s %-8s %-8s %-8s %-8s",
        "-" x 12, "-" x 8, "-" x 8, "-" x 8, "-" x 8, "-" x 8, "-" x 8 );

    # put the report pieces together and return
    $message = report_header();
    $message .= "$sum_totals\n";
    $message .= "$sum_avg_size\n";
    $message .= "$sum_max_size\n";
    $message .= "$bucket_head\n";
    $message .= "$sum_buckets\n";
    $message .= "$hourly\n";

    return $message;
}

sub report_header {
    my $time               = scalar( localtime($current_time) );
    my $host               = Sys::Hostname::hostname();
    my $scalar_oldest_time = scalar( localtime($oldest_allowed_timestamp) );

    my $header =
        "Generated at $time US/Pacific\n\t"
      . "from $host:$opt_log\n"
      . "Any items prior to $scalar_oldest_time "
      . "US/Pacific were ignored\n\n";

    return $header;
}

sub send_message {
    my ( $recipients, $message ) = @_;

    return unless ( $message or $recipients );

    my ( $wday, $mon, $mday, $year ) =
      ( localtime( time - 86400 ) =~ /(\w+) (\w+)\s+(\d+) [\d\:]+ (\d+)/ );
    my $date = sprintf( "%s %s %d %d", $wday, $mon, $mday, $year );

    my $output = "To: " . join( ',', @$recipients ) . "\n";
    $output .= "From: Rohit Parmar <rohit_parmar\@symantec.com>\n";
    $output .= "Reply-To: rohit_parmar\@symantec.com\n";
    $output .= "Subject: Submission Size Report for $opt_colo: $date\n";
    $output .= "\n";
    $output .= $message;

    open( SENDMAIL, "|/usr/sbin/sendmail -t" );
    print SENDMAIL $output;
    close(SENDMAIL);
    die "sendmail error: $?" if $?;

    open( STORAGE_FOR_IT, ">/var/tmp/$0.txt" );
    print STORAGE_FOR_IT $output;
    close(STORAGE_FOR_IT);
}

sub bucketize {
    my ( $type, $msg_size ) = @_;
    my $last_bucket = 0;

    return unless ( $type or $msg_size );

    foreach my $bucket ( sort { $a <=> $b } keys %buckets ) {
        last if ( $msg_size < $bucket and $msg_size > $last_bucket );
        $last_bucket = $bucket;
    }

    return $last_bucket;
}
