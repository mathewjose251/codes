#/bin/bash
#
# $Id: bt-ard_log_analysis.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
# $Author: mathew $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_log/files/opt/BMIops/bt-ard_log_analysis.sh,v $
#

# Remove old Log Files from server
rm -rf /app/log/tmp/bt-ard-logs/*

# Create temp dir if it does not exist
if [ ! -d /app/log/tmp/bt-ard-logs/* ]
then
        mkdir -p /app/log/tmp/bt-ard-logs/*
fi

for host in `/usr/local/tools/bin/bmehost | grep bt-ard`
do
	scp -p ${host}:/opt/bloctools/server/logs/access.1.gz /app/log/tmp/bt-ard-logs/${host}-access.1.gz
done

/usr/bin/zmergelog /app/log/tmp/bt-ard-logs/bt-ard*-access.1.gz | webalizer -c /var/www/html/usage/bt-ard/webalizer.conf

# Migrate results to NMS
rsync -aze ssh /var/www/html/usage/bt-ard/* nms01.sac:/var/www/html/usage/bt-ard/
rsync -aze ssh /var/www/html/usage/bt-ard/* nms02.usw2:/var/www/html/usage/bt-ard/
rsync -aze ssh /var/www/html/usage/bt-ard/* nms02.usw2:/var/www/html/usage/bt-ard/
