#!/usr/bin/perl

use strict;
use warnings;

=pod

    SYMANTEC PROPRIETARY/CONFIDENTIAL--INTERNAL USE ONLY
    Copyright (c) 2008 Symantec Corporation.  All rights reserved.

    $Id: probe_creation_stats_from_logs.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $
    $Name:  $

=head1 NAME
probe_creation_stats_from_logs.pl - report on number of rpc-based probe
creations

=head1 SYNOPSIS

probe_creation_stats_from_logs.pl -r email recipients -l log file -t host [-hd]

probe_creation_stats_from_logs.pl -r r1@symc.com -r r2@symc.com -l
/var/log/bloclatency.1.gz -t bt-probe07

=head1 OPTIONS

=over 4

=item C<-r RECIPIENT>

Email recipient/s of this report.

=item C<-l LOGFILE>

Location of bloclatency log file.

=item C<[-t HOSTNAME]>

The host/s that this report was generated for. This value is used in the
email subject. If omitted, all hosts found in log file are included.

=item C<-h>

Print this screen

=item C<-d>

Debug mode. Print report to STDOUT only

=back

=head1 DESCRIPTION

B<msg_too_big_stats_from_logs.pl> parses the bloclatency log and reports the
number of rpc-based probe creations

=head2 SAMPLE CRON

    0 4 * * * /opt/BMIOps/probe_creation_stats_from_logs.pl \
        -r peeps@brightmail.com \
        -l /var/log/bloclatency.1.gz \
        -t bt-probe07

=head1 SAMPLE REPORT

    To: emmet_cassidy@symantec.com
    From: Emmet Cassidy <emmet_cassidy@symantec.com>
    Reply-To: emmet_cassidy@symantec.com
    Subject: Automatic Probe Creation Report for all hosts: Wed Oct 28 2009

    Generated at Thu Oct 29 14:45:06 2009 US/Pacific
        from spamlab-dev04:/var/log/bloclatency
    Any items prior to Thu Oct 15 00:00:01 2009 US/Pacific were ignored

    HH:      Total probes created   Total rejected requests      Total probe requests
    00:                        NA                        NA                        NA
    01:                        NA                        NA                        NA
    02:                        NA                        NA                        NA
    03:                        NA                        NA                        NA
    04:                        NA                        NA                        NA
    05:                        NA                        NA                        NA
    06:                        NA                        NA                        NA
    07:                        NA                        NA                        NA
    08:                        NA                        NA                        NA
    09:                        NA                        NA                        NA
    10:                        20                        78                        69
    11:                        NA                        NA                        NA
    12:                         5                        27                        34
    13:                        13                        92                        83
    14:                        20                        66                        61
    15:                         7                        38                        34
    16:                        19                       148                       101
    17:                        17                       126                        85
    18:                         9                        47                        42
    19:                        21                       103                        87
    20:                        12                        53                        45
    21:                        NA                        NA                        NA
    22:                        NA                        NA                        NA
    23:                        NA                        NA                        NA

=cut

use Getopt::Long;
use Pod::Usage qw/pod2usage/;
use Sys::Hostname;
use Time::Local;
use IO::File;

my ( $script ) = $0 =~ /.*\/(.*)/;
my $usage = "usage: $script <-f log_file>";

GetOptions(
    "h"    => \my $opt_help,
    "l=s"  => \my $opt_log,
    "r=s@" => \my @opt_rcpt,
    "t=s@" => \my @opt_host,
    "d"    => \my $opt_debug,
) or pod2usage( -verbose => 2 );

if ( $opt_help or !@opt_rcpt or !$opt_log ) {
    pod2usage( -verbose => 2 );
}

my %opt_hosts;
%opt_hosts = map { $_ => 1 } @opt_host if @opt_host;

my $current_time = time();
my ( undef, undef, undef, $md, $mn, $yr ) = localtime($current_time);
my $midnight = timelocal( 1, 0, 0, $md, $mn, $yr );
my $oldest_allowed_timestamp = $midnight - ( 60 * 60 * 24 );

my %meta_data = (
    requested => {
        regex => qr/sent a probe creation req/,
        report_hdr => 'Total probe requests'
    },
    rejected => {
        regex => qr/request rejected/,
        report_hdr => 'Total rejected requests'
    },
    created => {
        regex => qr/Created probe \S+ \(ID: \d+\) for given/,
        report_hdr => 'Total probes created'
    },
);

my %data;
if ( parse_log($opt_log, \%data) ) {
    send_message( \@opt_rcpt, gen_report(\%data) )
        and printf "sent report to %s", join( ', ', @opt_rcpt );
}

exit;

sub parse_log {
    my ( $log_file, $data ) = @_;

    die "parse_log wants log_file, a string"
        if !defined $log_file;
    die "parse_log wants data, a HREF"
        if !$data or ref $data ne 'HASH';

    my %months;
    my @m = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
    @months{@m} = ( 0 .. 11 );
    my $year = ( localtime($current_time) )[5];

    my $grep         = '/usr/bin/zgrep';
    my $grep_pattern = '-e "bloc\/apache\/probes"';

    my $cmd = sprintf( "%s %s %s", $grep, $grep_pattern, $log_file );
    my $FH = new IO::File "$cmd |";

#    -e $log_file or die "log file $log_file not found";
#    open my $FH, '<', $log_file or die "$!. $log_file";

    while ( my $line = <$FH> ) {
        my ( $mon, $mday, $time, $host, $process, $string )
            = $line =~ /^(\w+)\s+(\d+) ([\d\:]+) (\S+) ([^\[]+)\[\d+\]: (.*)/;

        # ignore anything not from bloc/apache/probes
        next if !$process or $process ne 'bloc/apache/probes';

        # ignore anything not from the given host (allow all if not given)
        next if %opt_hosts and !$opt_hosts{$host};

        # ignore anything that is too old
        my ( $hour, $min, $sec ) = split( /:/, $time );
        my $unixtime =
            timelocal( $sec, $min, $hour, $mday, $months{$mon}, $year );
        next if $unixtime < $oldest_allowed_timestamp;

        # now try and match the line against a set of regexes
        for my $data_label ( keys %meta_data ) {
            my $regex = $meta_data{$data_label}{regex};
            if ( $line =~ /$regex/ ) {
                $data->{sprintf "%.02d", $hour}{$data_label}++;
            }
        }
    }
    close $FH;

    return 1;
}

sub report_header {
    my $time               = scalar( localtime($current_time) );
    my $host               = Sys::Hostname::hostname();
    my $scalar_oldest_time = scalar( localtime($oldest_allowed_timestamp) );

    my $header =
        "Generated at $time US/Pacific\n\t"
      . "from $host:$opt_log\n"
      . "Any items prior to $scalar_oldest_time "
      . "US/Pacific were ignored\n\n";

    return $header;
}

sub gen_report {
    my ( $data ) = @_;

    die "gen_report wants data, a HREF"
        if !$data or ref $data ne 'HASH';

    my $report = report_header();

    # make data headers
    $report .=  sprintf "HH: %25s %25s %25s\n",
                    map { $meta_data{$_}{report_hdr} } sort keys %meta_data;
    for my $hour ( 0 .. 23 ) {
        my @vals;
        for my $label ( sort keys %meta_data ) {
            my $val = !exists $data->{$hour}         ? 'NA'
                    : !exists $data->{$hour}{$label} ? 'NA'
                    :                                  $data->{$hour}{$label}
                    ;
            push @vals, $val;
        }
        $report .= sprintf "%02d: %25s %25s %25s\n", $hour, @vals;
    }

    return $report;
}

sub send_message {
    my ( $recipients, $message ) = @_;

    die "parse_log wants recipients, a ARRAYREF"
        if !$recipients or ref $recipients ne 'ARRAY';
    die "send_message wants message, a string"
        if !defined $message;

    my ( $wday, $mon, $mday, $year ) =
        ( localtime( time - 86400 ) =~ /(\w+) (\w+)\s+(\d+) [\d\:]+ (\d+)/ );
    my $date = sprintf( "%s %s %d %d", $wday, $mon, $mday, $year );

    my $output = "To: " . join( ',', @$recipients ) . "\n";
    $output .= "From: Emmet Cassidy <emmet_cassidy\@symantec.com>\n";
    $output .= "Reply-To: emmet_cassidy\@symantec.com\n";
    my $host = keys %opt_hosts ? join ', ', keys %opt_hosts : 'all hosts';
    $output .= "Subject: Automatic Probe Creation Report for $host: $date\n";
    $output .= "\n";
    $output .= $message;

    my ( $script ) = $0 =~ /.*\/(.*)/;

    if ( $opt_debug ) {
        print $output;
        return 1;
    }

    open SENDMAIL, "|/usr/sbin/sendmail -t"
        or die "error creating handle to sendmail. $!";
    print SENDMAIL $output;
    close SENDMAIL;
    die "sendmail error: $?" if $?;

    my $storage = "/var/tmp/$script.txt";
    open my $STORAGE_FOR_IT, '>', $storage or die "$!. $storage";
    print $STORAGE_FOR_IT $output;
    close $STORAGE_FOR_IT;

    return 1;
}
