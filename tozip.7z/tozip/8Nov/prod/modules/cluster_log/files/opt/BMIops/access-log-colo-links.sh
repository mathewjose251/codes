#!/bin/bash

# make some directories and symlinks so I can run the same script that runs against
# the combined data directory on these separate data directories.
# I love comments
 
  if [ $# -ne 1 ];then
    echo " Usage: $0 <days>";
    exit 1
  fi

  days=$1

  cd /app/log/tmp/aztec-logs/access || exit 1

  mkdir databash
  mkdir databash

  cd databash && rm -fR 200*
  ( cd ../data && ls ) | xargs mkdir 
  ( cd ../data && find . -name "bash*" -mtime -${days} ) | while read x;do y=`echo $x|sed 's/^..//'`; ln -s ../../data/$y $x;done

  cd ../databash && rm -fR 200*
  ( cd ../data && ls ) | xargs mkdir 
  ( cd ../data && find . -name "bash*" -mtime -${days} ) | while read x;do y=`echo $x|sed 's/^..//'`; ln -s ../../data/$y $x;done

