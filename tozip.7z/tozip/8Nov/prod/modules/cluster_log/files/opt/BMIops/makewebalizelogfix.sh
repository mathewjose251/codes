#!/bin/bash

# process some files with webalizer
# presumse files are gziped
# see usage

me=`basename $0`


usage_fn() {
  echo "Usage: $0: <days> <datadir> <webalizer-conf-file>"
  echo
  echo " days is how many days before now to find data directories to process"
  echo " datadir is a directory which contains a subdirectory structure full of directorys named YYYY-MM-DD"
  echo "  In each subdirectory, must be only valid zipped log files otherwise this may corrupt"
  echo "  or just fail to process"
  echo
  echo "This script is the process part of steps of get, process, and post web logs"
  echo "Frailities assumed include using the filesystem as a datasource, and relying on"
  echo "  webalizer state files from prior runs to be usable"
  echo 
  echo " A future enhancement to this would be to use a manifest, and to understand webalizer state"
  echo "  file structure enough to gracefully handle webalizer problems"
  echo
  exit
}

d_fn() {
  date "+%Y%m%d-%H%M"
}
err_fn() {
  echo $1
  exit 1
}

if [ $# -ne 3 ];then
  usage_fn;
fi

echo $1 | egrep '[^0-9]'
if [ $? -eq 0 ];then
  echo " $1 not a number"
  usage_fn
fi
days=$1
if [ ! -d $2 ];then
  echo "$2 not a directory"
  usage_fn
fi
datadir=$2
if [ ! -f $3 ];then 
  echo "$3 not a file"
  usage_fn
fi
webconf=$3
logfile=`pwd`/$me.out

( 
  cd $datadir || err_fn "can't change dir to $datadir"
  list=`find . -type d -mtime -${days}| egrep "200|201"|sort`
  set -e
  set -x
  for dir in $list; do 
    echo "`d_fn` Begin Processing $dir" | tee -a $logfile
    /usr/bin/zmergelog $dir/* | sed -e 's/^::1 /127.0.0.1 /' | webalizer -c $webconf | tee -a $logfile
    echo "`d_fn` End Processing $dir" | tee -a $logfile
  done
)

