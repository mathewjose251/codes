#/bin/bash
#
# $Id: ipr-server_log_analysis.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
#

# How many times should we retry the host
num_try=6
sleep=60

# Remove old Log Files
rm -rf /app/log/tmp/ipr-server-logs/*

# Create temp dir if it does not exist
if [ ! -d /app/log/tmp/ipr-server-logs ]
then
        mkdir -p /app/log/tmp/ipr-server-logs
fi

for host in `/usr/local/tools/bin/bmehost | grep ipr-web\[0-9\]\[0-9\]`
do
	try=1
	
	while [ $try -lt $num_try ]
	do
		scp -p ${host}:/app/log/httpd/ipr_server-access_log.1.gz /app/log/tmp/ipr-server-logs/${host}-access_log.1.gz
		if [ $? -ne 0 ]
		then
			echo "SCP failed on $host: Try=$try sleeping for $sleep..."
			sleep $sleep
			let try=try+1
		else
			break
		fi
	done
done

#
# Remove the IPv6 crap from the compressed logs which zmergelog barfs on...
for f in /app/log/tmp/ipr-server-logs/*-access_log.1.gz
do
    TEMP="${f}.tmp"
    /usr/bin/zgrep -v '^::1' < $f | gzip -9c > $TEMP
    /bin/mv -f $TEMP $f
done

/usr/bin/zmergelog /app/log/tmp/ipr-server-logs/*-access_log.1.gz | webalizer -c /var/www/html/usage/ipr-server/webalizer.conf

# Migrate results to NMS
rsync -aze ssh /var/www/html/usage/ipr-server/* nms02.usw2:/var/www/html/usage/ipr-server/
rsync -aze ssh /var/www/html/usage/ipr-server/* nms02.usw2:/var/www/html/usage/ipr-server/
