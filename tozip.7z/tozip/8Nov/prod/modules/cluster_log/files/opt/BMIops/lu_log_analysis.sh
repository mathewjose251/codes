#!/bin/bash
#
#

# collect and process httpd log files daily
#
# Maintenance: 
# ------------
# you may want to periodically delete
# the log files it stores on log01:/var/tmp/esp-logs
# but since they can be very useful to have, I would wait 
# until you surely dont want any old ones. 

export PATH

PATH=$PATH:/usr/local/tools/bin;
COLLECT=/opt/BMIops/collect.sh
DAYS=10
HOSTGRP=aztec
SRCDIR=/app/log/aztec
#
# the LOGGRP value does more than one thing.
# 1) It acts as the wildcard of filenames to collect off the source hosts
# 2) It is the directory name of the processing area for the defined files
# 3) It is the web directory name
# I should change that and have separate variables next time around
#
LOGGRP="consumerstats submit"
LOGSPEC="consumerstats submit"
LOGDIR=/tmp
PROCESSDIR=/app/log/tmp/aztec-logs
COLOS=bashbash"
# uses mtime of files, so will catch from a backlogs if recollection occured
WEBALIZEFINDDAYS=10

d_fn() { d=${type}_log; }

# collect the files and stage them
for type in $LOGSPEC; do
  FILES=${type}*gz
  LOGFILE=$LOGDIR/collect.sh.${type}.log
  $COLLECT $DAYS $HOSTGRP $SRCDIR/$FILES $PROCESSDIR/${type} > $LOGFILE 2>&1
done

WEBDIR=/var/www/html/usage

# webalize the files
for type in $LOGSPEC; do
  d_fn
  /opt/BMIops/makewebalize.sh $WEBALIZEFINDDAYS $PROCESSDIR/${type}/data $WEBDIR/${type}/webalizer.conf 
done

# send the web content to the  nms server
for type in $LOGSPEC; do
  d_fn
  rsync -aze ssh $WEBDIR/$type/* nms02.usw2:$WEBDIR/$type/
  rsync -aze ssh $WEBDIR/$type/* nms02.usw2:$WEBDIR/$type/
done


# and hey, we're done.
