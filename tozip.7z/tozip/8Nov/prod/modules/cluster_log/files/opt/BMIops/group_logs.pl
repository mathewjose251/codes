#!/usr/bin/perl

=head1 NAME

group_logs.pl - Brightmail log scraper for alerts and paging

=head1 SYNOPSIS

group_logs.pl [options]

OPTIONS:

--pagefile=B<paging-file>
--logfile=B<log-file>
--config=B<config-file>
--email_to=B<user@host[,...]>
--page_to=B<PAGE-TO-OPTION-STRING>
--page_at=B<minimum-occurance-number>
--page_server_cnt=B<number>
--page_every=B<number>
--email_during_page=B<[YN]>
--subject=B<'string'>
--page_subject=B<'string'>

PAGE-TO-OPTION-STRING:

B<user@host:page-on-alert:paging-frequency:paging-count:paging-interval>

B<page-on-alert>    C<Y|N>

B<paging-freqency>  C<number>

B<paging-count>     C<number>

B<paging-interval>  C<number>
    
=begin RCS

    $Id: group_logs.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $
    $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_log/files/opt/BMIops/group_logs.pl,v $

=end

=cut

use Getopt::Long;
use lib '/usr/lib/perl5';
use Date::Parse;
use List::Util qw(first);

my ( %alert_recipients, %processes );

# file: logfile to scan for
# email_to format: email1,email2,email3
# page_to format: <address>:Page on Alert Match:Min Frequency:Page Every Min
# page_at: Default Frequency of Errors at which page is sent
# page_every: Default interval at which page is sent

my (
    $opt_pagefile,     $opt_file,       $opt_config_file,
    $opt_email_to,     $opt_page_to,    $opt_page_at,
    $opt_page_srvrcnt, $opt_page_every, $opt_email_during_page,
    $opt_subject
);

GetOptions(
    'pagefile=s'          => \$opt_pagefile,
    'logfile=s'           => \$opt_file,
    'config_file|c=s'     => \$opt_config_file,
    'email_to=s'          => \$opt_email_to,
    'page_to=s'           => \$opt_page_to,
    'page_at=i'           => \$opt_page_at,
    'page_server_cnt=i'   => \$opt_page_srvrcnt,
    'page_every=i'        => \$opt_page_every,
    'email_during_page=s' => \$opt_email_during_page,
    'subject=s'           => \$opt_subject,
    'page_subject=s'      => \$opt_page_subject,
);

if ( !$opt_file or !$opt_config_file ) {
    usage();
    print "--logfile/--config_file parameter is missing. ";
    print "Can't work without that. Good bye...\n\n";
    exit;
}

require "$opt_config_file";

if ( !$opt_subject ) {
    $opt_subject = "BLOC Errors for";
}

#
# default minutes
my $MIN_DUR_FOR_PAGE       = 10;

#
# default minutes
my $MAX_DUR_FOR_PAGE       = 10;
#
# default number of occurances to qualify for paging
my $MIN_OCCURANCE_FOR_PAGE = 6;

#
# default number of occurances to qualify for paging
my $MAX_OCCURANCE_FOR_PAGE = 6;

my @opt_email_to = split( /,/, $opt_email_to );
my @opt_page_to  = split( /,/, $opt_page_to );

#
# if not defined then assign default
if ( !$opt_page_at ) {
    $opt_page_at = $MIN_OCCURANCE_FOR_PAGE;
}

# if not defined then assign default
if ( !$opt_page_srvrcnt ) {
    $opt_page_srvrcnt = 4;
}

#
# if not defined then assign default
if ( !$opt_page_every ) {
    $opt_page_every = $MIN_DUR_FOR_PAGE;
}

#
# if not defined then assign default
if ( !$opt_email_during_page ) {
    $opt_email_during_page = "N";
}
else {
    $opt_email_during_page = "Y";
}

foreach $line (@opt_email_to) {
    ( my $l_email, my $l_email_during_page ) = split( /:/, $line );

    #
    # if not defined then assign default
    if ( !$l_email_during_page ) {
        $l_email_during_page = $opt_email_during_page;
    }

    if ( $l_email_during_page eq "N" ) {
        push @recipients, $l_email;
    }
    else {
        push @alert_only_recipients, $l_email;
    }

}

# store recipient specific preferences into a table
foreach $line (@opt_page_to) {
    my ( $l_email, $l_pageon_alert, $l_paging_freq, $l_paging_srvrcnt,
        $l_paging_interval )
      = split( /:/, $line );
    if ( !$l_email ) {
        next;
    }
    my $trigram = get_trigram_bash($l_email);

    #
    # if not defined then assign default
    if ( !$l_pageon_alert ) {
        $l_pageon_alert = N;
    }
    #
    # if not defined then assign default
    if ( !$l_paging_freq ) {
        $l_paging_freq = $opt_page_at;
    }
    if ( !$l_paging_srvrcnt ) {
        # if not defined then assign default
        $l_paging_srvrcnt = $opt_page_srvrcnt;
    }
    if ( !$l_paging_interval ) {
        # if not defined then assign default
        $l_paging_interval = $opt_page_every;
    }

    # store data in a table
    $alert_recipient{$trigram}[0] = $l_email;
    $alert_recipient{$trigram}[1] = uc($l_pageon_alert);
    $alert_recipient{$trigram}[2] = $l_paging_freq;
    $alert_recipient{$trigram}[3] = $l_paging_srvrcnt;
    $alert_recipient{$trigram}[4] = $l_paging_interval;

    if ( $l_paging_freq > $MAX_OCCURANCE_FOR_PAGE )
    {
        # adjust value of variables
        $MAX_OCCURANCE_FOR_PAGE = $l_paging_freq;
    }

    if ( $l_paging_freq < $MIN_OCCURANCE_FOR_PAGE )
    {
        # adjust value of variables
        $MIN_OCCURANCE_FOR_PAGE = $l_paging_freq;
    }

    if ( $l_paging_interval < $MIN_DUR_FOR_PAGE )
    {
        # adjust value of variables
        $MIN_DUR_FOR_PAGE = $l_paging_interval;
    }

    if ( $l_paging_interval > $MAX_DUR_FOR_PAGE )
    {
        # adjust value of variables
        $MAX_DUR_FOR_PAGE = $l_paging_interval;
    }
}    # end of foreach

# declare variables
my $EntriesExpired = 0;
my $PageFile;

if ( !$opt_pagefile ) {
    $PageFile = "/tmp/newLastPaged.txt";    # This is the database file.
}
else {
    $PageFile = "$opt_pagefile";
}

my $SomethingToPage = 0;
my $logfile         = $opt_file;
my $currtime        = time();
my %PageFileErrors;
my %errors;

# get time in the past 60 second
my $mytime = show_past_time(60);    # seconds

# store this as number as this will help compare
my $ptime_number = str2time($mytime);

if ( -e "$PageFile" ) {
    my ($mtime) = ( stat($PageFile) )[9];
    if ( ( $currtime - $mtime ) < ( $MAX_DUR_FOR_PAGE * 60 ) ) {

        # Following few lines suppose to read all trigrams and their timestamp
        # and remove all expired trigrams.
        if ( !( open( PAGEFILE, "<$PageFile" ) ) ) {
            die "Unable to open file <<<<$PageFile>>>> for reading";
        }

        my $line;
        while ( $line = <PAGEFILE> ) {
            ( my $errormailtrigram, my $trigram, my $email, my $timestamp ) =
              split( /:/, $line );
            if (
                ( $currtime - $timestamp ) < (
                    (
                        exists $alert_recipient{$email}[4]
                        ? $alert_recipient{$email}[4]
                        : $MIN_DUR_FOR_PAGE
                    ) * 60
                )
              )
            {
                # if trigram is not expired then keep
                if ( $timestamp > 0 ) {
                    $PageFileErrors{$errormailtrigram}[0] = $trigram;
                    $PageFileErrors{$errormailtrigram}[1] = $email;
                    $PageFileErrors{$errormailtrigram}[2] = $timestamp;
                }
            }
            else {
                $EntriesExpired = 1;
            }

        }
        close(PAGEFILE);
    }
}

# Parse error log and group errors
parse_logfile($logfile);

if ( @recipients or @alert_only_recipients )
{
    # if recipient list is defined then send emails
    if ( $SomethingToPage > 0 )
    {
        # if any of the error was pagable then email to alert only
        # recipients too
        send_message( \@alert_only_recipients, 1, \%errors );
        push @recipients, @alert_only_recipients;

        if ( first { $errors{$_}->{string} =~ /CRITICAL/ } keys %errors ) {
            $opt_subject = "[Paging Event] [CRITICAL] $opt_subject";
        }
        else {
            $opt_subject = "[Paging Event] $opt_subject";
        }

    }

    if (@recipients) {
        send_message( \@recipients, 0, \%errors ); # email all error messages
    }

    # If pageable event then write to page file

    if (   $SomethingToPage > 0
        or $EntriesExpired > 0 )
    {
        # if it ended up paging or anyof the entries have expired then
        # maintain local error database
        open( PAGEFILE, ">$PageFile" )
          or die "Unable to open file <<<<$PageFile>>>> for writing";
        foreach my $errormailtrigram (
            sort { $PageFileErrors{$b}[2] <=> $PageFileErrors{$a}[2] }
            keys %PageFileErrors )
        {

            # prune out empties
            if ($errormailtrigram) {
                print PAGEFILE
"$errormailtrigram:$PageFileErrors{$errormailtrigram}[0]:$PageFileErrors{$errormailtrigram}[1]:$PageFileErrors{$errormailtrigram}[2]:\n";
            }
        }
        close(PAGEFILE);
    }
}
elsif ( keys %errors ) {
    # Else print all errors on the screen
    print &report_header;
    print report_data( 0, \%errors );
    print &report_footer;
}
else {
    print("\nNo errors found!\n");
}

exit(0);

sub usage {
    print<<EOF;
Usage:
    group_logs.pl --logfile=FILENAME
                  --email_to=RECIPIENT1:EMAIL-AT-PAGING-EVENT(Y/N),...
                  --page_to=RECIPIENT1:PAGE-FOR-ALERT-STRING(Y/N):
                                PAGE-AFTER-N-ERRORS:
                                PAGE-AFTER-N-SERVER-REPORTED-ERRORS:
                                PAGE-EVERY-N-MIN,...
                  --page_at=DEFAULT-PAGE-AFTER-N-ERRORS
                  --page_every=DEFAULT-PAGE-EVERY-N-MIN
                  --email_during_page=DEFAULT-EMAIL-AT-PAGING-EVENT(Y/N)

EOF
    return;
}

# parse through the specified logfiles return @lines
sub parse_logfile {
    my ($file) = @_;

    return unless ( -f $file );
    if ( $file =~ /\.gz|\.Z/ ) {
        open( FILE, "zcat $file |" );
    }
    else {
        open( FILE, "tail -200 $file|" );
    }

    while ( my $line = <FILE> ) {

        # parse away the host, process, pid, etc
        my ( $month, $time, $server, $process, $string ) = ( $line =~
              /^(\w+\s+\d+) ([\d\:]+) ([\S]+) ([^\[]+)\[\d+\]\: (.*)/ );

        # remove Brightmail.com extension
        $server =~ s/\.brightmail\.com//g;

        # see if the line should be ignored as exception
        my $ShouldIignore =
          grep_pattern( "(" . join( "|", @EXCEPTION_LIST ) . ")", $line );

        # Don't try to page by default i.e. 0 - Don't page, 1 - Page
        my $ShouldIpage = 0;

        # added by manoj to see if the string is of interest

        next unless $time and $process and $string;

        if ( str2time("$month $time") - $ptime_number >= 0
            and !$ShouldIignore )
        {

            # do some bloc-specific cleaning
            my $clean_string = $string;

            # fpreader md5 bash bad length bug
            $clean_string =~
              s/md5 bash for report_id=[a-z0-9\-]+/md5 bash for report_id/;
            $clean_string =~ s/[0-9]+/0/g;

            # added by manoj on 09/30 to remove server names which can
            # create different sig
            $clean_string =~ s/[a-z\-_\.]+0([a-z\-_\.]+| )/0/g;

            # I am commenting the following line as this could cause
            # more groups.  I'll rather group on first 40-60 characters
            # than the whole string.
            my $trigram = get_trigram_bash( substr( $clean_string, 0, 40 ) );

            $errors{$trigram}{count}++;

            # If Last Page file is older and you can now page then check
            # if this alert requires paging
            $ShouldIpage =
              grep_pattern( "(" . join( "|", @ALERT_SEARCH_STRING ) . ")",
                $line );

            if ( $ShouldIpage > 0 ) {
                send_page_to( $trigram, $errors{$trigram}{count}, 0, 1 );
            }

            # push server if not already there

            my @test2 = grep { /$server/ } @{ $errors{$trigram}{servers} };
            if ( !scalar @test2 ) {
                push( @{ $errors{$trigram}{servers} }, $server );
            }

            # See if thresholding needs to apply to the error
            my $ShouldIalert = grep_pattern(
                "(" . join( "|", ( keys %ALERT_STRING_THRESHOLD ) ) . ")",
                $line );

            if ($ShouldIalert) {
                $ShouldIalert =
                  check_string_for_threshold( $line,
                    $errors{$trigram}{count} );
                send_page_to( $trigram, $errors{$trigram}{count}, 0, 1 )
                  if ( $ShouldIalert > 0 );
            }
            else {
                my $unique_srvrcnt =
                  scalar( @{ $errors{$trigram}{servers} } );

                # if specified minimum number of occurance has occured
                # then it automatically becomes a paging event
                if ( $errors{$trigram}{count} >= $MIN_OCCURANCE_FOR_PAGE ) {
                    send_page_to( $trigram, $errors{$trigram}{count},
                        $unique_srvrcnt, 0 );
                }
            }

            # push time if not already there
            my @test1 = grep { /$time/ } @{ $errors{$trigram}{times} };
            if ( !scalar @test1 ) {
                push( @{ $errors{$trigram}{times} }, $time );
            }

            $errors{$trigram}{process} = $process;
            $errors{$trigram}{string}  = $string;

            # If page event is not already set up and has not been
            # previously paged and is pageable then set the bit to page
            # now. If Page has been previously sent then no need to page.
        }
    }

    close(FILE);

}

sub send_message {
    my ( $recipients, $pageonly, $errors ) = @_;
    my ($string);
    my @cached_pager_list;

    my @datepcs = split( /\s+/, scalar localtime );

    return unless ( keys %$errors );

    my ( $wday, $mon, $mday, $year ) =
      ( localtime( time - 86400 ) =~ /(\w+) (\w+)\s+(\d+) [\d\:]+ (\d+)/ );
    my $date = sprintf( "%s %s %d %d", $wday, $mon, $mday, $year );
    if ( !$pageonly )
    {
        #
        # if email is meant to be sent instead of page create recipient list
        # else recipient list is set per error
        open( SENDMAIL, "|/usr/lib/sendmail -t" );
        print SENDMAIL "From: DL-ENG-ASE-BLOC-Alerts\@symantec.com\n";
        print SENDMAIL "To: " . join( ",", @$recipients ) . "\n";
        print SENDMAIL "Subject: $opt_subject ", scalar(localtime), "\n\n";
    }

    my @pager_list;
    push @pager_list, @recipients;

    foreach my $trigram ( sort { $$errors{$b}{count} <=> $$errors{$a}{count} }
        keys %$errors )
    {
        # prune out the empties
        unless ( $$errors{$trigram}{count} && $$errors{$trigram}{process} ) {
            delete $$errors{$trigram};
            next;
        }

        if ( $pageonly && $pageonly eq $$errors{$trigram}{page} )
        {
            # for page only errors
            $string = "";
            foreach my $pageraddress ( @{ $errors{$trigram}{recipients} } ) {
                my @test1 = grep { /$pageraddress/ } @cached_pager_list;

                if ( !scalar @test1 )
                {
                    # cache pager address so that one error is sent per
                    # recipient to avoid bombarding them with pages
                    push @pager_list,        $pageraddress;
                    push @cached_pager_list, $pageraddress;
                }
            }
            if (@pager_list) {
                #
                # page to all recipients
                open( SENDMAIL, "|/usr/lib/sendmail -t" );
                print SENDMAIL "From: DL-ENG-ASE-BLOC-Alerts\@symantec.com\n";
                print SENDMAIL "To: " . join( ",", @pager_list ) . "\n";
                print SENDMAIL "Subject: [Page $opt_page_subject] ",
                join( " ", @datepcs[ 1, 2, 3 ] ), "\n\n";
            }
            else {
                next;
            }
        }

        if (
            $pageonly eq $$errors{$trigram}{page}
            or !$pageonly
          )
        {
            $string .= report_data($trigram);
        }

        if ( $pageonly && $pageonly eq $$errors{$trigram}{page} )
        {
            # send page now.
            print SENDMAIL report_data($trigram);
            close(SENDMAIL);
            die "sendmail error: $?" if $?;
        }

        @pager_list = ();
    }

    if ( !$pageonly ) {
        # print footer for email only alerts
        $string = sprintf(
            "%d unique errors in %d processes found in %s\n\n",
            scalar( keys %$errors ),
            scalar( keys %processes ), $logfile
        ) . $string;

        print SENDMAIL &report_header;
        print SENDMAIL $string;
        print SENDMAIL &report_footer;
        close(SENDMAIL);
        die "sendmail error: $?" if $?;
    }
}

sub send_page_to {
    # Primary purpose of this procedure is to figure out who to send
    # pages for errors. This checks frequency with each recipients frequency
    # which was defined earlier in the script.
    my $errortrigram   = shift;
    my $errorcount     = shift;
    my $unique_srvrcnt = shift;
    my $alertcheck     = shift;

    foreach my $mailtrigram ( keys %alert_recipient ) {
        if ( !exists $PageFileErrors{ $errortrigram . $mailtrigram } ) {
            if (
                (
                        $alertcheck > 0
                    and $alert_recipient{$mailtrigram}[1] eq "Y"
                )
                or (    $errorcount > 0
                    and $errorcount >= $alert_recipient{$mailtrigram}[2] )
                or (    $unique_srvrcnt > 0
                    and $unique_srvrcnt >= $alert_recipient{$mailtrigram}[3] )
              )
            {
                my @test1 =
                  grep { /$alert_recipient{$mailtrigram}[0]/ }
                  @{ $errors{$errortrigram}{recipients} };

                if ( !scalar @test1 ) {
                    push(
                        @{ $errors{$errortrigram}{recipients} },
                        $alert_recipient{$mailtrigram}[0]
                    );
                    $PageFileErrors{ $errortrigram . $mailtrigram }[0] =
                      $errortrigram;
                    $PageFileErrors{ $errortrigram . $mailtrigram }[1] =
                      $mailtrigram;
                    $PageFileErrors{ $errortrigram . $mailtrigram }[2] =
                      $currtime;
                    $SomethingToPage = 1;
                    $errors{$errortrigram}{page} = 1;
                }
            }
        }
    }

}

sub report_data {
    my $trigram = shift;

    my ($string);

    $processes{ $$errors{$trigram}{process} } = 1;

    $string .= sprintf( "Name: %s\n", $errors{$trigram}{process} );
    $string .= sprintf( "On: %s\n",
        join( " ", group_servers( @{ $errors{$trigram}{servers} } ) ) );

    my $errorstring = $errors{$trigram}{string};
    $errorstring =~ s/\[ERROR\] //;
    $errorstring =~ s/  / /g;

    $string .= sprintf( "Msg:  %s\n", $errorstring );

    #$string .= sprintf("Msg:  %s\n",
    #($errors{$trigram}{string}=~s/\[ERROR\]//));
    $string .= sprintf( "#Time: %d\n", $errors{$trigram}{count} );

    if ( $$errors{$trigram}{count} == 1 ) {
        $string .= sprintf( "At: %s\n", $errors{$trigram}{times}[0] );
    }
    elsif ( $$errors{$trigram}{count} <= 6 ) {
        $string .=
          sprintf( "At: %s\n", join( ", ", @{ $errors{$trigram}{times} } ) );
    }
    else {
        $string .= sprintf(
            "At: %s\n",
            join( ", ",
                ( @{ $errors{$trigram}{times} } )[ 0 .. 2 ],
                '...',
                ( @{ $errors{$trigram}{times} } )[ -3 .. -1 ] )
        );
    }
    $string .= "\n";

    return $string;
}

sub report_header {
    my $time = scalar(localtime);
    my $host = `/bin/hostname`;
    chomp($host);

    return "Generated at $time from $host:$logfile\n\n";
}

sub report_footer {
    my $host = `/bin/hostname`;
    chomp($host);
    my $string = qq{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  The data in this report was generated by

    $host:$0

  The script uses trigrams to sort errors.  Please note that because
  errors are grouped using fuzzy techniques, the error log may prove
  more enlightening for the non-casual observer.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
};
    return $string;
}

sub get_trigram_bash {
    my ($string) = @_;

    # some locals
    my ( %trigrams, %tmp, @bin, $i, $item, $trigram );

    # lowercase both header and body, suck 'em into local scalars so
    # that we don't affect the actual values...
    $string = lc($string);

    # count the body
    count_string_trigrams( \%tmp, $string, 1 );

    # create a list of trigrams reverse sorted by value. Then splice
    # off the top $trigram_keylength @list items as a new @list, and
    # use the resulting @list values to repopulate %$trigrams.
    my @list = sort { $tmp{$b} <=> $tmp{$a} } keys %tmp;
    foreach $item ( splice( @list, 0, 4 ) ) {
        $trigrams{$item} = $tmp{$item};
    }

    # now, let's use @list again to determine the min and max.  First,
    # rebuild the list by using values %$trigrams.  Then determine max
    # and min by grabbing the first and last elements from @list.
    @list = sort { $b <=> $a } values %trigrams;
    my $max = $list[0];     # first list element
    my $min = $list[-1];    # last list element

    # normalize the trigrams ( 0 -> $trigram_buckets ).  Skip if
    # ($max-$min)==0 because the normalization will actually hurt the
    # data if that's the case... also skip the normalization if we
    # have 0 buckets (which should be fairly uncommon...)
    if ( ( $max - $min ) > 0 ) {

        # assign $trigram_buckets+1 count of evenly dispersed 'bins'
        # holding the values to be used for comparison.  For instance,
        # if $trigram_buckets # is 9, there will be 10 bins, $bin[0]
        # thru $bin[9].  The value of # the bin will be used to
        # normalize the trigram score.  This will # add a degree of
        # fuzziness to the grouping.

        # The value of each bin will be dispersed fairly evenly
        # between $min and $max.  Everything beteen 0 and $min counts
        # as 0 (there # shouldn't be any of these values).  The
        # $bin[$i] value is the # starting point of the bin; ending
        # point is not defined (rather, # the starting point of the
        # *next* bin - $bin[$i+1] - will be used # to define the
        # endpoint of $bin[$i]).

        # Set $bin[0] to 0 right off, since we're basically saying
        # that anything between 0 and $bin[$min+1] is set to 0...
        $bin[0] = 0;
        for ( $i = 1 ; $i <= 2 ; $i++ ) {
            $bin[$i] = ( ( ( $max - $min ) * ( $i / 3 ) ) + $min );
        }

        # for instance, if keylength=10, and if $trigram_buckets=9,
        # and if the unnormalized trigram scores are 5, 6, 6, 7, 8,
        # 11, 12, 14, 18, and 25, $min would be 5, $max would be 25,
        # and @bins would have the following 10 elements:

        # $bin[0] = 0  # ( because we set it that way :)
        # $bin[1] = ( ( 25 - 5 ) * (1/10) ) + 5 ) => 7
        # $bin[2] = ( ( 25 - 5 ) * (2/10) ) + 5 ) => 9
        # $bin[3] = ( ( 25 - 5 ) * (3/10) ) + 5 ) => 11
        # $bin[4] = ( ( 25 - 5 ) * (4/10) ) + 5 ) => 13
        # $bin[5] = ( ( 25 - 5 ) * (5/10) ) + 5 ) => 15
        # $bin[6] = ( ( 25 - 5 ) * (6/10) ) + 5 ) => 17
        # $bin[7] = ( ( 25 - 5 ) * (7/10) ) + 5 ) => 19
        # $bin[8] = ( ( 25 - 5 ) * (8/10) ) + 5 ) => 21
        # $bin[9] = ( ( 25 - 5 ) * (9/10) ) + 5 ) => 23

        # next, iterate through the values in the $trigrams
        # bash. foreach value, add both the trigram and the normalized
        # value for the trigram to the referenced string.

        # For instance, continuing our example from above, normalized
        # scores would be:

        # 5  => 0; # $bin[0] because 5  <= $bin[0]
        # 6  => 0; # $bin[0] because 6  >= $bin[0] and < $bin[1]
        # 7  => 1; # $bin[1] because 7  >= $bin[1] and < $bin[2]
        # 8  => 1; # $bin[1] because 8  >= $bin[1] and < $bin[2]
        # 11 => 3; # $bin[3] because 11 >= $bin[3] and < $bin[4]
        # 12 => 3; # $bin[3] because 12 >= $bin[3] and < $bin[4]
        # 14 => 4; # $bin[4] because 14 >= $bin[4] and < $bin[5]
        # 18 => 6; # $bin[6] because 18 >= $bin[6] and < $bin[7]
        # 25 => 9; # $bin[9] because 25 >= $bin[9]

        # do each trigram...
        foreach $item ( sort keys %trigrams ) {

            # decrease the bin[$i] until we get a hit
            for ( $i = 2 ; $i >= 0 ; $i-- ) {
                if ( $trigrams{$item} >= $bin[$i] ) {
                    $trigram .= sprintf( "%3s%1d", $item, $i );
                    last;
                }    # end if
            }    # end for
        }    # end foreach

    }    # end if ( $max-$min == 0 )

    # oops, this is a VERY small message, no trigram appears more than
    # once (or, MUCH less likely, all trigrams appear an equal number
    # of times but more than once (which is astronomically unlikely in
    # even a very small message).  Create $$p_trigram differently,
    # namely be iteratating over the sorted trigrams and using
    # $trigram_buckets for each of them.
    else {
        foreach $item ( sort keys %trigrams ) {
            $trigram .= sprintf( "%3s%1d", $item, 2 );
        }
    }

    return $trigram;
}

sub trigram_text_cleaner {
    my $string = shift;

  # remove anything that's not a lowercase letter or whitespace or number from
  # $$string.
    $$string =~ s/[^0-9a-z_\s]//g;

    # truncate one or more spaces or underscores into a single underscore
    $$string =~ s/[\s_]+/_/g;
}

sub count_string_trigrams {
    my ( $trigrams, $string, $adder, $start, $end ) = @_;

    # if this is a null addition, return immediately
    return if ( $adder <= 0 );

    # cleanup the string
    trigram_text_cleaner( \$string );

    # define the search positions, allow overrides
    if ($end) {
        $end = length($string) - 2 if ( $end > length($string) );
    }
    else {
        $end = length($string) - 2;
    }

    if ($start) {
        return if ( $start > $end );
    }
    else {
        $start = 0;
    }

    # iterate over the trigrams, add $adder to each substr
    for ( my $i = $start ; $i < $end ; $i++ ) {
        $$trigrams{ ( substr( $string, $i, 3 ) ) } += $adder;
    }
}

sub show_past_time {
    $sec_before = shift;

    my @months = (
        "Jan", "Feb", "Mar", "Apr", "May", "Jun",
        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    );

    my $tstamp = time() - $sec_before;
    my ( $y, $m, $d, $ss, $mm, $hh ) =
      ( localtime($tstamp) )[ 5, 4, 3, 0, 1, 2 ];
    $y += 1900;

    return "$months[$m] $d $hh:$mm"

}

# Find strings with pattern
sub grep_pattern {
    my $pattern = shift;
    my $string  = shift;
    return 1 if $string =~ m/$pattern/;
    return 0;
}

# Find strings with pattern and see if they meet threshold
sub check_string_for_threshold
{
    my $string    = shift;
    my $err_count = shift;

    foreach my $pattern ( keys %ALERT_STRING_THRESHOLD ) {
        return 1
          if ( ( $string =~ m/$pattern/ )
            and $err_count >= $ALERT_STRING_THRESHOLD{$pattern}[0] );
    }

    return 0;
}

sub group_servers {
    my @servers = @_;

    my %serverlist = ();
    my @return_string;

    foreach my $line (@servers) {
        my ( $cluster, $c_number ) = ( $line =~ /([a-zA-Z_-]+)(\d+)/ )
          ;    # grep for pattern for clustername - number - domain

        if ($c_number)
        {
            # if it is a well defined cluster then push name and number
            my @test1 = grep { /$c_number/ } @{ $serverlist{$cluster} };
            if ( !scalar @test1 ) {
                push( @{ $serverlist{$cluster} }, $c_number );
            }
        }
        else {
            # if not well defined then just push the name of the server
            $serverlist{$line} = "";
        }
    }
    foreach $clustername ( sort keys %serverlist ) {
        push @return_string,
          ( "$clustername", join( ",", @{ $serverlist{$clustername} } ),
            " " );
    }

    return (@return_string);
}

