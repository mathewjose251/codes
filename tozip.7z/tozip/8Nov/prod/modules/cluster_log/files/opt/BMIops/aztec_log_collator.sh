#!/bin/bash 
export PERL5LIB=/opt/bloctools/lib/perl5:/opt/bloctools/lib/perl5/i386-linux
export ORACLE_HOME=/u01/app/product/oracle/8.1.7
export BLOC_CONFIG_FILE=/opt/BMIops/aztec_log_collator.cfg

yesterday=`perl -e '$t=time -86400; @a=localtime($t);printf("%d-%02d-%02d\n",$a[5]+1900,$a[4]+1,$a[3]);'`;

/usr/bin/zmergelog /var/tmp/aztec-logs/access/data/$yesterday/* | /opt/BMIops/aztec_log_collator.pl

#/bin/gunzip -c /var/tmp/aztec-logs/aztec-access.gz | /opt/BMIops/aztec_log_collator.pl
