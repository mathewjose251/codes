#!/bin/sh -x

DATE=`/bin/date +"%b%d%Y"`
SCP=/usr/bin/scp
SSH=/usr/bin/ssh
CHMOD=/bin/chmod
CHOWN=/bin/chown
CP=/bin/cp
MV=/bin/mv
GZIP=/bin/gzip

for hosts in aztec01 aztec02 aztec03 aztec04 aztec05 aztec06 aztec07
do
	$SSH $hosts "$CP -p /app/log/aztec/access /var/tmp/access_log"
done

for hosts in aztec01 aztec02 aztec03 aztec04 aztec05 aztec06 aztec07
do
	$SCP -pqCB $hosts:/var/tmp/access_log /space/logs/aztec/${hosts}/access.$DATE 
	$SSH $hosts "/bin/rm /var/tmp/access_log"
	$GZIP -9 /space/logs/aztec/${hosts}/access.$DATE
done

$CHMOD -R 755 /space/logs/aztec
$CHOWN -R root:root /space/logs/aztec
