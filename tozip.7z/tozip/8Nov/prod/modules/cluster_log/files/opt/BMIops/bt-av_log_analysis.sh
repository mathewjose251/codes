#/bin/bash
#
# $Id: bt-av_log_analysis.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
# $Author: mathew $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_log/files/opt/BMIops/bt-av_log_analysis.sh,v $
#

# Remove old Log Files from server
rm -rf /app/log/tmp/bt-av-logs/*

# Create temp dir if it does not exist
if [ ! -d /app/log/tmp/bt-av-logs/* ]
then
        mkdir -p /app/log/tmp/bt-av-logs/*
fi

for host in `/usr/local/tools/bin/bmehost | grep bt-av`
do
	scp -p ${host}:/opt/bloctools/server/logs/access.1.gz /app/log/tmp/bt-av-logs/${host}-access.1.gz
done

/usr/bin/zmergelog /app/log/tmp/bt-av-logs/bt-av*-access.1.gz | webalizer -c /var/www/html/usage/bt-av/webalizer.conf

# Migrate results to NMS
rsync -aze ssh /var/www/html/usage/bt-av/* nms02.usw2:/var/www/html/usage/bt-av/
rsync -aze ssh /var/www/html/usage/bt-av/* nms02.usw2:/var/www/html/usage/bt-av/
