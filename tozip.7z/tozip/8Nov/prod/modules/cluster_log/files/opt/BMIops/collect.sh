#/bin/bash
#
#

export PATH

usage_fn() {
  echo "Usage: $0 <days> <hostspec> <dirspec> <target-dir>"
  echo
  echo "where days is 1,2,3,..., the number of days in the past from today to collect the logs"
  echo
  echo "where hostgroup is a filter to grep  the number of days in the past from today to collect the logs"
  echo
  echo "target dir will be used to create a data/<YYYY-MM-DD> directory on the target host"
  echo
}
 
if [ $# -ne 4 ];then
  usage_fn;
  exit
fi
days=$1
case $days in
  *[^0-9]*)  echo;echo "sorry, I did not understand that number of days, $days?";echo
    usage_fn;
    exit 1;;
  *);;
esac

hostspec=$2
dirspec=$3
targetdir=$4

bme_dfunc() {
  perl -ne 's/Nov/11/;s/Oct/10/;s/Dec/12/;s/Jan/01/;s/Feb/02/;s/Mar/03/;s/Apr/04/;s/May/05/;s/Jun/06/;s/Jul/07/;s/Aug/08/;s/Sep/09/; 
    /\[(\d+)\/(\d+)\/(\d+):(\d+):(\d+)/; 
    $d=$1;$m=$2;$y=$3;$h=$4;$M=$5; 
    printf("%4d-%02d-%02d_%02d%02d\n",$y,$m,$d,$h,$M);'
}

PATH=$PATH:/usr/local/tools/bin;

td=$targetdir/data

for host in `/usr/local/tools/bin/bmehost | grep $hostspec|sort`;do 
   echo "going to collect on: $host"

  	for f in `ssh $host "find $dirspec -mtime -${days}"`;do
          td=${targetdir}/data
          nf=`basename $f|sed 's/\..*z//'`
          tf=${host}-${nf}

          line=`ssh -n $host "zcat $f|head -1"`
          dtag=`echo $line | bme_dfunc` 
          echo $dtag | egrep '00-00'
          if [ $? -eq 0 ];then
             echo " could not grab the date spec out of the file, perhaps it is not valid"
             echo " skipping file: `ssh -n $host ls -l $f`"
             continue
          fi
          dayt=`echo $dtag|awk -F"_" '{print $1}'`

          td=${td}/${dayt}
          tf=${td}/${tf}_${dtag}

	  mkdir -p $td

          echo "writing file: ${tf} to $targetdir"
          checkline=`ls -l ${tf} 2>/dev/null`
          echo $checkline | grep ${tf} > /dev/null
          if [ $? -eq 0 ];then # found file on target
            echo "target file: $tf exists in targetdir"
            if [ ! -z "$BME_COLLECT_OVERWRITE" ]; then
              echo "BME_COLLECT_OVERWRITE is set, overwriting existing target file"
              echo "Press CTRL-C within 20 seconds to interrupt"
              sleep 23
	      rsync -azue ssh $host:$f ${tf}
            else
              echo "BME_COLLECT_OVERWRITE is not set, leaving existing target file in place"
            fi 
          else
	    rsync -aze ssh $host:$f ${tf}
          fi
        done

done

exit
