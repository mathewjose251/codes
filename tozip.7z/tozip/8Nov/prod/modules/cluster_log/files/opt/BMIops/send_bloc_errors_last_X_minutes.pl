#!/usr/bin/perl
# $Id: send_bloc_errors_last_X_minutes.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $

use constant MIN_ERRORS_TO_REPORT => 50;
use constant DELETE_SOME_ERRORS => 1;

# ignore errors from certain (broken) hosts (if DELETE_SOME_ERRORS)
my %ignore_hosts = map {$_=>1} qw//;

use File::Basename;
use Time::Local;
use Sys::Hostname;
use Getopt::Std;

sub uniq {
    my %seen;
    return grep {!($seen{$_}++)} @_;
}

sub usage {
    print("usage: $0 [OPTIONS] minutes logfile [recipient1]..[recipientN]\n");
    print("       if no recipients are specified, output will >STDOUT\n");
    print("OPTIONS:   -t   ignore timestamp restrictions\n");
    exit(0);
}

getopts('ts:');
my ( $minutes, $logfile, @recipients ) = @ARGV;
usage unless ($minutes and $logfile);
usage() unless ($minutes !~ /\D/);
usage() unless (-f $logfile);

# don't include any record older than minutes
my $current_time = time();
my $oldest_allowed_timestamp = $current_time - ($minutes * 60);

# jump through hoops to id the hosts from the IPs (which is all we get
# from some system logging)
my $dirname = dirname($0);

my %errors = &parse_logfile($logfile);

if ( %errors and @recipients ) {
    &send_message(\@recipients, \%errors);
} elsif ( %errors ) {
    print &report_header;
    print &report_data(\%errors);
    print &report_footer;
} else {
    # just exit quietly
    exit(0);
}

exit(0);

# parse through the specified logfiles return @lines
sub parse_logfile {
    my ( $file ) = @_;

    my %errors;

    return unless ( -f $file );
    if ( $file =~ /\.gz|\.Z/ ) {
	open(FILE, "zcat $file |");
    } else {
	open(FILE, "<$file");
    }

    my @m = qw(Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec);
    my %months;
    @months{@m} = (0..11);
    my $year = (localtime($current_time))[5];

    my $previous; # handle 'last message repeated N time' case

    while(my $line = <FILE>) {

	chomp($line);

	if ( $previous and $line =~ /last message repeated (\d*) time/ ) {
	    $errors{$previous}{count} += $1;
	    next;
	};

	# parse away the host, process, pid, etc
	my ($mon, $mday, $time, $host, $process, $string) =
	    ($line =~ /^(\w+)\s+(\d+) ([\d\:]+) ([\S]+) ([^\[]+)\[\d+\]\: (.*)/);
	next unless $mon and $mday and $time and $host and $process and $string;

	my ($hour, $min, $sec) = split(/:/, $time);
	my $unixtime = timelocal($sec,$min,$hour,$mday,$months{$mon},$year);
	next if !$opt_t and $unixtime < $oldest_allowed_timestamp;

	# host cleanup
	$host =~ s/\.brightmail\.com//i;
	if ( $host =~ /\[\d+\.\d+\.\d+\.\d+/ and %known_hosts ) {
	    my ($lookup) = ($host =~ /\[(\d+\.\d+\.\d+\.\d+)\./);
	    $host = $known_hosts{$lookup} || $host;
	}

        next if DELETE_SOME_ERRORS and $ignore_hosts{$host};

	# /usr/bin/logger is different on Solaris and Linux... compensate
	my $real_string = $string;
	$string =~ s/^[ ]*\[[\w\d\. ]+\][ ]*//;

	# if $string begins with [A-Z+], lop that off, it screws up
	# the silly trigrams for short error messages
	$string =~ s/^[ ]*\[[A-Z]+\][ ]*//;

	my $trigram = &get_trigram_bash($string) || next;

	$errors{$trigram}{count}++;
	push(@{$errors{$trigram}{times}}, $time);
	push(@{$errors{$trigram}{hosts}}, $host);
	$errors{$trigram}{process} = $process;
	$errors{$trigram}{string}  = $real_string;

	$previous = $trigram;
    }

    close(FILE);

    # prune out some of the errors we don't want to receive
    if (DELETE_SOME_ERRORS) {
	foreach my $trigram (keys %errors) {
	    delete $errors{$trigram}
	    if ($errors{$trigram}{process} eq 'aztec_apache') or
		(($errors{$trigram}{process} eq 'handle_test_ack') and
		 ($errors{$trigram}{string} =~ /ERR_SOCKET_CONNECT/)) or
		($errors{$trigram}{process} eq 'hotmail_status_update') or
		($errors{$trigram}{process} eq 'apache' and
		 $errors{$trigram}{count} < MIN_ERRORS_TO_REPORT and
		 $errors{$trigram}{string} =~ /File does not exist/) or
		($errors{$trigram}{process} eq 'apache' and
		 $errors{$trigram}{string} =~ /mod_ssl: SSL handshake failed/) or
		($errors{$trigram}{process} eq 'apache' and
		 $errors{$trigram}{string} =~ /sslv3 alert certificate expired/) or
		($errors{$trigram}{process} eq 'junk_alert_daemon' and
		 $errors{$trigram}{string} =~ /failure in end_message/) or
		($errors{$trigram}{process} eq 'junk_alert_daemon' and
		 $errors{$trigram}{string} =~ /value as an ARRAY reference/) or
		$errors{$trigram}{string} =~ /Mason error/ or
		($errors{$trigram}{process} eq 'junk_grabber' and
		 $errors{$trigram}{string} =~ /connection reset by peer/i);
	}
    }

    # remove empties
    delete $errors{''};
    return %errors;
}

sub send_message
{
    my ( $recipients, $errors ) = @_;

    return unless %$errors;

    open(SENDMAIL, "|/usr/lib/sendmail -t");
    print SENDMAIL "To: ".join(',', @$recipients)."\n";
    print SENDMAIL "From: dl-it-sf-cfio\@symantec.com\n";
my $title = $opt_s || 'BLOC';
    print SENDMAIL "Subject: ".scalar(localtime($current_time)).": $title Errors in last 10 minutes (from ".Sys::Hostname::hostname().")\n";
    print SENDMAIL "\n";
    print SENDMAIL &report_header;
    print SENDMAIL &report_data($errors);
    #print SENDMAIL &report_footer;
    close(SENDMAIL);

    die "sendmail error: $?" if $?;
}

sub report_data
{
    my ($errors) = @_;

    my ( %processes, $string, $total );

    foreach my $trigram (
	 sort { $$errors{$b}{count} <=> $$errors{$a}{count} } keys %$errors ) {

	# prune out the empties
	unless ( $$errors{$trigram}{count} && $$errors{$trigram}{process} ) {
	    delete $$errors{$trigram};
	    next;
	}


	$total += $$errors{$trigram}{count};

	$processes{$$errors{$trigram}{process}} = 1;

	$string .= sprintf("Occurrences: %d\n",
			   $$errors{$trigram}{count});
	$string .= sprintf("Process:     %s\n",
			   $$errors{$trigram}{process});
        my @hosts = uniq(@{$errors{$trigram}{hosts}});
	if ( @hosts == 1 ) {
	    $string .= sprintf("Host:        %s\n", $hosts[0]);
	} else {
	    $string .= sprintf("Hosts:       %s\n", join(", ", @hosts));
	}
	if ($$errors{$trigram}{count} == 1) {
	    $string .= sprintf("Time:        %s\n",
			       $$errors{$trigram}{times}[0]);
	} elsif ($$errors{$trigram}{count} <= 6) {
	    $string .= sprintf("Times:       %s\n",
			       join(", ", @{$errors{$trigram}{times}}));
	} else {
	    $string .= sprintf("Times:       %s\n",
			       join(", ",
				    (@{$errors{$trigram}{times}})[0..2], '...',
				    (@{$errors{$trigram}{times}})[-3..-1]));
	}
	$string .= sprintf("Error:       %s\n",
			   $$errors{$trigram}{string});
	$string .= "\n";
    }

    my $num_errors = scalar(keys %$errors);
    my $num_procs  = scalar(keys %processes);
    $string = sprintf("%s (%d total) in %s found in %s\n\n",
		      $num_errors == 1 ? '1 unique error' : "$num_errors unique errors",
		      $total,
		      $num_procs == 1 ? '1 process': "$num_procs processes",
		      $logfile) . $string;

    return $string;
}

sub report_header
{
    my $time = scalar(localtime($current_time));
    my $host = Sys::Hostname::hostname();
    my $scalar_oldest_time = scalar(localtime($oldest_allowed_timestamp));

    if ($opt_t) {
    return "Generated at $time $ENV{TZ}\n\tfrom $host:$logfile\n\n";
    } else {
    return "Generated at $time $ENV{TZ}\n\tfrom $host:$logfile\nAny errors prior to $scalar_oldest_time $ENV{TZ} were ignored\n\n";
    }
}

sub report_footer
{
    my $host = Sys::Hostname::hostname();
    my $revision = q$Revision: 1.3 $;
    my ($version) = ($revision =~ /evision: ([\d\.]+)/);

    my $string = qq{
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

  The data in this report was generated by

    $host:$0 v$version

  The script uses trigrams to sort errors.  Please note that because
  errors are grouped using fuzzy techniques, the error log may prove
  more enlightening for the non-casual observer.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
};
    return $string;
}

sub get_trigram_bash
{
    my ( $string ) = @_;

    my ( %trigrams, %tmp, @bin, $trigram );

    $string = lc($string);

    &count_string_trigrams(\%tmp, $string, 1);

    my @list = sort { $tmp{$b} <=> $tmp{$a} || $a cmp $b } keys %tmp;
    foreach my $item ( splice(@list,0,4) ) {
        $trigrams{$item} = $tmp{$item};
    }

    @list = sort { $b <=> $a } values %trigrams;
    my $max = $list[0];  # first list element
    my $min = $list[-1]; # last list element

    if ( ($max - $min) > 0 ) {
        $bin[0] = 0;
        for ( my $i=1; $i<=2; $i++ ) {
            $bin[$i] = ( ( ($max - $min) * ($i / 3 ) )
			 + $min );
        }
        foreach my $item ( sort {$a cmp $b} keys %trigrams ) {
	    for ( my $i=2; $i>=0; $i-- ) {
		if ( $trigrams{$item} >= $bin[$i] ) {
		    $trigram .= sprintf("%3s%1d", $item, $i);
		    last;
		} # end if
	    } # end for
	} # end foreach

    } # end if ( $max-$min == 0 )

    else { # very small message
        foreach my $item ( sort keys %trigrams ) {
            $trigram .= sprintf("%3s%1d", $item, 2);
        }
    }

    return $trigram;
}

sub trigram_text_cleaner
{
    my $string = shift;

    # cleanup of DBD::Oracle syslog artifacts
    $$string =~ s/\\n//g;
    $$string =~ s/\^i//gi;

    $$string =~ s/[^a-z_\s]//g;
    $$string =~ s/[\s_]+/_/g;
}

sub count_string_trigrams
{
    my ( $trigrams, $string, $adder, $start, $end ) = @_;
    return if ( $adder <= 0 );
    &trigram_text_cleaner(\$string);
    if ( $end ) {
        $end = length($string) - 2 if ( $end > length($string) );
    } else {
        $end = length($string) - 2;
    }
    if ( $start ) {
        return if ( $start > $end );
    } else {
        $start = 0;
    }
    for (my $i=$start; $i<$end; $i++) {
        $$trigrams{ (substr($string, $i, 3)) } += $adder;
    }
}
