#!/bin/sh
#
PATH=/dist/tools/bin:/dist/tools/sbin:/usr/local/sbin:/usr/sbin:/sbin:/usr/local/bin:/usr/bin:/bin:/usr/local/etc:/usr/etc:/etc:/usr/bin/X11:/usr/ucb:/usr/ccs/bin
export PATH
# Figure out where we're running

host=`hostname`
DIR_TO_CHECK='aztec\n
              rules\n
              rda'

DIR_TO_CHECK='aztec'
SCRIPT_DIR='/var/www/html/usage'
TEXT_SEARCH_STRING="(Total Hits)|\
                    (Total KBytes)|\
                    (Code 200 - OK)|\
                    (Code 403 - Forbidden)|\
                    (Code 503 - Service Unavailable)|\
                    (KBytes per Day)|\
                    (Hits per Day)"

CURR_DATE=`date '+%Y%m%d'` 
CURR_YM=$1

TEXT_SEARCH_STRING=`echo $TEXT_SEARCH_STRING|sed s/\|\ \(/\|\(/g`

echo $DIR_TO_CHECK|while read FOLDERNAME 
do
  out=`egrep -A1 "$TEXT_SEARCH_STRING"  "$SCRIPT_DIR/$FOLDERNAME/usage_$CURR_YM.html"|sed s/"<[^>]*>"//g|sed s/"--"/":"/g`
  echo $CURR_DATE:$FOLDERNAME: $out|awk -F: '{ for (i = 3; i <= NF; i++) printf "%s:%s:%s\n",$1,$2,$i; }' \
           |awk  '{ for (i = 1; i <= NF; i++) {if (i<NF) printf "%s ", $i; else printf ":%s\n",$i; } }'
done

