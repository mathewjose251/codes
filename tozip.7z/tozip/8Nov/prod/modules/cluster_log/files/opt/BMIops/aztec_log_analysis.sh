#!/bin/bash
#

# collect and process aztec httpd log files daily
#
# Maintenance: 
# ------------
# you may want to periodically delete
# the log files it stores on log01:/app/log/tmp/aztec-logs
# but since they can be very useful to have, I would wait 
# until you surely dont want any old ones. 

export PATH

PATH=$PATH:/usr/local/tools/bin;

lockfile=/var/run/mso/`basename $0`.lock

clean_up() {

  date
  echo "$0: In clean_up: $1"
  rm -f $lockfile
  exit 2
}

trap clean_up 1 2 3 15

[ -f $lockfile ] && clean_up "My lockfile, $lockfile, is preventing me from running."

COLLECT=/opt/BMIops/collect.sh
DAYS=2
HOSTGRP=aztec
SRCDIR=/app/log/aztec
LOGGRP="register swupdate access rtu engineering persistence submit_ara"
LOGDIR=/tmp
PROCESSDIR=/app/log/tmp/aztec-logs
COLOS=bashbash"
# uses mtime of files, so will catch from a backlogs if recollection occured
WEBALIZEFINDDAYS=1

d_fn() { d=aztec-${type}; }

# collect the files and stage them
for type in $LOGGRP; do
  FILES=${type}*gz
  LOGFILE=$LOGDIR/collect.sh.${type}.log
  $COLLECT $DAYS $HOSTGRP $SRCDIR/$FILES $PROCESSDIR/${type} > $LOGFILE 2>&1
done

WEBDIR=/var/www/html/usage

# webalize the files
for type in $LOGGRP; do
  d_fn
  /opt/BMIops/makewebalize.sh $WEBALIZEFINDDAYS $PROCESSDIR/${type}/data $WEBDIR/${d}/webalizer.conf 
done

# send the web content to the  nms server
for type in $LOGGRP; do
  d_fn
  rsync -aze ssh ${WEBDIR}/${d}/* nms02.usw2:${WEBDIR}/${d}/
  rsync -aze ssh ${WEBDIR}/${d}/* nms02.usw2:${WEBDIR}/${d}/
done

# webalize the same access logs on a per-colo basis. this hurts
# first prep the directories so we appear to have a "colo" data set
# this part is a hack that should be improved, made to use "COLOS", etc.
/opt/BMIops/access-log-colo-links.sh $DAYS

for colo in $COLOS ; do
  /opt/BMIops/makewebalize.sh $WEBALIZEFINDDAYS $PROCESSDIR/access/data-${colo} $WEBDIR/aztec-access-${colo}/webalizer.conf 
done

# send also the colo specific runs to the nms server
for colo in $COLOS; do
  rsync -aze ssh $WEBDIR/aztec-access-${colo}/* nms02.usw2:$WEBDIR/aztec-access-${colo}/
  rsync -aze ssh $WEBDIR/aztec-access-${colo}/* nms02.usw2:$WEBDIR/aztec-access-${colo}/
done

touch $WEBDIR/aztec-archive/index.html # this is to keep the nagios check happy

rm -f $lockfile
# and hey, we're done.
