#!/bin/sh -x

SCP=/usr/bin/scp
SSH=/usr/bin/ssh
CHMOD=/bin/chmod
CHOWN=/bin/chown
CP=/bin/cp
MV=/bin/mv
GZIP=/bin/gzip

for hosts in aztec01 aztec02 aztec03 aztec04 aztec05 aztec06 aztec07
do
	for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14
	do
		DATE=`/bin/date --date="-${i} day" +"%b%d%Y"`
		$SCP -pqCB ${hosts}:/app/log/aztec/access.${i}.gz /space/logs/aztec/${hosts}/access.${i}.gz 
		$GZIP -d /space/logs/aztec/${hosts}/access.${i}.gz
		$MV /space/logs/aztec/${hosts}/access.${i} /space/logs/aztec/${hosts}/access.${DATE}
		$GZIP -9 /space/logs/aztec/${hosts}/access.${DATE}
	done
done

$CHMOD -R 755 /space/logs/aztec
$CHOWN -R root:root /space/logs/aztec
