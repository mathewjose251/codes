#!/bin/bash
#
#

# collect and process httpd log files daily
#
# Maintenance: 
# ------------
# you may want to periodically delete
# the log files it stores on log01:/var/tmp/wl-web-logs
# but since they can be very useful to have, I would wait 
# until you surely dont want any old ones. 

export PATH

PATH=$PATH:/usr/local/tools/bin;
COLLECT=/opt/BMIops/collect.sh
DAYS=10
HOSTGRP=wl-web
SRCDIR=/app/log/httpd

#
# the LOGGRP value does more than one thing.
# 1) It acts as the beginning-anchored string match of filenames to collect off the source hosts
# 2) It is part of a compound directory name in processing and publishing 
#
LOGGRP="access"
LOGDIR=/tmp
PROCESSDIR=/app/log/tmp
COLOS=bashbash"
# uses mtime of files, so will catch from a backlogs if recollection occured
WEBALIZEFINDDAYS=1

logmap() { echo ${HOSTGRP}-${type}; }

# collect the files and stage them
for type in $LOGGRP; do
  FILES=${type}*gz
  LOGFILE=$LOGDIR/collect.sh.`logmap`.log
  $COLLECT $DAYS $HOSTGRP $SRCDIR/$FILES $PROCESSDIR/`logmap` > $LOGFILE 2>&1
done

WEBDIR=/var/www/html/usage

# webalize the files
for type in $LOGGRP; do
  set -x
  /opt/BMIops/makewebalize.sh $WEBALIZEFINDDAYS $PROCESSDIR/`logmap`/data $WEBDIR/`logmap`/webalizer.conf 
  set +x
done

# send the web content to the  nms server
for type in $LOGGRP; do
  rsync -aze ssh $WEBDIR/`logmap`/* nms02.usw2:$WEBDIR/`logmap`/
  rsync -aze ssh $WEBDIR/`logmap`/* nms02.usw2:$WEBDIR/`logmap`/
done


# and hey, we're done.
