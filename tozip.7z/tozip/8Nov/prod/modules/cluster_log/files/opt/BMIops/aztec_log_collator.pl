#!/opt/blocperl/bin/perl -w
#
# $Id: aztec_log_collator.pl,v 1.3 2018/10/30 10:11:51 mathew Exp $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_log/files/opt/BMIops/aztec_log_collator.pl,v $
#
#
# parses apache access logs and collates information for each IP/wall
# combination, thereby allowing us to make a pretty good guess at the
# number of actual systems retrieving rules. It handles all of the
# deployment cases wrt IPs and wall_ids, e.g.
#
#   one wall_id per IP address
#   many wall_ids per IP address (NAT)
#   many IP addresses per wall_id (Ironport, Borderware)
#
# This script is really a first-pass apache log summary tool; a
# subsequent summary on the database will allow the user to determine
# the actual number of servers actually retrieving data.  querying for
# the 'blrm' will probably return the most valid results for "number
# of walls hitting us on a given day"
#

# first do pattern matching.  We match against this:
# 208.57.84.226 - wall_id=59306 [17/May/2005:00:01:41 -0700] "GET /rules2/spamhunter.3.update HTTP/1.1" 304 - "-" "Conduit;$Name:  $;SBAS v6.0.2.0000;windows.x86"
my %ruleset_map = (
	   'av.symantec.linux.i386'    => 'av.lin',
	   'av.symantec.solaris.sparc' => 'av.sol',
	   'av.symantec.windows'       => 'av.win',
	   'blrm'                      => 'blrm',
	   'bashes'                    => 'bashes',
	   'permit_rules'              => 'permit',
	   'spamhunter'                => 'spamhunter',
	   'spamhunter.2'              => 'spamhunter.2',
	   'spamhunter.3'              => 'spamhunter.3',
	   'spamsigs'                  => 'spamsigs',
	   'spamsigs.2'                => 'spamsigs.2',
	   );

my ($first_date, $ip, $wall, $most_recent_date, $ruleset, $version, %data, %ipv, %stats_date, $counter);
#print "Beginning to analyze: ", scalar(localtime), "\n";
while(<>) {
    next unless /rules/; # we don't care about software update etc

# i want to track all ruleset and full/update ruleset download history
#    ($ip, $wall, $most_recent_date, $ruleset) = ($_ =~ /^(\d+\.\d+\.\d+\.\d+) .* wall_id=(\d+) \[(\S+) \-\d\d\d\d\] \"GET \/rules[2std]*\/(\S+) /) or next;

    ($ip, $wall, $most_recent_date, $ruleset, $version) = ($_ =~ /^(\d+\.\d+\.\d+\.\d+) .* wall_id=(\d+) \[(\S+) \-\d\d\d\d\] \"GET (\S+).* (".*")$/) or next;
    $first_date = $most_recent_date unless $first_date;
    $version =~ s/\"//g;

    $most_recent_date =~ /([^:]+):.+/; 
    $stats_date{$1}++;

# i want to be able to find out if customer is downloading full ruleset and how many times
#    $ruleset =~ s/\.update$//;
#    die "$ruleset => $_" unless $ruleset_map{$ruleset};
#    $data{$ip}{$wall}{$ruleset_map{$ruleset}}++;

    $data{$ip}{$wall}{$ruleset}++;
    $ipv{$ip}{$version}++;
#    last if ++$counter > 100000;
}

# roughly how many 1-minute intervals do the logs encompass?
my $intervals = find_intervals($first_date, $most_recent_date);

# modifies first date to use the date which appears the most
foreach my $currdate (sort { $stats_date{$a} <=> $stats_date{$b} } keys %stats_date) {
   $first_date = $currdate;
}

# now do all of the summarizing and database insertions
use BLOC::DB;
my $db = BLOC::DB->new();
$db->{AutoCommit} = 0;

# create table aztec_access_stats (
#     ip varchar2(15),
#     wall_id number(10),
#     number_of_requests number(10),
#     minutes number(10),
#     number_of_systems number(10),
#     ruleset varchar2(500), -- changed from 12 to 500 just to ensure it takes
#     timestamp date
# );

#print "Beginning to insert into aztec_access_stats: ", scalar(localtime), "\n";
my $sth = $db->prepare(q{
    insert into aztec_access_stats
      (ip, wall_id, ruleset, number_of_requests, minutes,
       number_of_systems, timestamp)
    values (?,?,?,?,?,?,to_date(?, 'dd/Mon/yyyy:hh24:mi:ss'))
});

$counter=0; # incremental commits
foreach my $ip (keys %data) {
    foreach my $wall_id (keys %{$data{$ip}}) {
	foreach my $ruleset (keys %{$data{$ip}{$wall_id}}) {
	    # number_of_systems for the period is number of requests /
	    # intervals, but should always be at least 1
	    $sth->execute($ip,
			  $wall_id,
			  $ruleset,
			  $data{$ip}{$wall_id}{$ruleset},
			  $intervals,
			  int($data{$ip}{$wall_id}{$ruleset}/$intervals) || 1,
			  $first_date);
		#$db->commit unless ++$counter % 10000; # disabling commit for faster results and integrity
		#print "." unless ++$counter % 10000; 
	}
    }
}

$sth->finish;

$sth = $db->prepare(q{
    insert into aztec_ip_versions
      (ip, version, timestamp)
    values (?,?,to_date(?, 'dd/Mon/yyyy:hh24:mi:ss'))
});

#print "Beginning to insert into aztec_ip_versions: ", scalar(localtime), "\n";
foreach my $ip (keys %ipv) {
  foreach my $ipversion (keys %{$ipv{$ip}}) {
     $sth->execute($ip,
		   $ipversion,
		   $first_date);
  }
}


$sth->finish;
$db->commit;
$db->disconnect;
#print "Finished: ", scalar(localtime), "\n";

#
# little helper function to find how many minutes of logs we're dealing with
#
sub find_intervals {
    my ($first_date, $last_date) = @_;
    use Time::Local;
    my $d=0;
    my %mmap = map {$_=>$d++} qw/jan feb mar apr may jun jul aug sep oct nov dec/;
    my ($fmd,$fmo,$fy,$fh,$fmi,$fs) =
	($first_date =~ /(\d\d)\/(\w\w\w)\/(\d\d\d\d):(\d\d):(\d\d):(\d\d)/);
    my ($lmd,$lmo,$ly,$lh,$lmi,$ls) =
	($last_date =~ /(\d\d)\/(\w\w\w)\/(\d\d\d\d):(\d\d):(\d\d):(\d\d)/);
    my $f = timelocal($fs,$fmi,$fh,$fmd,$mmap{lc($fmo)},$fy);
    my $l = timelocal($ls,$lmi,$lh,$lmd,$mmap{lc($lmo)},$ly);
    my $number_of_seconds = $l - $f;

    # customers ping the blrm every minute, so the number of
    # intervals is int($l - $f / 60)
    return int(($l - $f)/60)
}
