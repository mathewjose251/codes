#/bin/bash
#
# $Id: bt-web_log_analysis.sh,v 1.3 2018/10/30 10:11:51 mathew Exp $
# $Author: mathew $
# $Source: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_log/files/opt/BMIops/bt-web_log_analysis.sh,v $
#

# Remove old Log Files from server
rm -rf /app/log/tmp/bt-web-logs/*

# Create temp dir if it does not exist
if [ ! -d /app/log/tmp/bt-web-logs ]
then
        mkdir -p /app/log/tmp/bt-web-logs
fi

for host in `/usr/local/tools/bin/bmehost | grep ^bt-web`
do
	scp -p ${host}:/opt/bloctools/server/logs/access.1.gz /app/log/tmp/bt-web-logs/${host}-access.1.gz
done

/usr/bin/zmergelog /app/log/tmp/bt-web-logs/bt-web*-access.1.gz | webalizer -c /var/www/html/usage/bt-web/webalizer.conf

# Migrate results to NMS
rsync -aze ssh /var/www/html/usage/bt-web/* nms02.usw2:/var/www/html/usage/bt-web/
rsync -aze ssh /var/www/html/usage/bt-web/* nms02.usw2:/var/www/html/usage/bt-web/
