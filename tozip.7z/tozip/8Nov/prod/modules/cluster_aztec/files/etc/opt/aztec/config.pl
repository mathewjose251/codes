# -*- perl -*-
use strict;
my $rules_server   = 'http://bt-ard.aws.brightmail.com';
my $av_rules_server = 'http://bt-av.aws.brightmail.com';
my $rpc_server     = 'http://bt-rpc.aws.brightmail.com';
my $rpc_server2     = 'http://bt-rpc.tuc.brightmail.com';
my $stats_server   = 'http://bt-statack-a.aws.brightmail.com';
my $sw_server      = 'rsync://asu.aws.brightmail.com';
my $http_proxy_url = 'http://bt-rpc.aws.brightmail.com:80/';
#my $imrules_server = 'http://rtps.aws.iml.brightmail.com';
#my $imstats_server = 'http://rtps.aws.iml.brightmail.com:81';
my $ard_rsync_base = 'rsync://bt-ard.aws.brightmail.com:873';
my $ara_provisioning_server = 'http://bt-rpc.aws.brightmail.com';


# redis config.
my $redis_server = 'aztec-redissync-usw2.qgjpbt.ng.0001.usw2.cache.amazonaws.com';
my $redis_port = '6379';

# Supported Redis clients:
# Redis       - http://search.cpan.org/~dams/Redis-1.991/lib/Redis.pm
# Redis::Fast - http://search.cpan.org/~shogo/Redis-Fast-0.03/lib/Redis/Fast.pm
my $redis_client = 'Redis::Fast';   


# PR41541 - consumer submissions go to the bt-probe VIP
my $consumer_submission_server = 'http://bt-probe-a.aws.brightmail.com';

my $aztec_home     = '/opt/aztec';
my $aztec_data     = '/var/aztec';
my $aztec_etc      = '/etc/opt/aztec';
my $aztec_htdocs   = $aztec_data . '/htdocs';
my $aztec_state    = '/var/run/aztec';
my $cache_root     = '/var/cache/aztec';
my $httpd_log_dir  = '/var/log/aztec';
my $error_response = "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">
<HTML><HEAD>
<TITLE>%s</TITLE>
</HEAD><BODY>
<H1>%s</H1>
You don't have permission to access %s
on this server.<P>
</BODY></HTML>";

# PR 38948 - microupdates need to be in the normal DocumentRoot or Apache
#            wreaks havoc with the Last-Modified timestamp.
#            TODO: check whether having both of these is redundant.
my $micro_dir      = $aztec_htdocs;
my $publish_dir    = $micro_dir;

# these directories are copied exactly from $rules_server.  rules2
# isn't in the list because it currently comes from
# rules2_microupdates.  similarly, rules2litea comes from
# rules2litea_microupdates
my @simple_microupdate_rules_dirs = (
    'rules2std',   'rules2full', 'rules2liteb',
    'rules2litec', 'outbound',
    'rules2infrequent',
    # PR36600 - effectiveness rulesets
    'effectiveness_human',
    'effectiveness_automation',
    'effectiveness_heuristic',
    # PR39556 - rules2rben
    'rules2rben',
    # PR40060 - custom ruleset one
    'ccone',
    # PR41086 - consumer rulesets
    'consumer',
    # PR42675 - rapid response rulesets
    'rules2rr',
    # 46262 - base RBEN rules for ARA customers.
    'customer/rules',
    # PR48372 - rules5 BrightSig3 rules.
    'rules5',
    # PR48593 - .cloud rules
    'cloud',

);

# microupdate-supported rulesets
# a ruleset must be listed here or a request for its microupdates
# will return 400
my @microupdate_rulesets = (
    'blrm',    # original 9 at launch
#    'contentspim',
    'dayzero',
    '.aws.s',
    'intsigs',
    'permit_rules',    # PR 38925
#    'realtimespim',
    'spamhunter',
    'spamsigs',
    'statsigs',        # PR 38925
);

# PR 40335 - new verdicts are rsynced and downloadable for microupdates.
# However, their paths follow a different convention than the old verdicts,
# for some product-side reason.  Remember to keep this in sync with
# BLOC::Verdict and friends.
my @new_verdicts              = qw(bulk newsletter suspicious_url);
my @new_verdict_ruleset_roots = (
    'blrm',    # always BLRM v4
    '.aws.s',
    'intsigs',
    'spamhunter',
    'spamsigs',
    'statsigs',
);
my @new_verdict_rsync;
for my $verdict (@new_verdicts) {
    for my $root (@new_verdict_ruleset_roots) {
        push @microupdate_rulesets, sprintf( '%s_%s', $root, $verdict );
        for my $dir (qw/rules2 rules2full rules2infrequent/) {
            push @new_verdict_rsync,
              {
                dir => sprintf(
                    '%s/%s/%s_%s.vcdiff/',
                    $publish_dir, $dir, $root, $verdict
                ),
                url => sprintf(
                    '%s/publish/rules2_%s/%s.vcdiff/*',
                    $ard_rsync_base, $verdict, $root
                ),
                args => [ '-av', '--delete', '--exclude', '.*' ],
              };
        }
    }
}

# new disposition rules for litea
for my $verdict (@new_verdicts) {
    for my $verdict_ruleset_roots (qw/blrm .aws.s intsigs spamhunter spamsigs/)
    {
        push @new_verdict_rsync,
          {
            dir => sprintf(
                '%s/rules2litea/%s_%s.vcdiff/',
                $publish_dir, $verdict_ruleset_roots, $verdict
            ),
            url => sprintf(
                '%s/publish/rules2litea_%s/%s.vcdiff/*',
                $ard_rsync_base, $verdict, $verdict_ruleset_roots
            ),
            args => [ '-av', '--delete', '--exclude', '.*' ],
          };
    }
}



# list of all the aztec servers.
my @ara_memcached_servers;
my $datacenter = aws;
foreach my $server_num ( 1 .. 42 ) {
    push ( 
	@ara_memcached_servers,
	sprintf( "aztec%02s.%s.brightmail.com", $server_num, $datacenter )
    );
}

my $syslog_facility =  'local5';

$Aztec::Config = {

    # needed for error response set for custome responses
    error_response => $error_response,
    
    # needed by httpd.conf
    aztec_home    => $aztec_home,
    aztec_data    => $aztec_data,
    aztec_etc     => $aztec_etc,
    aztec_state   => $aztec_state,
    aztec_htdocs  => $aztec_htdocs,
    httpd_log_dir => $httpd_log_dir,
    micro_dir     => $micro_dir,
    publish_dir   => $publish_dir,
    #imstats_server => $imstats_server,

    # httpd peformance settings
    httpd_LogLevel             => 'info', # PR39433
    httpd_MinSpareServers      => 5,
    httpd_MaxSpareServers      => 10,
    httpd_StartServers         => 256,
    httpd_MaxRequestWorkers           => 768,
    httpd_MaxConnectionsPerChild  => 1000,
    httpd_TimeOut              => 60,
    httpd_KeepAlive            => 'On',

    # PR40405 - elektra walls will be asking for at most 27 URLs
    httpd_MaxKeepAliveRequests => 27,
    httpd_KeepAliveTimeout     => 10,
    httpd_SSLCertificateChainFile => $aztec_home . "/ssl/intermediate.crt",
    httpd_SSLCACertificateFile    => $aztec_home . "/ssl/bmi.crt",

    # ExportCertData is required for certificate gathering, but
    # otherwise just bloats the processes.  This value should be kept
    # aligned with cert_collection_enabled; if cert_collection_enabled
    # is true, then this config should be '+StdEnvVars
    # +ExportCertData'. If cert_collection_enabled is false, then this
    # config should be '+StdEnvVars'.  If the two are misaligned the
    # application will choose performance over correctness and will
    # NOT try to write certificates to disk.
    #
    # if cert_collection_enabled=>1
    #httpd_SSLOptions => '+StdEnvVars +ExportCertData',
    #
    # if cert_collection_enabled=>0
    httpd_SSLOptions => '+StdEnvVars',

    # httpd listeners.  these need to be kept in synch with the load
    # balancer in production, and can be whatever you want them to be
    # in dev/qa.  This also gives dev/qa the opportunity to do things
    # with certs.
    httpd_vhosts => {
        443 => {
            ServerName => 'aztec.brightmail.com',
            CustomLog  => "$httpd_log_dir/access access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/aztec.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/aztec.brightmail.com.key',
        },
        1443 => {
            ServerName => 'rtu.brightmail.com',
            CustomLog  => "$httpd_log_dir/rtu access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/rtu.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/rtu.brightmail.com.key',
        },
        2443 => {
            ServerName => 'persistence.brightmail.com',
            CustomLog  => "$httpd_log_dir/persistence access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/persistence.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/persistence.brightmail.com.key',
        },
        3443 => {
            ServerName => 'engineering.brightmail.com',
            CustomLog  => "$httpd_log_dir/engineering access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/engineering.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/engineering.brightmail.com.key',
        },
        5443 => {
            ServerName => 'swupdate.brightmail.com',
            CustomLog  => "$httpd_log_dir/swupdate access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/swupdate.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/swupdate.brightmail.com.key',
        },
        6443 => {
            ServerName => 'register.brightmail.com',
            CustomLog  => "$httpd_log_dir/register access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/register.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/register.brightmail.com.key',
        },
        7080 => {
            ServerName => 'consumerstats.brightmail.com',
            CustomLog  => "$httpd_log_dir/consumerstats access"
        },
        8443 => {
            ServerName => 'submit.brightmail.com',
            CustomLog  => "$httpd_log_dir/submit access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/submit.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/submit.brightmail.com.key',
            # PR 38896 - disable weak ciphers here for security audit.
            SSLProtocol    => "-ALL +SSLv3 +TLSv1",
            SSLCipherSuite => "ALL:!aNULL:!ADH:!eNULL:!LOW:!EXP:RC4+RSA:+HIGH:+MEDIUM",
        },
        9443 => {
            # PR 38704 via PR 38896 - appliance probe account support.
            ServerName => 'probes.brightmail.com',
            CustomLog  => "$httpd_log_dir/probes access",
            SSLEngine  => 'on',
            SSLCertificateFile => 'ssl/probes.brightmail.com.crt',
            SSLCertificateKeyFile => 'ssl/probes.brightmail.com.key',
            SSLProtocol    => "-ALL +SSLv3 +TLSv1",
            SSLCipherSuite => "ALL:!aNULL:!ADH:!eNULL:!LOW:!EXP:RC4+RSA:+HIGH:+MEDIUM",
        },
    },

    #
    # PR39134 - Maintain a list of messages suppressed by aztec_logger
    #
    #           Note: changes to this list require a bump to apache.
    #
    aztec_logger_suppressed_messages => [
        'System: Connection reset by peer',
        'OpenSSL:',
        'mod_ssl:',
	'System: Broken pipe',
	'AH01998:',
	'AH01964:',
	'SSL Library Error:', 
	'AH02008:',
    ],

    # return 503 for all requests with the exception of registrations
    # OFF => 0
    # ON  => 1
    maintenance_mode => 0,
    
    # tell client to retry after specified time if in maintenance mode.
    # The value can be either an HTTP-date or an integer number of seconds 
    # after the time of the response. This value is NOT verified for
    # correctness so what ever you define here is returned to the client.
    # The conduit currently doesn't know how to handle the Retry-After header
    # so this was mostly done for RFC compliance.
    #
    # Examples:
    #
    #      maintenance_mode_retry_after => 60
    #      maintenance_mode_retry_after => "Tue, 02 Dec 2008 23:59:59 GMT"
    maintenance_mode_retry_after => 60,
    
    user  => 'aztec',
    group => 'aztec',

    syslog_facility => "$syslog_facility",
 
    rpc_url        => "$rpc_server/xml-rpc",
    query_rpc_url  => "$rpc_server/rpc/aztec/query",
    query_rpc_url2  => "$rpc_server2/rpc/aztec/query",
    http_proxy_url => $http_proxy_url,
    grabber_http_proxy_url => '',

    stats_address => 'statistics@blocstats.aws.brightmail.com',
    sendmail_opts => '-odq',

    verify_mailwall_stats => 0,
    stats_url      => "$stats_server/rpc/aztec_stats",
    stats_dir      => "$aztec_data/stats",
    stats_timeout  => 120,
    stats_compressed => 0,

    aws_stats_enabled  => 1,
    aws_stats_dir      => "$aztec_data/aws_stats",
    aws_stats_bucket   => 'MSO to Configure',
    aws_access_key_id  => 'MSO to Configure',
    aws_secret_access_key => 'MSO to Configure',
    
    #
    # PR 39756 - Aztec handler for c.aws.stats lite
    #
    c.aws.stats_address => "$rpc_server/rpc/c.aws.stats",
    c.aws.stats_enabled => 1,

    #
    # microupdates
    #

    # PR 38866 - spec 1.9, 3.1.1: allowed rules_dir values
    microupdate_rules_dirs => [
        'rules2',
        'rules2litea',
        'spamlab/legit',
        'spamlab/spamsigsv1',
        @simple_microupdate_rules_dirs,
    ],

    # PR 38866 - spec 1.10, 3.1.1: allowed ruleset values
    microupdate_rulesets => \@microupdate_rulesets,

    # if a url matches a regex in microupdate_ttl_overrides, we'll
    # reply with that ttl.  otherwise we'll use the default ttl.
    microupdate_default_ttl   => 60,

    # overrides are processed in the order entered below (top to
    # bottom), and the first one that matches will take effect, so
    # more precise policies should go first. e.g. given
    #
    # microupdate_ttl_override => [
    #   [ qr/rules2.*spamhunter\.vcdiff\/\.5/, 15 ],
    #   [ qr/rules2.*spamhunter\.vcdiff/, 30 ]
    # ]
    #
    # a request for any spamhunter v5 ruleset will get a TTL of 15,
    # any other spamhunter ruleset will get a ttl of 30.
    microupdate_ttl_overrides => [
        # [ compiled regex, ttl ]
    ],

    #
    # support microupdate redirects, will have the requested
    # uri path pasted onto the uri, no trailing slash
    #
    # microupdate_redirect_url => 'https://liveupdate.symantec.com/bmi',

    #
    # PR 38985 - Forego 404's for requests in the future unless they're
    # *really* out of whack, then return HTTP `RC_INTERNAL_SERVER_ERROR'.
    # Otherwise return a lower-than-usual TTL with an `RC_NOT_MODIFIED'.
    #
    # (for now "really out of whack" means 15 minutes)
    #
    max_mud_sync_drift      => 3600,
    mud_sync_drift_ttl      => 59,

    #
    # PR39127 - Don't return 500's for out-of-sync rulesets for now
    # PR39384 - actually, that's exactly what we want to return.  Now
    # that sync looks at the past as well as the future, if we return
    # 304s for things that are way out of sync (say, 01-01-1980) those
    # clients will never ever ever get updates again.  ever.  so we'll
    # send 'em a 500 and they'll log to their admin about the fact
    # that somehow they ended up with a ruleset that aztec didn't know
    # anything about AND it was from the distant past (or future).  Of
    # course, this strategy will break down if we start pruning
    # rulesets that are just outside of max_mud_sync_drift AND clients
    # are trying to pull those rulesets.
    #
    # let the default value 500 assert itself
    #mud_sync_drift_response => '500',

    #
    # support for HTTP Submission API v1
    # http://intranet.brightmail.com/engineering/bloc/protocols/http_submissions.html
    # http://bz.brightmail.com/42310
    #

    # POSTs bigger than this value in bytes will be rejected with 413
    http_submission_v1_max_length => 5000000,

    # enables 503 for just the HTTP Submission API v1. if
    # maintenance_mode is true then requests will receive 503
    # regardless of this value.  there is no way to set a Retry-After
    # header specific to this API.
    http_submission_v1_maintenance_mode => 0,

    # if true, HTTP Submission API v1 handler will accept ALL
    # submissions, reply with "success" then throw the content away
    # whether/not it meets the API requirements
    http_submission_v1_discard_traffic => 0,

    # valid messages submitted correctly to the HTTP Submission API v1
    # handler will be sent to this address.  If a false value (0 or
    # undef) the message will be checked for validity but no mail will
    # be sent (the message will be thrown away).
    #
    # note that in production this address is datacenter-specific; to
    # prevent errors in dev and QA the shipping default is a safe value
    # http_submission_v1_email_address => 'nobody@localhost.localdomain',
    # SAC
    #http_submission_v1_email_address => 'junkyard-in@junk-in.tuc.brightmail.com,spool@spamlab-markup.tuc.brightmail.com',
    # TUC
    #http_submission_v1_email_address => 'junkyard-in@junk-in.aws.brightmail.com spool@spamlab-markup.aws.brightmail.com',
    http_submission_v1_email_address => 'localhost.localdomain',
    #
    # probe account creation
    #

    # set probe_requests_enabled to 0 to return a 503 for all probe
    # account creation requests
    probe_requests_enabled    => 1,

    # don't allow uploads in excess of 1MB
    probe_requests_max_length => 1_000_000,

    # time to receive reply from BLOC RPC
    probe_request_timeout     => 300,

    # bloc rpc for probe creation requests
    probe_request_rpc_uri     => "$rpc_server/rpc/probes",

    # certificate collection - see
    # http://socialtext.ges.symantec.com/mws-r/index.cgi?certificate_gathering_and_storage_minispec
    # note that collection won't work if httpd_SSLOptions isn't set
    # correctly, see the minispec for details
    cert_collection_enabled => 0,
    cert_collection_dir     => "$aztec_data/certificates",
    cert_collection_url     => "$stats_server/rpc/certificate_collection",

    # configurations for Aztec::ConsumerStat and consumer_stat_pusher
    consumer_stats_enabled    => 1,
    consumer_stats_url        => "$stats_server/rpc/consumer_stats",
    consumer_stats_dir        => "$aztec_data/consumer_stats",
    consumer_stats_timeout    => 120,
    consumer_stats_compressed => 0,

    # configurations for Aztec::Submission and
    # consumer_submission_pusher
    submission_max_length => 1_000_000,

    # compresses FP or FN tarballs prior to POSTing them?
    submission_compression   => 0,

    # HTTP POST timeout pushing FP/FNs to the BLOC
    submission_timeout       => 300,

    # each submission type can have different policies.
    # consumer_submission_pusher and Aztec::Submission depend on this
    # structure (and Aztec::Submission::Type provides accessors).
    #
    # briefly:
    #
    # uri         the URI to which this submission type is posted
    # checker     function that verifies the contents of the POST
    # handler     function that manages the disposition of the contents
    #             and generates the response
    # spool_dir   directory into which submissions are spooled
    # copy_dir    (optional) directory containing hard links of
    #             spooled submissions.  Entries in the directory should
    #             be cleaned up by a periodic cron job.
    # type        the submission type (fp/fn)
    # product     the product that uses this uri
    # backend_url the url consumer_submission_pusher talks to
    #
    submission_types => [
        {
            uri         => '/nis2010/fp',
            checker     => 'Aztec::Submission::nis2010_checker',
            handler     => 'Aztec::Submission::nis2010_handler',
            spool_dir   => "$aztec_data/consumer_submissions/nis2010_fps",
            copy_dir    => "$aztec_data/consumer_submissions/nis2010_fps.saved",
            type        => 'fp',
            product     => 'nis2010',
            backend_url => "$consumer_submission_server/rpc/consumer_submission/fp",
        },
        {
            uri         => '/nis2010/fn',
            checker     => 'Aztec::Submission::nis2010_checker',
            handler     => 'Aztec::Submission::nis2010_handler',
            spool_dir   => "$aztec_data/consumer_submissions/nis2010_fns",
            copy_dir    => "$aztec_data/consumer_submissions/nis2010_fns.saved",
            type        => 'fn',
            product     => 'nis2010',
            backend_url => "$consumer_submission_server/rpc/consumer_submission/fn",
        },
    ],

    register_timeout => 10,

    lk_timeout      => 30,
    lk_cache_expire => 7200, # 2 hours in seconds.
    cache_root      => $cache_root,

    # PR47059 - config to poll BLOC rpc call to help refresh memcached
    # on upgrade.
    max_retries     => 3,

    #
    # ruleset mirroring
    #
    grabber_sleep_time         => 10,
    grabber_request_timeout    => 300,
    av_grabber_sleep_time      => 30,
    av_grabber_request_timeout => 1200,
    rsync_grabber_sleep_time   => 5,

    # how long should an rsync kid be allowed to run?  This is
    # different from --timeout, if you want to use that do it in
    # rsync_urls => ...args => "--timeout=600".  This setting will
    # cause rsync_grabber to reap an rsync kid that's run for too long
    # (via Aztec::Daemon via IPC::Run).
    rsync_grabber_rsync_timeout => 600,

    # we can nice the grabber to a better priority so that it won't
    # get as bogged down by httpd kids in traffic spikes
    grabber_nice    => 0,
    av_grabber_nice => 0,
    rsync_grabber_nice => 0,

    rsync_urls => [
        # grab all lu.* files out of the aztec/consumer directories.
        # in summary, the --include /lu.* makes sure we get all lu.*
        # files from the consumer/archive, while the --exclude
        # /intsigs/spamhunter makes sure we ignore the stuff that
        # grabber.pl will pick up.  `man rsync` for a deeper
        # explanation of --include and --exclude directives
        {
            dir  => "$aztec_htdocs/consumer",
            url  => "$ard_rsync_base/consumer",
            args => [ '-av', '--delete',
                      '--include', '/lu.*',
                      '--exclude', '/intsigs*',
                      '--exclude', '/spamhunter*',
                      ],
        },

        #
        # grab all .vcdiff rulesets for microupdates, and ignore
        # everything else.
        #

        # rules2 is special, contents currently come from rules2_microupdates
        {
            dir => sprintf( "%s/rules2/", $publish_dir ),
            url => sprintf( "%s/publish/rules2_microupdates/*.vcdiff",
                            $ard_rsync_base ),
            args => [ '-av', '--delete', '--exclude', '.*' ],
        },

        # rules2litea special too, contents come from rules2litea_microupdates
        {
            dir => sprintf( "%s/rules2litea/", $publish_dir ),
            url => sprintf( "%s/publish/rules2litea_microupdates/*.vcdiff",
                            $ard_rsync_base ),
            args => [ '-av', '--delete', '--exclude', '.*' ],
        },

        # PR40752 legit special too, contents need to be copied to spamlab folder
        {
            dir => sprintf( "%s/spamlab/legit/", $publish_dir ),
            url => sprintf( "%s/publish/legit/*.vcdiff",
                            $ard_rsync_base ),
            args => [ '-av', '--delete', '--exclude', '.*' ],
        },

        # PR40752 spamsigs version1 are copied as version2 for spamlab markup purposes.
        {
            dir => sprintf( "%s/spamlab/spamsigsv1/spamsigs.vcdiff/2/", $publish_dir ),
            url => sprintf( "%s/publish/rules2/spamsigs.vcdiff/1/",
                            $ard_rsync_base ),
            args => [ '-av', '--delete', '--exclude', '.*' ],
        },

        # Special case for rules4, we only get rules4/spmahunter.4 from 
        # the ard_sync_base, rest of the ruleset should be symlinked to rules2
        {
            dir => sprintf( "%s/rules4/", $publish_dir ),
            url => sprintf( "%s/publish/rules4/*.vcdiff",
                            $ard_rsync_base ),
            args => [ '-av', '--delete', '--exclude', '.*' ],
        },

        # other microupdate rules dirs are simple, they're a direct
        # mapping from ard => aztec
        (
            map {
                {
                    dir => sprintf( "%s/%s/", $publish_dir, $_ ),
                    url => sprintf( "%s/publish/%s/*.vcdiff",
                                    $ard_rsync_base, $_ ),
                    args => [ '-av', '--delete', '--exclude', '.*' ],
                }
            } @simple_microupdate_rules_dirs
        ),

        # PR 40335 - except new verdicts, which also get renamed.  These are
        # defined above.
        @new_verdict_rsync,

    ],

    grabber_urls => [
        {
            dir  => "$aztec_htdocs/rules",
            urls => [
                "$rules_server/aztec/rules/blrm",
                "$rules_server/aztec/rules/.aws.s",
                "$rules_server/aztec/rules/spamsigs",
                "$rules_server/aztec/rules/spamsigs.2",
                "$rules_server/aztec/rules/spamhunter",
                "$rules_server/aztec/rules/spamhunter.2",
                "$rules_server/aztec/rules/spamhunter.3",
                "$rules_server/aztec/rules/permit_rules",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2",
            urls => [
                "$rules_server/aztec/rules2/blrm",
                "$rules_server/aztec/rules2/blrm.4",
                "$rules_server/aztec/rules2/.aws.s",
                "$rules_server/aztec/rules2/spamsigs",
                "$rules_server/aztec/rules2/spamsigs.2",
                "$rules_server/aztec/rules2/spamhunter",
                "$rules_server/aztec/rules2/spamhunter.2",
                "$rules_server/aztec/rules2/spamhunter.3",
                "$rules_server/aztec/rules2/spamhunter.4",
                "$rules_server/aztec/rules2/permit_rules",
                "$rules_server/aztec/rules2/intsigs",
                "$rules_server/aztec/rules2/dayzero.4",
                "$rules_server/aztec/rules2/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2std",
            urls => [
                "$rules_server/aztec/rules2std/blrm",
                "$rules_server/aztec/rules2std/blrm.4",
                "$rules_server/aztec/rules2std/.aws.s",
                "$rules_server/aztec/rules2std/spamsigs.2",
                "$rules_server/aztec/rules2std/spamhunter.2",
                "$rules_server/aztec/rules2std/spamhunter.3",
                "$rules_server/aztec/rules2std/spamhunter.4",
                "$rules_server/aztec/rules2std/permit_rules",
                "$rules_server/aztec/rules2std/intsigs",
                "$rules_server/aztec/rules2std/dayzero.4",
                "$rules_server/aztec/rules2std/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2full",
            urls => [
                "$rules_server/aztec/rules2full/blrm",
                "$rules_server/aztec/rules2full/blrm.4",
                "$rules_server/aztec/rules2full/.aws.s",
                "$rules_server/aztec/rules2full/spamsigs.2",
                "$rules_server/aztec/rules2full/spamhunter.2",
                "$rules_server/aztec/rules2full/spamhunter.3",
                "$rules_server/aztec/rules2full/spamhunter.4",
                "$rules_server/aztec/rules2full/permit_rules",
                "$rules_server/aztec/rules2full/intsigs",
                "$rules_server/aztec/rules2full/dayzero.4",
                "$rules_server/aztec/rules2full/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2litea",
            urls => [
                "$rules_server/aztec/rules2litea/blrm",
                "$rules_server/aztec/rules2litea/blrm.4",
                "$rules_server/aztec/rules2litea/.aws.s",
                "$rules_server/aztec/rules2litea/spamsigs.2",
                "$rules_server/aztec/rules2litea/spamhunter.2",
                "$rules_server/aztec/rules2litea/spamhunter.3",
                "$rules_server/aztec/rules2litea/spamhunter.4",
                "$rules_server/aztec/rules2litea/permit_rules",
                "$rules_server/aztec/rules2litea/intsigs",
                "$rules_server/aztec/rules2litea/dayzero.4",
                "$rules_server/aztec/rules2litea/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2liteb",
            urls => [
                "$rules_server/aztec/rules2liteb/blrm",
                "$rules_server/aztec/rules2liteb/blrm.4",
                "$rules_server/aztec/rules2liteb/.aws.s",
                "$rules_server/aztec/rules2liteb/spamsigs.2",
                "$rules_server/aztec/rules2liteb/spamhunter.2",
                "$rules_server/aztec/rules2liteb/spamhunter.3",
                "$rules_server/aztec/rules2liteb/spamhunter.4",
                "$rules_server/aztec/rules2liteb/permit_rules",
                "$rules_server/aztec/rules2liteb/intsigs",
                "$rules_server/aztec/rules2liteb/dayzero.4",
                "$rules_server/aztec/rules2liteb/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2litec",
            urls => [
                "$rules_server/aztec/rules2litec/blrm",
                "$rules_server/aztec/rules2litec/blrm.4",
                "$rules_server/aztec/rules2litec/.aws.s",
                "$rules_server/aztec/rules2litec/spamsigs.2",
                "$rules_server/aztec/rules2litec/spamhunter.2",
                "$rules_server/aztec/rules2litec/spamhunter.3",
                "$rules_server/aztec/rules2litec/spamhunter.4",
                "$rules_server/aztec/rules2litec/permit_rules",
                "$rules_server/aztec/rules2litec/intsigs",
                "$rules_server/aztec/rules2litec/dayzero.4",
                "$rules_server/aztec/rules2litec/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            dir  => "$aztec_htdocs/outbound",
            urls => [
                "$rules_server/aztec/outbound/blrm",
                "$rules_server/aztec/outbound/blrm.4",
                "$rules_server/aztec/outbound/.aws.s",
                "$rules_server/aztec/outbound/spamsigs.2",
                "$rules_server/aztec/outbound/spamhunter.2",
                "$rules_server/aztec/outbound/spamhunter.3",
                "$rules_server/aztec/outbound/spamhunter.4",
                "$rules_server/aztec/outbound/permit_rules",
                "$rules_server/aztec/outbound/intsigs",
                "$rules_server/aztec/outbound/dayzero.4",
                "$rules_server/aztec/outbound/statsigs",
                #"$imrules_server/rules/contentspim",
                #"$imrules_server/rules/realtimespim",
            ],
        },
        {
            # rsync_grabber picks up stuff for liveupdate, grabber
            # picks up stuff for the Shasta/SBMF integration
            dir  => "$aztec_htdocs/consumer",
            urls => [
                "$rules_server/aztec/consumer/spamhunter.4",
                "$rules_server/aztec/consumer/intsigs",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules.other",
            urls => [
                "$rules_server/aztec/rules.other/brs21",
                "$rules_server/aztec/rules.other/zodiac.rbldns",
                "$rules_server/aztec/rules.other/bad.zodiac.rbldns",
                "$rules_server/lists/opl.txt",
                "$rules_server/lists/suspectip.txt",
                "$rules_server/lists/zombie.txt",
            ],
        },
        {
            dir  => "$aztec_htdocs/basicspam",
            urls => [ "$rules_server/aztec/basicspam/spamhunter.4", ],
        },
        {
            # PR36600 anti-spam effectiveness rulesets: human
            dir  => "$aztec_htdocs/effectiveness_human",
            urls => [
                "$rules_server/aztec/effectiveness_human/spamsigs.2",
                "$rules_server/aztec/effectiveness_human/intsigs",
                "$rules_server/aztec/effectiveness_human/.aws.s",
                "$rules_server/aztec/effectiveness_human/blrm.4",
                "$rules_server/aztec/effectiveness_human/spamhunter.4",
            ],
        },
        {
            # PR36600 anti-spam effectiveness rulesets: automation
            dir  => "$aztec_htdocs/effectiveness_automation",
            urls => [
                "$rules_server/aztec/effectiveness_automation/intsigs",
                "$rules_server/aztec/effectiveness_automation/blrm.4",
                "$rules_server/aztec/effectiveness_automation/spamhunter.4",
            ],
        },
        {
            # PR36600 anti-spam effectiveness rulesets: heuristic
            dir  => "$aztec_htdocs/effectiveness_heuristic",
            urls => [
                "$rules_server/aztec/effectiveness_heuristic/statsigs",
                "$rules_server/aztec/effectiveness_heuristic/spamhunter.4",
            ],
        },
        {
            # PR39556 staged RBEN ruleset
            dir  => "$aztec_htdocs/rules2rben",
            urls => [
                "$rules_server/aztec/rules2rben/spamhunter.4",
            ],
        },
    ],

    av_grabber_urls => [
        {
            dir  => "$aztec_htdocs/rules",
            urls => [
                "$av_rules_server/aztec/rules/av.symantec.solaris.sparc",
                "$av_rules_server/aztec/rules/av.symantec.windows",
                "$av_rules_server/aztec/rules/av.symantec.linux.i386",
            ],
        },
        {
            dir  => "$aztec_htdocs/rules2",
            urls => [
                "$av_rules_server/aztec/rules2/av.symantec.solaris.sparc",
                "$av_rules_server/aztec/rules2/av.symantec.windows",
                "$av_rules_server/aztec/rules2/av.symantec.linux.i386",
            ],
        },
        {
            dir  => "$aztec_htdocs/symantec.rr",
            urls => [
                "$av_rules_server/aztec/symantec.rr/av.symantec.solaris.sparc",
                "$av_rules_server/aztec/symantec.rr/av.symantec.windows",
                "$av_rules_server/aztec/symantec.rr/av.symantec.linux.i386",
            ],
        },
        {
            dir  => "$aztec_htdocs/symantec.platinum",
            urls => [
                "$av_rules_server/aztec/symantec.platinum/av.symantec.solaris.sparc",
                "$av_rules_server/aztec/symantec.platinum/av.symantec.windows",
                "$av_rules_server/aztec/symantec.platinum/av.symantec.linux.i386",
            ],
        },
    ],

    #
    # Default rysnc settings.
    #
    rsync_bin                 => '/usr/bin/rsync',
    rsync_cache_dir           =>  "$cache_root",
    rsync_timeout             => 600,

    #
    # APT mirroring
    #
    apt_grabber_rsync_timeout => 600,
    apt_grabber_cache_dir     => "$cache_root/apt_grabber",
    apt_grabber_sleep_time    => 1800,

    # NOTE: 'name' is used as a subdirectory name
    apt_repositories => [
        {
            name             => 'prod',
            remote_rsync_url => "$sw_server/prod-reader",
            local_path => "$aztec_htdocs/products/smsapp/prod/i386",
        },
        {
            name             => 'beta',
            remote_rsync_url => "$sw_server/beta-reader",
            local_path => "$aztec_htdocs/products/smsapp/beta/i386",
        },
        # Bug 38725 - rsync prod2 repositories for DDS migration
        {
            name             => 'prod2',
            remote_rsync_url => "$sw_server/prod2-reader",
            local_path => "$aztec_htdocs/products/smsapp/prod2/i386",
            version_info => 1,  # Bug 38690
        },
        {
            name             => 'beta2',
            remote_rsync_url => "$sw_server/beta2-reader",
            local_path => "$aztec_htdocs/products/smsapp/beta2/i386",
            version_info => 1,  # Bug 38690
        },
        {
            name             => 'asr-prod',
            remote_rsync_url => "$sw_server/asr-prod-reader",
            local_path => "$aztec_htdocs/products/asrapp/prod/i386",
        },
        {
            name             => 'asr-beta',
            remote_rsync_url => "$sw_server/asr-beta-reader",
            local_path => "$aztec_htdocs/products/asrapp/beta/i386",
        },
        # PR 46002 - Support for yum repo
        {
            name             => 'prod3',
            remote_rsync_url => "$sw_server/prod3-reader",
            local_path       => "$aztec_htdocs/products/smsapp/prod3",
            yum_repo         => 1,
            symc_dir         => qr{/symc/(?:i386|x86_64)},
        },
        # PR 46002 - Support for Yum repo
        {
            name             => 'beta3',
            remote_rsync_url => "$sw_server/beta3-reader",
            local_path       => "$aztec_htdocs/products/smsapp/beta3",
            yum_repo         => 1,
        },
        # PR 48569 - New beta4/prod4 directories for SMG Voyager
        {
            name             => 'prod4',
            remote_rsync_url => "$sw_server/prod4-reader",
            local_path       => "$aztec_htdocs/products/smsapp/prod4",
            yum_repo         => 1,
            symc_dir         => qr{/symc/(?:i386|x86_64)},
        },
        # PR 48569 - New beta4/prod4 directories for SMG Voyager
        {
            name             => 'beta4',
            remote_rsync_url => "$sw_server/beta4-reader",
            local_path       => "$aztec_htdocs/products/smsapp/beta4",
            yum_repo         => 1,
        },
        # BZ 47805, 47776 - Support for SGSTD, yum repos
        {
            name             => 'sgstd-beta',
            remote_rsync_url => "$sw_server/sgstd-beta-reader",
            local_path => "$aztec_htdocs/products/sgstd/beta",
            yum_repo         => 1,
        },
        {
            name             => 'sgstd-test',
            remote_rsync_url => "$sw_server/sgstd-test-reader",
            local_path => "$aztec_htdocs/products/sgstd/test",
            yum_repo         => 1,
        },
        {
            name             => 'sgstd-prod',
            remote_rsync_url => "$sw_server/sgstd-prod-reader",
            local_path => "$aztec_htdocs/products/sgstd/prod",
            yum_repo         => 1,
        },
        # PR48773 - Support for ATPU 2.0
        {
            name             => 'atpu-beta',
            remote_rsync_url => "$sw_server/atpu-beta-reader",
            local_path       => "$aztec_htdocs/products/atpu/beta",
            yum_repo         => 1,
        },
        {
            name             => 'atpu-test',
            remote_rsync_url => "$sw_server/atpu-test-reader",
            local_path       => "$aztec_htdocs/products/atpu/test",
            yum_repo         => 1,
        },
        {
            name             => 'atpu-prod',
            remote_rsync_url => "$sw_server/atpu-prod-reader",
            local_path       => "$aztec_htdocs/products/atpu/prod",
            yum_repo         => 1,
        },
    ],

    #
    # ARA Configurations
    #
    # Point to certificate to be used when communicating to ARA
    # over https. If undef or the file does not exist on the 
    # disk, Aztec will not contact ARA
    ara_aztec_certificate_file => "$aztec_home/ssl/aztec-cert.pem",

    # include this file in https conversion with ARA.
    # If undef, or file is not present on the disk. 
    # No connection will be made to ARA.
    ara_aztec_ca_file          => "$aztec_home/ssl/ara-cacert.pem",

    # ara status file XML.
    # Content (xml) of this status file will only be returned to the caller 
    # if there is no status message available for the caller in memcached.
    # if file is empty or config is undef, empty reponse will be returned.
    ara_status_file            => undef,

    # BLOC ARA provisioning url - use bt-web because it already has
    # firewall access to AWS for other things
    bloc_provisioning_rpc_url  => "$ara_provisioning_server/rpc/ara/wall",

    #
    # Cache configurations, 1 for enable, 0 disable
    #
    filecache_enabled => 1,

#    memcached_bin => '/usr/bin/memcached',
#    memcached_user => 'aztec',

    # Memcached for storing WallServiceMap data
     aztec_redis_enabled          => 1,
#    aztec_memcached_cache_size       => 1024,
#    aztec_max_memcached_connections  => 1024,
#    aztec_memcached_port             => 11211,
     redis_server  => $redis_server,
     redis_port    => $redis_port,
     redis_client  => $redis_client,

    # command line options added in bloc-memcached.
    # Options -T ident, -F syslog facilty and -V {verbose}
#    aztec_memcached_options          => "",

    # Memcached for storing ARA specific data.
#    ara_memcached_enabled          => 1,
    ara_redis_enabled          => 1,
#    ara_memcached_cache_size       => 256, # Size of Memcached in MB
#    ara_max_memcached_connections  => 33000, # httpd_MaxClients * number_of_aztec_servers_is_this_dc
#    ara_memcached_port             => 11212,
    # Protocol integer 0 - TCP, UDP otherwise
#    ara_memcached_protocol         => 1,
#    ara_memcached_redundancy_level => 2,

    # command line options added in bloc-memcached.
    # Options -T ident, -F syslog_facilty and -V {verbose}
#    ara_memcached_options          => " -T ARA_Memcached -F $syslog_facility",

    # List of aztec server memcached is running on.
    # By default memcached will be running on all the aztec server
    # under that datacenter.
    # For QA - point it to  list of machine running memcached. If more than
    # one machine is running memcached, do not use 127.0.0.1 or localhost.
#    ara_memcached_servers          => \@ara_memcached_servers,
#    ara_provisioning_server        => $ara_provisioning_server,

    # memcached_synchronizer_servers must point to the list of Aztec servers
    # memcached_synchronizer.pl should run on.
    # Host name of the server should be derived as follows:
    #        perl -MSys::Hostname -e 'print Sys::Hostname::hostname;'
#    memcached_synchronizer_servers => [ 'aztec01.aws., 'aztec02.aws.],
    redis_synchronizer_servers => ["127.0.0.1","aztec-redis-sync01","aztec-redis-sync02"],	 
    redis_synchronizer_rpc_url  => "$ara_provisioning_server/rpc/ara/aztec",
#    memcached_synchronizer_rpc_url  => "$ara_provisioning_server/rpc/ara/aztec",

    # memcached_synchronizer.pl should sleep for <num> of seconds if its not
    # in the config: memcached_synchronizer_servers list.
#    memcached_synchronizer_sleep_time => 300,
    redis_synchronizer_sleep_time => 300,

    # Synchronizer will grab the full list for each namespace based
    # on following configs. 
    WallSubmitterMap_synchronizer_sleep_time         => 60,
    WallRedirectMap_synchronizer_sleep_time          => 60,
    SubmitterStatusMap_synchronizer_sleep_time       => 60,
    SubmitterRegionURLMap_synchronizer_sleep_time    => 60,

    # Please NOTE: This value must always be less thatn WallSubmitterMap_synchronizer_sleep_time
    # If set to > WallSubmitterMap_synchronizer_sleep_time, memcached_synchronizer.pl
    # may not behave as expected.
    # Get the WallSubmitterMap update every <n> seconds.
    WallSubmitterMap_update_synchronizer_sleep_time  => 1,

    # PR 44459 - Aztec randomly returns 403s for customer-specific rules due to 
    # memached race condition. Aztec will now use a BLOC RPC if it does not find
    # submitter info for a wall id in Memached. BLOC RPC Lookup can be 
    # enabled/disabled using following config. Values: 1: Enabled, 0: Disabled.
    WallSubmitterMap_RPC_lookup  => 1,
   
   # PR 48594 - Aztec returns 403 for end of life products.
   # This was done to help reduce load on aztec servers that is 
   # caused at times by these old customers asking for AV defs.
   EndOfLifeUserAgentMatches => [qr/SBAS v6.0/,],
};
