#!/bin/bash
PROMPT="/tmp/smg-prompts.$$.tmp"
cd /opt/symantec/smg-sp/Scanner/ || { exit 1; }
cat <<__EOF__ > $PROMPT
y
/tmp
/var/log/brightmail
/var/spool/brightmail
n
n


__EOF__
echo "Auto-registering SMG 10.6"
RC=$(./configure.sh < $PROMPT | grep -c 'configured successfully')
rm -f -- $PROMPT
if [ ${#RC} -lt 1 -o $RC -ne 5 ]
then
    echo "Registration of SMG 10.6 failed."
    exit 1
fi
rm -rf -- bm_ruleset* > /dev/null 2>&1
rm -rf -- etc/bm_ruleset* > /dev/null 2>&1
echo "Registration of SMG 10.6 succeeded."
exit 0
