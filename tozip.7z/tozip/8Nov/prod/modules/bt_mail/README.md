The bt_mail module is a module for configuring  sendmailin bt* servers

 readme

Creating the Sendmail Puppet recipe

What  to  achieve  ::
 The mail settings for each cluster in our application  may differ .we need to define the common email setup 
 in easy to use language in the puppet  manifest
 that later can be tested and executed to achieve desired level of consistency.

So the desired level of consistency  depends on our needs  is described as below in terms of puppet.

−  Sendmail related files and directories
−  Cluster specific aliases file and sendmail.mc Files

−  The Sendmail.cf file has to build in each server based on the cluster specific senmdail.mc file
−  The mail related .db files has to created
−  The  sendmail service should be reloaded based on   the config Changes

 we do not have to write everything from scratch, the code  from staging is  reusable with Hiera data lookup .

We use the definitive language that puppet provides  (DSL) along with the classes and functions which we created .



While puppet agent runs on   bt servers  ,  this module will be called in teh main stage as bt_mail 

We use run  stages  via a base module along with and role and profiles via Hiera.

stages
----
Stage[one] :Base Module

             :: users,::Ec2configs
             YUM  Module

Stage[two] :Puppet module

Stage[three]:sudoers module

            :nagios install module

Stage[Main] :nrpe module
            :system module (wip)
            nfs module
            Sendmail_tools module
            bt_mail module

The rest of details are data  sensitive and  will not  be included in the readme file.
