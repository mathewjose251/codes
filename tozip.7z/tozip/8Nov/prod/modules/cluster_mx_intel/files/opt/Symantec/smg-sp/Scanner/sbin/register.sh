#!/bin/sh
# $Header: /space/cvsroot/aws/skyline/prod/puppet/prod/modules/cluster_mx_intel/files/opt/symantec/smg-sp/Scanner/sbin/register.sh,v 1.3 2018/10/30 10:11:53 mathew Exp $
#
#   Copyright 1998-2013 Symantec Corporation.   All Rights Reserved.
#
#  This product is protected by U.S. and International Copyright and
#  distributed under license restricting copying, distributing, and
#  decompiling.
#
#  ALL SOFTWARE, SERVICES, AND DOCUMENTATION PRODUCED FROM THIS CODE
#  ARE BEING PROVIDED "AS IS". SYMANTEC CORPORATION (SYMANTEC) MAKES NO
#  REPRESENTATION OR WARRANTY OF ANY KIND WHETHER EXPRESS OR IMPLIED
#  (EITHER IN FACT OR BY OPERATION OF LAW) WITH RESPECT TO THE SOFTWARE
#  GENERATED FROM THIS CODE.  SYMANTEC EXPRESSLY DISCLAIMS ALL IMPLIED
#  WARRANTIES, INCLUDING WITHOUT LIMITATION, THOSE OF NONINFRINGEMENT,
#  MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. SYMANTEC DOES NOT
#  WARRANT THAT THIS CODE WILL BE ERROR-FREE, SECURE, OR UNINTERRUPTED.
#
# File Name       :    register.sh
# Description     :    Wrapper scrip for register
# Original Author :    Raphael Pepi
# Current Owner   :    Raphael Pepi

#--- BASIC VARIABLES ----------------------------------------------------------
BASEDIR=/opt/symantec/smg-sp/Scanner
cfgfound=1
cmd_args=$*

#--- Functions ----------------------------------------------------------------


# Launch Registration Tool 
regTool()
{
	/opt/symantec/smg-sp/Scanner/sbin/register -c /opt/symantec/smg-sp/Scanner/etc/bmiconfig.xml $cmd_args
}

#--- MAIN ---------------------------------------------------------------------

output=`id |grep "uid=0("`

result=$?
if [ $result -ne 0 ]; then
    echo "Registation must be done as root."
    exit 1;
fi

. /opt/symantec/smg-sp/Scanner/etc/brightmail-env 

regTool
 
